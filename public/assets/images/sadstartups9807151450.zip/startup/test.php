<?php /* Template Name:Test */ 	?>

test
<?php 
wp_mail( 'golchin.saeed@gmail.com', 'subject', 'test');
mail( 'golchin.saeed@gmail.com', 'subject', 'test');
?>