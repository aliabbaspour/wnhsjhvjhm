<?php get_header();?>
<?php the_post();?>
<div class="container-fluid bg-purple">
    <div class="container">
    	<h1 class="pad-20 align-center font-s40 color1 bold"><?php the_title();?></h1>
    </div>
</div>
<div class="container-fluid bg-gray">
    <div class="container">
    	<div class="colm colm8 margin-auto bg1 pad-20">
    		<div class="align-center pad-20 sinlge-image">
    			<?php the_post_thumbnail(array(420,420));?>
    		</div>
    		<div class="single-content align-justify font-s13 color6 pad-t20 pad-b20">
    			<?php the_content();?>
    		</div>
    	</div>
    </div>
</div>
<?php get_footer(); ?>