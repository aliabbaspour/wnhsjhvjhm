<!doctype html>
<html class="no-js" <?php language_attributes(); ?> >
<?php 
$setting_keyword = get_option('setting_webpage_keyword');
$setting_description = get_option('setting_webpage_description');
?>
<head>
	<meta charset="utf-8" />
	<meta name="viewport" content="width=device-width, initial-scale=1.0" />
    <meta name="Keywords" content="<?php echo trim($setting_keyword)  ?>">
    <?php if (is_home()):?>
    <meta name="description" content="<?php echo $setting_description ?>" />
    <meta name="DC.Title" content="<?php bloginfo('name') ?>"/>
    <meta name="DC.Description" content="<?php echo $setting_description ?>"/>
    <meta name="DC.Language" content="fa_IR"/>
    <meta name="DC.Publisher" content="<?php bloginfo('name') ?>"/>
    <meta property="og:locale" content="fa_IR" />
    <meta property="og:type" content="website" />
    <meta property="og:title" content="<?php bloginfo('name') ?>" />
    <meta property="og:description" content="<?php echo $setting_description ?>" />
    <meta property="og:url" content="<?php echo home_url() ?>" />
    <meta property="og:site_name" content="<?php bloginfo('name') ?>" />
    <?php endif ?>
    <?php if(is_singular('post')):?>
    <meta name="description" content="<?php echo get_the_excerpt()?>" />
    <meta name="DC.Identifier" content="<?php the_permalink()?>"/>
    <meta name="DC.Date.Created" content="<?php the_time('F j, Y'); ?> at <?php the_time('g:i a'); ?>"/>
    <meta name="DC.Title" content="<?php the_title()?>"/>
    <meta name="DC.Description" content="<?php echo get_the_excerpt()?>"/>
    <meta name="DC.Language" content="<?php echo get_bloginfo('language')?>"/>
    <meta name="DC.Publisher" content="<?php echo get_bloginfo('name') ?>"/>
    <meta property="og:site_name" content="<?php echo get_bloginfo('name') ?>"/>
    <meta property="og:url" content="<?php the_permalink()?>">
    <meta property="og:title" content="<?php the_title()?>" />
    <meta property="og:description" content="<?php echo get_the_excerpt()?>" />
    <?php $thumbnail_src = wp_get_attachment_image_src(get_post_thumbnail_id($post -> ID), "medium"); ?>
    <meta property="og:image" content="<?php echo $thumbnail_src[0]; ?>" />
    <meta property="og:image:secure_url" content="<?php echo $thumbnail_src[0]; ?>">
    <meta property="og:image:width" content="<?php echo $thumbnail_src[1]; ?>">
    <meta property="og:image:height" content="<?php echo $thumbnail_src[2]; ?>">
    <meta property="og:image:type" content="images/jpg">
    <?php endif ?>
    <?php wp_head(); ?>
</head>
<body <?php body_class(); ?>>
	<div id="wrapper">
		
		<div class="loader">
			<div class="loadfix">
                <img width="200" src="<?php bloginfo('template_url') ?>/assets/images/loading.gif" />
            </div>
		</div>
		
	    <header id="header" class="container-fluid hide-tab">
             <div class="container">
                 <div class="header-logo pull-right pad-t10 pad-l40">
                 	<a href="<?php echo home_url() ?>">
                 		<span>صـــداستــارت آپ</span>
                 	</a>
                 </div>
                 <div class="header-menu pull-right">
                 	<nav class="main-menu">
                 		<?php wp_nav_menu( array( 'theme_location' => 'main-menu' , 'container' => false ) ) ?>
                 	</nav>
                 </div>
                 <div class="header-signup pull-left pad-10">
                 	<?php if(is_user_logged_in()){?>
                 		<a href="<?php echo wp_logout_url(home_url('')); ?>">
	             			<span class="font-s14 color-white">خروج</span>
	             		</a>
         			<?php }else{?>
         				<div class="pad-5 pull-right">
	         				<a href="/register">
		             			<span class="font-s14 color-white">ثبت نام</span>
		             		</a>
         				</div>
						<!--<div class="pad-5 pull-right">
							<a href="<?php echo home_url('/follow-up') ?>">
		             			<span class="font-s14 color-white pad-5">کد رهگیری</span>
		             		</a>
						</div>-->
						<div class="clearfix"></div>
 					<?php } ?>
                 </div>
                 <div class="clearfix"></div>
             </div>
	    </header>
<!-- Mobile -->
<div class="mobile hide bg-gray hide-mob">
	<div>
		<div class="header-right-mob pull-right relative">
	        <i class="color-white fa fa-bars vertical"></i>
	    </div>
	    <div class="align-center pull-right pad-10 ">
	    	<h3 class="color-purple font-s16"><?php bloginfo('name') ?></h3>
	    </div>
	    <div class="header-icon-mob pull-left align-center">
	    	<a class="color-darkgray" href="<?php echo home_url('/register') ?>">
	    		<i class="icon-user-plus vertical vertical"></i>
	    	</a>
	    </div>
	    <div class="clearfix"></div>
	</div>
    <div class="mobile-menu-right"> 
	    <div class="mobile-menu-logo align-center pad-t20 pad-b20">
	        <a href="<?php echo home_url() ?>">
	            <img alt="logo" height="40" src="<?php bloginfo('template_url') ?>/assets/images/logo.png" />
	        </a>
	        <h2 class="color-white font-s16 pad-t10"><?php bloginfo('name') ?></h2>
	    </div>
	    <div class="mobile-menu font-s13">
	        <?php  wp_nav_menu( array( 'theme_location' => 'main-menu', 'container' =>false ) ); ?>
	    </div>
	</div>
	<div class="mob-swipe-bg"></div>
    <div class="mobile-search hide">
        <form method="get" class="mobile-search-form" action="<?php echo home_url() ?>">
            <div class="mobile-site-search">
                <i class="icon-android-close search-close"></i>
                <div class="mobile-search-input-box">
                    <input class="mobile-search-input" name="s" type="search" placeholder="جستجو کنید ...">
                </div>
            </div>
        </form>
    </div>
</div>