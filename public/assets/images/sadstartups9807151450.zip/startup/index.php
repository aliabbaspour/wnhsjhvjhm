<?php
if(isset($_POST['submit_contact'])){
	$args_conte = array(
		'post_type'		=>'contactus',
		'post_title'	=>$_POST['first_name'],
		'post_content'	=>$_POST['description'],
		
	);
	$posts_id = wp_insert_post($args_conte);
	update_post_meta($posts_id,'email',$_POST['email']);
	
	wp_redirect(home_url('/?sent=1'));
}
?>
<?php get_header(); ?>
<?php get_template_part('content','intro') ?>
<?php //get_template_part('content','capital') ?>
<?php get_template_part('content','statistic') ?>
<?php get_template_part('content','advisor') ?>
<?php get_template_part('content','referee') ?>
<?php get_template_part('content','sendplan') ?>
<?php get_template_part('content','founder') ?>
<?php get_template_part('content','support') ?>
<?php get_template_part('content','blog') ?>
<?php get_template_part('content','contact') ?>
<?php get_footer(); ?>
<script>
jQuery(document).ready(function(){
	var uri = window.location.toString();
	if (uri.indexOf("?") > 0) {
	    var clean_uri = uri.substring(0, uri.indexOf("?"));
	    window.history.replaceState({}, document.title, clean_uri);
	}
});
</script>
