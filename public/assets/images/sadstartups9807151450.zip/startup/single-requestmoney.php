<?php
$user = wp_get_current_user();
$user_id = $user->ID;
$authro_id = $post->post_author ;
?>
<?php if(is_user_logged_in() && ($user_id == $authro_id || is_super_admin())){?>
<?php get_header() ?>
<?php get_header('admin') ?>
<?php the_post();?>
<div class="colm8 colm12-tab colm margin-auto spacer-t50">
	<div class="body-form relative">
		<div class="bg-chart4 body-form-top absolute flex-center">
			<div class="fa fa-money-check vertical font-s30 color-white"></div>
		</div>
		<div class="absolute title-panel">
			<h3 class="font-w300 font-s18">درخواست اعتبار</h3>
		</div>
		 <div class="pad-30"> 
		 	<div class="spacer-t30">
		 		<div class="font-s14 pad-10">
			 		<span>تاریخ : <?php the_time('Y/m/d H:i');?></span>
			 		<span class="pad-r30 pad-l30">مبلغ : <?php echo get_post_meta($post->ID,'request_money',true); ?></span>
			 		<span>موضوع : <?php echo get_post_meta($post->ID,'request_cat',true); ?></span>
			 	</div>
		 		<div class="pad-10">
		 		عنوان : <?php the_title(); ?>
			 	</div>
				<div class="pad-10">
					<h4>شرح در خواست : </h4>
					<?php the_content();?>
				</div>
		 	</div>
		</div>
	</div>	
</div>
<style>
    header , footer{
        display: none;
    }
</style>
<?php get_footer(); ?>
<?php get_footer('admin'); ?>
<?php }else{
    wp_redirect(home_url());
}?>