<?php /* Template Name: Profile */ ?>
<?php if(is_user_logged_in()){?>
<?php
$user 	 = wp_get_current_user();
$user_id = $user->ID;
?>
<?php

	$description = get_user_meta($user_id,'description',true);
	$first_name = get_user_meta($user_id,'first_name',true);
	$last_name = get_user_meta($user_id,'last_name',true);
	$number_phone = get_user_meta($user_id,'mobile',true);
	$email = get_user_meta($user_id,'email',true);
	$number_code = get_user_meta($user_id,'number_code',true);
	$phone = get_user_meta($user_id,'phone',true);
	
	
?>
<?php get_header(); ?>
<style>
</style>
<div class="container-fluid bg-gray pad-b25">
	<div class="container pad-5">
		<!---<div class="font-s20 align-center bold pad-t20">تکمیل اطلاعات</div>-->
			<div class="colm9 colm margin-auto">
				<div class="bg-white border-ra5 box-shaddow spacer-t10 pad-25">
					<nav class="form-steps pad-t15 pad-b15">
						<div class="form-steps__item form-steps__item--active">
							<div class="form-steps__item-content">
								<span class="form-steps__item-icon">
									<i class="icon-book vertical"></i>
								</span>
								<span class="form-steps__item-text">ارسال رزومه</span>
							</div>
						</div>
						<div class="form-steps__item form-steps__item--active">
							<div class="form-steps__item-content">
								<span class="form-steps__item-icon">
									<i class="icon-sitemap vertical"></i>
								</span>
								<span class="form-steps__item-line"></span>
								<span class="form-steps__item-text">انتخاب دسته</span>
							</div>
						</div>
						<div class="form-steps__item form-steps__item--active">
							<div class="form-steps__item-content">
								<span class="form-steps__item-icon">
									<i class="icon-cloud-upload vertical"></i>
								</span>
								<span class="form-steps__item-line"></span>
								<span class="form-steps__item-text">اپلود فایل</span>
							</div>
						</div>
						<div class="form-steps__item">
							<div class="form-steps__item-content">
								<span class="form-steps__item-icon">
									<i class="icon-check vertical"></i>
								</span>
								<span class="form-steps__item-line"></span>
								<span class="form-steps__item-text ">تایید نهایی</span>
							</div>
						</div>
					</nav>
					<div class="spacer-t30 spacer-b30">
						<div class="tagline"><span>ارسال رزومه</span></div>
					</div>	
						<form action="/upload" class="dropzone pad-20 " id="upload-video" enctype="multipart/form-data" method="post">
							<input name="user_id" value="<?php echo $user_id; ?>" class="hide" />
							<div class="frm-row pad-b20">
								<div class="colm6 colm pad-15 pull-right">
									<!--<label for="first-name" class="gui-label">نام :</label>-->
									<label class="relative">
										<span class="icon-gui"><i class="aligncenter color-blue icon-user vertical"></i></span>
										<input class="gui-input iransans valid" type="text" value="<?php echo $first_name; ?>" name="first_name" id="first-name" placeholder="نام" required="" >
									</label>
								</div>
								<div class="colm6 colm pad-15 pull-right">
									<!--<label for="last-name" class="gui-label">نام خانوادگی :</label>-->
									<label class="relative">
										<span class="icon-gui"><i class="aligncenter color-blue icon-user vertical"></i></span>
										<input class="gui-input iransans valid" type="text" value="<?php echo $last_name?>" name="last_name" id="last-name" placeholder="نام خانوادگی"  required="" >
									</label>
								</div>
								<div class="clearfix"></div>
							</div>
							
							<div class="frm-row pad-b20">
								<div class="colm6 colm pad-15 pull-right">
									<!---<label for="number-phone" class="gui-label">شماره همراه :</label>-->
									<label class="relative">
										<span class="icon-gui"><i class="aligncenter color-blue icon-phone vertical"></i></span>
										<input class="gui-input iransans valid" type="text" value="<?php echo $number_phone; ?>" name="number_phone" id="number-phone" placeholder="شماره همراه" required="">
									</label>
								</div>
								<div class="colm6 colm pad-15 pull-right">
									<!--<label for="email" class="gui-label">ایمیل :</label>-->
									<label class="relative">
										<span class="icon-gui"><i class="aligncenter color-blue icon-naslenoor-19 vertical"></i></span>
										<input class="gui-input iransans valid" type="email" value="<?php echo $email ?>" name="email" id="email" placeholder="ایمیل"  required="" >
									</label>
								</div>
								<div class="clearfix"></div>
							</div>
							
							<div class="frm-row pad-b20">
								<div class="colm6 colm pad-15 pull-right">
									<!---<label for="number-code" class="gui-label">کد ملی :</label>-->
									<label class="relative">
										<span class="icon-gui"><i class="aligncenter color-blue icon-street-view vertical"></i></span>
										<input class="gui-input iransans valid" type="text" value="<?php echo $number_code; ?>" name="number_code" id="number-code" placeholder="کد ملی" required="">
									</label>
								</div>
								<div class="colm6 colm pad-15 pull-right">
									<!---<label for="phone" class="gui-label">تلفن ثابت :</label>--->
									<label class="relative">
										<span class="icon-gui"><i class="aligncenter color-blue icon-naslenoor-21 vertical"></i></span>
										<input class="gui-input iransans valid" type="text" value="<?php echo $phone; ?> " name="phone" id="phone" placeholder="تلفن ثابت"  required="" >
									</label>
								</div>
								<div class="clearfix"></div>
							</div>
							<div class="frm-row">
								<div class="pad-15">
									<!---<label for="description" class="gui-label">توضیحات :</label>--->
									<label>
										<textarea id="description" name="description" placeholder="توضیحات"><?php echo $description; ?></textarea>
									</label>
								</div>
							</div>
							
							<div class="frm-row">
								<div class="colm6 colm pull-right pad-15">
									<div class="">
										<div id="video-preview" class="align-center"></div>
										<input type="text" class="hide" name="user_id" value="<?php echo $user_id; ?>" />
										<input type="hidden" name="festival_id" value="<?php echo $user_id; ?>" />
										<div class="dz-message dz-message" data-dz-message>
											<span class="font-s14 font-w300">برای بارگذاری کلیک کنید</span>
										</div>
									</div>
								</div>
								<div class="colm6 colm pull-right pad-15">
									<div class="">
										<div id="video-preview1" class="align-center"></div>
										<input type="text" class="hide" name="user_id" value="<?php echo $user_id; ?>" />
										<input type="hidden" name="festival_id" value="<?php echo $user_id; ?>" />
										<div class="dz-message dz-message1" data-dz-message>
											<span class="font-s14 font-w300">برای بارگذاری کلیک کنید</span>
										</div>
									</div>
								</div>
								<!---<div class="colm6 colm pull-right pad-15">
									<div class="">
										<div id="video-preview" class="align-center"></div>
										<input type="text" class="hide" name="user_id" value="<?php //echo $user_id; ?>" />
										<input type="hidden" name="festival_id" value="<?php //echo $id ?>" />
										<div class="dz-message dz-message" data-dz-message>
											<span class="font-s14 font-w300">برای بارگذاری کلیک کنید</span>
										</div>
									</div>
								</div>--->
								<div class="clearfix"></div>
							</div>
							<div class="pad-5 align-left spacer-t10">
				     			<button type="submit" name="submit" class="btn-web send-video pointer" id="send-video">مرحله بعد </button>
							</div>
							
						</form>
				</div>
			</div>
	</div>
</div>

								
<?php if($_GET['sent']==1):?>
<div class="message-producer pad-20 spacer-b25 color2 align-center message-css">
    <div class="wpulike-notification msg-profile">
    	<div class="wpulike-message wpulike-success">اطلاعات شما با موفقیت ثبت شد.</div>
	</div>
</div>
<?php endif ?>
<?php get_footer(); ?>
<?php }else{
	wp_redirect(home_url('/register'));
}?>
<script>
jQuery(document).ready(function($) {
	Dropzone.prototype.defaultOptions.dictFallbackMessage = "مرورگر شما آپلود فایل drag'n'drop را پشتیبانی نمی کند.";
	Dropzone.prototype.defaultOptions.dictFallbackText = "Please use the fallback form below to upload your files like in the olden days.";
	Dropzone.prototype.defaultOptions.dictFileTooBig  = "فایل خیلی بزرگ است ({{filesize}}MB). حداکثر اندازه فایل: {{maxFilesize}}MB.";
	Dropzone.prototype.defaultOptions.dictInvalidFileType  = "شما مجاز به بارگذاری این نوع فایل نیستید";
	Dropzone.prototype.defaultOptions.dictResponseError  = "Server responded with {{statusCode}} code.";
	Dropzone.prototype.defaultOptions.dictCancelUpload  = "انصراف بارگذاری";
	Dropzone.prototype.defaultOptions.dictCancelUploadConfirmation  = "آیا مطمئن هستید که میخواهید این بارگذاری را لغو کنید؟";
	Dropzone.prototype.defaultOptions.dictRemoveFile = "حذف فایل";
	Dropzone.prototype.defaultOptions.dictRemoveFileConfirmation = null;
	Dropzone.prototype.defaultOptions.dictMaxFilesExceeded = "شما فقط می توانید {{maxFiles}} فایل بارگذاری کنید  .";
		Dropzone.prototype.defaultOptions.dictDefaultMessage = "برای بارگذاری فایل کلیک کنید";
		
		
		Dropzone.options.uploadVideo = {
			autoProcessQueue: false,
			maxFiles: 1,
			maxFilesize: 10, // MB
			paramName: "video",
			addRemoveLinks: true,
			previewsContainer: '#video-preview',
			acceptedFiles: '.png',
			init: function() {
				var self = this;
				self.on("maxfilesexceeded", function(file) {
					self.removeAllFiles();
					self.addFile(file);
				});
				$("#send-video").click(function (e) {
		            e.preventDefault();
		            self.processQueue();
		            $("#upload-video .dz-remove").remove();
		        });
		        self.options.dictRemoveFile = "حذف";
		        self.on("addedfile", function (file) {
					$("#upload-video .dz-message").hide();
				});
		        self.on("removedfile", function (file) {
					$("#upload-video .dz-message").show();
				});
			}
		}
		
});
</script>
<script>
jQuery(document).ready(function(){
	var uri = window.location.toString();
	if (uri.indexOf("?") > 0) {
	    var clean_uri = uri.substring(0, uri.indexOf("?"));
	    window.history.replaceState({}, document.title, clean_uri);
	}
});
</script>