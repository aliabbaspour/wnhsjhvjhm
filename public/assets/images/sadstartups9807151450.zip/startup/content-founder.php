<div id="content-advisor" class="container-fluid">
	<div class="container">
		<div class="pad-t40 pad-b40 relative">
			
			<div class="illustrator-bg absolute hidden-xs">
				<img width="145" src="<?php bloginfo('template_url') ?>/assets/images/ill.png" />
			</div>
			
			<div class="align-center pad-b30">
				<h5 class="font-s21 color-purple pad-b13">
					<span class="font-w500">آکادمی صد استارت آپ</span>
				</h5>
				<h5 class="font-s13 color6 academi-txt pad-b13">
					<span class="relative">موسسین صداستارت آپ</span>
				</h5>
			</div>
			
			<div class="colm9 colm margin-auto">
				<div class="advisor-body">
					<?php $args = array( 'showposts' => 3 , 'post_type' => 'advisor' ) ?>
					<?php query_posts($args) ?>
					<?php while(have_posts()):the_post() ?>
						<div class="colm4 colm pull-right pad-20 align-center">
							<div class="pad-20 academi-inner">
								<div class="academi-img">
									<?php the_post_thumbnail('thumbnail') ?>
								</div>
								<div class="font-s17 color3 pad-t20 pad-b5 font-w500">
									<?php the_title() ?>
								</div>
								<div class="academi-excerpt font-s12 color6">
									<?php the_excerpt() ?>
								</div>
							</div>
						</div>
					<?php endwhile;wp_reset_query() ?>
					<div class="clearfix"></div>
				</div>
			</div>
			
		</div>
	</div>
</div>