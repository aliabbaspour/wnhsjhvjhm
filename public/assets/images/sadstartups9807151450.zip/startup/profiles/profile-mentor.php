<?php
$user_id    = get_query_var('id_m');
$firstname  = get_user_meta($user_id,'first_name',true);
$lastname   = get_user_mata($user_id,'last_name',true);
$email      = get_user_meta($user_id,'user_email',true);
?>

<?php get_header() ?>
<style>
    .max-wprofile{
        height: 140px;
        overflow: hidden;
    }
</style>
<div id="content-view2" class="container-fluid relative">
    <div class="blur"></div>
    <div class="view-text baner baner colm5  colm absolute">
		<span class="bold color-white pad-b15">
			صد استارت آپ
		</span>
        <p class="color-white font-s14 align-justify">
            ۲۰ میلیارد تومان سرمایه‌گذاری
            بر روی استارتاپ‌های برنده
            <br />
            ایده خلاقانه و موفقی دارید؟

        </p>
    </div>
</div>
<div class="container-fluid bg-gray">
    <div class="container" style="min-height: 500px">
        <div class="colm3 colm pull-right wow fadeIn" data-wow-duration="2s">
            <div class="body-view-right bg-white margin-auto">
                <div class="pad-b18  pad-t18 border-view">
                    <div class="btn-view2 colm11 colm margin-auto align-center">
                        <a class="color-white" href="#">سوالی بپرسید</a>
                    </div>
                </div>
                <div class="border-view">
                    <div class="body-view-bottom">
                        <div class="pad-20">
                            <div class="colm6 colm pull-right box-view box-view2 right pad-15 align-center">
                                <span class="font-s12 color-startup spacer-b5 display-block font-w400">استارت آپ</span>
                                <span class="font-s18 bold">100</span>
                            </div>
                            <div class="colm6 colm pull-right box-view box-view2 left pad-15 align-center">
                                <span class="font-s12 color-investor spacer-b5 display-block font-w400">سرمایه گذار</span>
                                <span class="font-s18 bold">20</span>
                            </div>
                            <div class="colm6 colm pull-right box-view box-view2 right pad-15 align-center font-w400">
                                <span class="font-s12 color-investor spacer-b5 display-block">کاربران</span>
                                <span class="font-s18 bold">237</span>
                            </div>
                            <div class="colm6 colm pull-right box-view box-view2 left pad-15 align-center font-w400">
                                <span class="font-s12 color-mentor spacer-b5 display-block">منتور</span>
                                <span class="font-s18 bold">150</span>
                            </div>
                            <div class="clearfix"></div>
                        </div>
                    </div>
                </div>
                <div class="border-view">
                    <div class="body-view-bottom">
                        <div class="">
                            <div class="bg-white">
                                <div class="border-information pad-15">
                                    <span class="color-green font-s14 font-w400">نام و نام خانوادگی:</span>
                                    <span class="color6 font-s13 pad-r10"><?php echo $firstname.' '.$lastname; ?></span>
                                </div>
                            </div>
                            <div class="bg-white">
                                <div class="border-information pad-15">
                                    <span class="color-green font-s14 font-w400">حوزه فعالیت:</span>
                                    <span class="color6 font-s13 pad-r10">منتورینگ</span>
                                </div>
                            </div>
                            <div class="bg-white">
                                <div class="border-information pad-15">
                                    <span class="color-green font-s14 font-w400">تاریخ عضویت:</span>
                                    <span class="color6 font-s13 pad-r10">1397/10/21</span>
                                </div>
                            </div>
                            <div class="bg-white">
                                <div class="border-information pad-15">
                                    <span class="color-green font-s14 font-w400">تحصیلات:</span>
                                    <span class="color6 font-s13 pad-r10">فوق لیسانس</span>
                                </div>
                            </div>
                            <div class="bg-white">
                                <div class="border-information pad-15">
                                    <span class="color-green font-s14 font-w400">تخصص:</span>
                                    <span class="color6 font-s13 pad-r10">نرم افزار</span>
                                </div>
                            </div>
                            <div class="bg-white">
                                <div class="border-information pad-15">
                                    <span class="color-green font-s14 font-w400">محل استقرار:</span>
                                    <span class="color6 font-s13 pad-r10">تهران</span>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
        <div class="colm7 colm pull-right wow fadeIn" data-wow-duration="2s">
            <div class="bg-white body-view-center">
                <div class="pad-9 border-view border-view2 relative">
                    <!--<div class="pull-right">
                        <div class="logo-view"></div>
                    </div>-->
                    <div class="pull-right border-h">
                        <h2 class="font-s20 color-green">منتور</h2>
                    </div>
                    <div class="clearfix"></div>
                </div>
                <div class="border-view">
                    <div class="font-s14 align-justify pad-25 color-green">
                        <p class="font-w300 max-wprofile">
                            اگرچه کلیت این فعالیت ها، مربوط به امروز و دیروز نیست و از سالیان پیش، اقدامات به صورت فردی،
                            با گسترش تدریجی فضای کارآفرینی نوآوری محور در کشور عزیزمان، مفاهیم و ساختارهای نوینی در حال شکل گیری و ایفای نقش می باشند. اگرچه کلیت این فعالیت ها، مربوط به امروز و دیروز نیست و از سالیان پیش، اقدامات به صورت فردی،  اگرچه کلیت این فعالیت ها، مربوط به امروز و دیروز نیست و از سالیان پیش، اقدامات به صورت فردی، محدود و جسته و گریخته شروع شده بود اما در یک سال اخیر است که شاهد فعالیت های منسجم و ساختار یافته در این زمینه هستیم.
                            اگرچه کلیت این فعالیت ها، مربوط به امروز و دیروز نیست و از سالیان پیش، اقدامات به صورت فردی،
                            مرکز شتابدهی فناوری TAC در نتیجه همفکری، تفاهم و همکاری بزرگان صنعت فناوری اطلاعات و ارتباطات ایران، و فعالین و متخصصان کارآفرینی دانش بنیان و نوآوری محور، از بهار ۱۳۹۴ فعالیت خود را آغاز کرد. این مرکز در نتیجه جلسات مهم و ارزشمند داوری، ۵ گروه از بهترین و خوشفکرترین جوانان کشور را جهت ارائه حمایت های مادی و معنوی خود در اولین دوره شتابدهی که از ابتدای آذر ۹۴ شروع شده، پذیرفته است.
                            اگرچه کلیت این فعالیت ها، مربوط به امروز و دیروز نیست و از سالیان پیش، اقدامات به صورت فردی
                            اگرچه کلیت این فعالیت ها، مربوط به امروز و دیروز نیست و از سالیان پیش، اقدامات به صورت فردی، ،
                            در این مدت، از زمان آغاز به کار رسمی این مرکز تا کنون، تماس ها، پرسش ها و گپ و گفت های متعددی با علاقمندان انجام شده است. به علت عدم وجود منابع اطلاعاتی و آموزشی کافی تصمیم گرفتیم تا در وبلاگ TAC به مرور مطالب کلیدی و دانش عملیاتی مرتبط با حوزه فعالیت مراکز شتابدهی ارائه نماییم تا علاقمندان گرامی یک خوانش یکدست، ساده و صحیح را از موضوعات گاها پیچیده و کمتر بحث شده را داشته باشند.
                        </p>
                    </div>
                </div>
            </div>
        </div>

        <div class="colm2 colm pull-right wow fadeIn" data-wow-duration="2s">
            <div class="margin-auto pad-t50">
                <a href="#" class="color-green">
					<span class="font-s20 pad-l5">
						<i class="fa fa-home vertical"></i>
					</span>
                    <span class="font-s14">صفحه اصلی</span>
                </a>
                <a href="#" class="display-block spacer-b20 color-icon hover-icon2">
					<span class="font-s20 pad-l5">
						<i class="fa fa-at vertical"></i>
					</span>
                    <span class="font-s14"><?php echo $email; ?></span>
                </a>
                <div class="spacer-b20 color-icon">
                    <div class="hover-icon2">
						<span class="font-s20 pad-l5">
							<i class="fa fa-globe-americas vertical"></i>
						</span>
                        <span class="font-s14">شبکه مجازی صد استارت آپ</span>
                    </div>
                    <a href="#" class="color-icon-social pad-r25 hover-social">
						<span class="font-s18 pad-l5">
							<i class="fab fa-instagram vertical"></i>
						</span>
                        <span class="font-s13">instagram</span>
                    </a>
                    <a href="#" class="display-block color-icon-social pad-r25 hover-social">
						<span class="font-s18 pad-l5">
							<i class="fab fa-linkedin-in vertical"></i>
						</span>
                        <span class="font-s13">linkedin</span>
                    </a>
                    <a href="#" class="display-block color-icon-social pad-r25 hover-social">
						<span class="font-s18 pad-l5">
							<i class="fab fa-telegram-plane vertical"></i>
						</span>
                        <span class="font-s13">telegram</span>
                    </a>
                    <a href="#" class="display-block color-icon-social pad-r25 hover-social">
						<span class="font-s18 pad-l5">
							<i class="fab fa-twitter vertical"></i>
						</span>
                        <span class="font-s13">twitter</span>
                    </a>
                </div>
            </div>
        </div>

        <div class="clearfix"></div>
    </div>
</div>

<?php get_footer() ?>
<script>
    new WOW().init();
</script>