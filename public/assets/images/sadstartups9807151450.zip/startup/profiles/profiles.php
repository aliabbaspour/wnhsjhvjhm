<?php /* template name: profiles   */ ?>
<?php
$user_id = get_query_var('id_m');
$roles = get_user_meta($user_id,'roles',true);
$user = get_userdata( $user_id );
$user_role = $user->roles;
$allowed_coach = array('coach');
$allowed_investor = array('investor');
?>
<?php get_template_part('profiles/profile','startup');?>


<?php /* if (in_array('subscriber' , $user_role)) {?>
    <?php get_template_part('profiles/profile','startup');?>
<?php }?>
<?php if (in_array('managers' , $user_role)) {?>
    <?php get_template_part('profiles/profile','investor');?>
<?php }?>
<?php  if (array_intersect($allowed_investor, $roles)) {?>
    <?php get_template_part('profiles/profile','investor');?>
<?php } */?>







