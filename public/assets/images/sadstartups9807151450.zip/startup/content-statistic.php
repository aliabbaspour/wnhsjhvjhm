<div id="content-statistic" class="container-fluid bg-gray">
	<div class="container">
		<div class="pad-t40 pad-b40">
			<div class="colm3 colm pull-right align-center pad-10">
				<div>
					<img width="60" src="<?php bloginfo('template_url') ?>/assets/images/submit.svg" />
				</div>
				<div class="static-text pad-t15 pad-b15 font-s17">
					<span class="font-w500 color6">تعداد طرح ارسالی</span>
				</div>
				<div class="static-num">
					<span class="font-s30 bold color-purple">426</span>
				</div>
			</div>
			<div class="colm3 colm pull-right align-center pad-10">
				<div>
					<img width="60" src="<?php bloginfo('template_url') ?>/assets/images/support.svg" />
				</div>
				<div class="static-text pad-t15 pad-b15 font-s17">
					<span class="font-w500 color6">تعداد سرمایه گذار</span>
				</div>
				<div class="static-num">
					<span class="font-s30 bold color-purple">1728</span>
				</div>				
			</div>
			<div class="colm3 colm pull-right align-center pad-10">
				<div>
					<img width="60" src="<?php bloginfo('template_url') ?>/assets/images/mentor.svg" />
				</div>
				<div class="static-text pad-t15 pad-b15 font-s17">
					<span class="font-w500 color6">تعداد منتور</span>
				</div>
				<div class="static-num">
					<span class="font-s30 bold color-purple">657</span>
				</div>				
			</div>
			<div class="colm3 colm pull-right align-center pad-10">
				<div>
					<img width="60" src="<?php bloginfo('template_url') ?>/assets/images/success.svg" />
				</div>
				<div class="static-text pad-t15 pad-b15 font-s17">
					<span class="font-w500 color6">طرح پذیرفته شده</span>
				</div>
				<div class="static-num">
					<span class="font-s30 bold color-purple">390</span>
				</div>				
			</div>
			<div class="clearfix"></div>			
		</div>
	</div>
</div>