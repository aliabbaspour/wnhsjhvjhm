<?php
$user_id  = get_query_var( 'id_m');
$status_referee		= get_user_meta($user_id,'status_referee',true);
$datar = array(
		'query'=>array(
			array(
				'key'=>'user_id',
				'value'=>$user_id,
				'compare'=>'='
			)
		)
	);
	$data_referee = query_data('referee',$datar);

	$score_full =$data_referee[3]->score_full;
	$score_coordination = $data_referee[3]->score_coordination;
	$score_ability = $data_referee[3]->score_ability;
	$score_market = $data_referee[3]->score_market;
	$score_growth = $data_referee[3]->score_growth;
	$score_competition = $data_referee[3]->score_competition;
	$score_targetmarket = $data_referee[3]->score_targetmarket;
	$score_suggestedvalue = $data_referee[3]->score_suggestedvalue;
	$score_mvp = $data_referee[3]->score_mvp;
	$score_transparency = $data_referee[3]->score_transparency;
	$score_advantage = $data_referee[3]->score_advantage;
	$score_strategy = $data_referee[3]->score_strategy;
	$score_comment = $data_referee[3]->score_comment;
	$score_precise = $data_referee[3]->score_precise;
	$scorestatus=$data_referee[3]->scorestatus;
	$vote1=(($score_full+$score_coordination+$score_ability)/3*35)/100; 
	$vote2=(($score_market+$score_growth+$score_competition)/3*20)/100;
	$vote3=(($score_targetmarket+$score_suggestedvalue+$score_mvp+$score_transparency+$score_advantage+ $score_strategy)/6*35)/100;
	$vote4=(($score_precise)/1*10)/100;
	$totoal_score4 = $vote1+$vote2+$vote3+$vote4;

?>
<style>
	input[type='range']{
		cursor: context-menu;
	} 
	.cursor-auto{
		cursor: context-menu;
	}
</style>
	<?php if($scorestatus == "failed"): ?>
		<div class="alert alert-rose alert-with-icon colm7 margin-auto colm flex-center">
			<div class="flex-center-row"><i class="fa fa-times pad-l5"></i>این تیم توسط داور رد شده است.</div>
		</div>
	<?php elseif($scorestatus == "accepted"): ?>
		<div class="alert alert-success alert-with-icon colm7 margin-auto colm flex-center">
			<div class="flex-center-row"><i class="fa fa-check pad-l5"></i>این تیم توسط داور تایید شده است.</div>
		</div>
	<?php endif ?>
<div>
	<h4 class="font-w300 font-s16 spacer-t30">تیم</h4>
	<div class="colm12 colm frm-row slidecontainer  pad-5 pad-t20">
	<div class="colm4 colm pad-10 ">
		<label for="breadth_store" class="gui-label pad-5 cursor-auto">کامل بودن تیم</label>
		<div class="rate-part">
	 	  <input type="range" min="1" max="5" value="<?php if($score_full){echo $score_full;}else{echo 0;}?>" class="renge cursor-auto" disabled name="score_full" id="myid">
		  <p class="font-s11">امتیاز: <?php if($score_full){echo $score_full;}else{echo 0;}?></p>
		</div>
	</div>
	<div class="colm4 colm pad-10"> 
		<label for="breadth_store" class="gui-label pad-5 cursor-auto">هماهنگی و انسجام اعضا </label>
		<div class="rate-part">
	 	  <input type="range" min="1" max="5" value="<?php if($score_coordination){echo $score_coordination;}else{echo 0;} ?>" class="renge cursor-auto" disabled name="score_coordination" id="myRange2">
		  <p class="font-s11">امتیاز: <?php if($score_coordination){echo $score_coordination;}else{echo 0;} ?></p>
		</div>
	</div>
	<div class="colm4 colm pad-10">
		<label for="breadth_store" class="gui-label pad-5 cursor-auto">توانمندی تیم برای اجرای این کسب‌وکار</label>
		<div class="rate-part">
	 	  <input type="range" min="1" max="5" value="<?php  if($score_ability){echo $score_ability;}else{echo 0;} ?>" class="renge cursor-auto" disabled name="score_ability" id="myRange3">
		  <p class="font-s11">امتیاز: <?php if($score_ability){echo $score_ability;}else{echo 0;} ?></p>
		</div>
	</div>
	</div>
	<hr>
	<h4 class="font-w300 font-s16 spacer-t10">بازار</h4>
	<div class="colm12 colm frm-row pad-5 pad-t20 slidecontainer">
	<div class="colm4 colm pad-10">
		<label for="breadth_store" class="gui-label pad-5 cursor-auto">اندازه بازار</label>
		<div class="rate-part">
			<input type="range" min="1" max="5" value="<?php  if($score_market){echo $score_market;}else{echo 0;}?>" class="renge cursor-auto" disabled name="score_market" id="myrange4">
			<p class="font-s11">امتیاز:<?php if($score_market){echo $score_market;}else{echo 0;} ?></p>
		</div>
	</div>
	<div class="colm4 colm pad-10">
		<label for="breadth_store" class="gui-label pad-5 cursor-auto">پتانسیل رشد بازار</label>
		<div class="rate-part">
			<input type="range" min="1" max="5" value="<?php  if($score_growth){echo $score_growth;}else{echo 0;} ?>" class="renge cursor-auto" disabled name="score_growth" id="myrange5">
			<p class="font-s11">امتیاز:<?php if($score_growth){echo $score_growth;}else{echo 0;}?></p>
		</div>
	</div>
	<div class="colm4 colm pad-10">
		<label for="breadth_store" class="gui-label pad-5 cursor-auto">شدت فضای رقابتی بازار هدف</label>
		<div class="rate-part">
			<input type="range" min="1" max="5" value="<?php if($score_competition){echo $score_competition;}else{echo 0;}?>" class="renge cursor-auto" disabled name="score_competition" id="myrange6">
			<p class="font-s11">امتیاز:<?php if($score_competition){echo $score_competition;}else{echo 0;} ?></p>
		</div>
	</div>
</div>
	<hr>
	<h4 class="font-w300 font-s16 spacer-t10">مدل کسب و کار </h4>
	<div class="colm12 colm frm-row pad-5 pad-t20 slidecontainer">
	<div class="colm4 colm pad-10">
		<label for="breadth_store" class="gui-label pad-5 cursor-auto">بخش‌بندی مشخص و شفاف مشتریان</label>
		<div class="rate-part">
			<input type="range" min="1" max="5" value="<?php  if($score_targetmarket){echo $score_targetmarket;}else{echo 0;} ?>" class="renge cursor-auto" disabled name="score_targetmarket" id="myrange4">
			<p class="font-s11">امتیاز:<?php if($score_targetmarket){echo $score_targetmarket;}else{echo 0;} ?></p>
		</div>
	</div>
	<div class="colm4 colm pad-10">
		<label for="breadth_store" class="gui-label pad-5 cursor-auto">ارزش پیشنهادی مشخص و ملموس </label>
		<div class="rate-part">
			<input type="range" min="1" max="5" value="<?php if($score_suggestedvalue){echo $score_suggestedvalue;}else{echo 0;} ?>" class="renge cursor-auto" disabled name="score_suggestedvalue" id="myrange5">
			<p class="font-s11">امتیاز:<?php if($score_suggestedvalue){echo $score_suggestedvalue;}else{echo 0;} ?></p>
		</div>
	</div>
	<div class="colm4 colm pad-10">
		<label for="breadth_store" class="gui-label pad-5 cursor-auto">کیفیت MVP</label>
		<div class="rate-part">
			<input onchange="" type="range" min="1" max="5" value="<?php if($score_mvp){echo $score_mvp;}else{echo 0;} ?>" class="renge cursor-auto" disabled name="score_mvp" id="myrange6">
			<p class="font-s11">امتیاز:<?php if($score_mvp){echo $score_mvp;}else{echo 0;} ?></p>
		</div>
	</div>
</div>
<div class="colm12 colm frm-row pad-5 pad-t20 slidecontainer">
	<div class="colm4 colm pad-10">
		<label for="breadth_store" class="gui-label pad-5 cursor-auto">شفاف بودن جریان‌های درآمدی </label>
		<div class="rate-part">
			<input type="range" min="1" max="5" value="<?php if($score_transparency){echo $score_transparency;}else{echo 0;} ?>" class="renge cursor-auto" disabled name="score_transparency" id="myrange4">
			<p class="font-s11">امتیاز:<?php if($score_transparency){echo $score_transparency;}else{echo 0;} ?></p>
		</div>
	</div>
	<div class="colm4 colm pad-10">
		<label for="breadth_store" class="gui-label pad-5 cursor-auto">داشتن مزیت رقابتی</label>
		<div class="rate-part">
			<input type="range" min="1" max="5" value="<?php  if($score_advantage){echo $score_advantage;}else{echo 0;} ?>" class="renge cursor-auto" disabled name="score_advantage" id="myrange4">
			<p class="font-s11">امتیاز:<?php if($score_advantage){echo $score_advantage;}else{echo 0;} ?></p>
		</div>
	</div>
	<div class="colm4 colm pad-10">
		<label for="breadth_store" class="gui-label pad-5 cursor-auto">داشتن استراتژی ورود به بازار</label>
		<div class="rate-part">
			<input type="range" min="1" max="5" value="<?php  if($score_strategy){echo $score_strategy;}else{echo 0;} ?>" class="renge cursor-auto" disabled name="score_strategy" id="myrange6">
			<p class="font-s11">امتیاز:<?php if($score_strategy){echo $score_strategy;}else{echo 0;} ?></p>
		</div>
	</div>
</div>
<hr>
	<h4 class="font-w300 font-s16 spacer-t10">کیفیت مستندات ارسالی </h4>
	<div class="colm12 colm frm-row pad-5 pad-t20 slidecontainer">
		<div class="colm4 colm pad-10">
			<label for="breadth_store" class="gui-label pad-5 cursor-auto">کامل و دقیق بودن مستندات</label>
			<div class="rate-part">
				<input type="range" min="1" max="5" value="<?php  if($score_precise){echo $score_precise;}else{echo 0;}  ?>" class="renge cursor-auto" disabled name="score_precise" id="myrange6">
				<p class="font-s11">امتیاز:<?php  if($score_precise){echo $score_precise;}else{echo 0;}?></p>
			</div>
		</div>
	</div>
	<hr>
	<h4 class="font-w300 font-s16 spacer-t10">نظر داور</h4>
	<div class="pad-t30">
		<div class="gui-textarea sans-digit"><?php  echo $score_comment; ?></div>
	</div>                          
</div>