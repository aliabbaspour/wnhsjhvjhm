<?php get_header(); ?>
<div class="container-fluid">
    <div class="container">
    	<h3 class="">
			<?php the_archive_title() ?>  
		</h3>
		<?php while(have_posts()):the_post()?>
			<div class="colm col4m4 pull-right">
				<div class="responsive">
					<?php the_post_thumbnail('medium')?>
				</div>
				<div><?php the_title()?></div>
			</div>
		<?php endwhile ?>
		<div class="clearfix"></div>
		<div class="paging"><?php if (function_exists("pagination")) { pagination($additional_loop->max_num_pages);} ?></div>
    </div>
</div>
<?php get_footer(); ?>