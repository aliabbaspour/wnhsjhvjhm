<?php //Template Name: test chart  ?>
<?php get_header() ?>
<?php get_header('admin') ?>
<style>
	header , footer{
		display: none;
	}
#chartdiv {
    width: 100%;
    height: 330px;
    margin: 0 auto;
    padding-top: 60px;
	font-size: 12px;
}
.chart-panel {
    width: 90%;
    top: -20px;
    left: 0px;
    right: 0px;
    margin: 0 auto;
    height: 75px;
    border-radius: 3px;
    transition: all 0.3s cubic-bezier(0.34, 1.61, 0.7, 1);
}
</style>
	<div class="frm-row pad-t40 ">
		<div>
			<div class="colm6 colm pull-right pad-15 wow slideInLeft" data-wow-duration="1.5s">
				<div class=" body-form height320 pad-15 relative">
					<div class="magin-auto absolute content-ch pad-20 ">
						<div id="chartdiv"></div>
					</div>
					<div class="bg-chart1 chart-panel magin-auto absolute pad-20 color-white">
						<h3 class="font-w300 font-s18">بازدید روزانه</h3>
						<h3 class="colm12 colm font-w200 font-s14">آمار بازدید روزانه سایت </h3>
					</div>
				</div>
			</div>
			<div class="clearfix"></div>
		</div>
	</div>


<?php get_footer('admin'); ?>
<?php get_footer(); ?>
<script src="https://www.amcharts.com/lib/4/core.js"></script>
<script src="https://www.amcharts.com/lib/4/charts.js"></script>
<script src="https://www.amcharts.com/lib/4/themes/animated.js"></script>

<script>
am4core.ready(function() {

// Themes begin
am4core.useTheme(am4themes_animated);
// Themes end

/* Create chart instance */
var chart = am4core.create("chartdiv", am4charts.RadarChart);

/* Add data */
chart.data = [ {
  "direction": "N",
  "value": 8
}, {
  "direction": "NE",
  "value": 9
}, {
  "direction": "E",
  "value": 4.5
}, {
  "direction": "SE",
  "value": 3.5
}, {
  "direction": "S",
  "value": 9.2
}, {
  "direction": "SW",
  "value": 8.4
}, {
  "direction": "W",
  "value": 11.1
}, {
  "direction": "NW",
  "value": 10
} ];

/* Create axes */
var categoryAxis = chart.xAxes.push(new am4charts.CategoryAxis());
categoryAxis.dataFields.category = "direction";

var valueAxis = chart.yAxes.push(new am4charts.ValueAxis());
//valueAxis.renderer.gridType = "polygons";

var range = categoryAxis.axisRanges.create();
range.category = "NW";
range.endCategory = "NW";
range.axisFill.fill = am4core.color("#0066CC");
range.axisFill.fillOpacity = 0.3;

var range2 = categoryAxis.axisRanges.create();
range2.category = "N";
range2.endCategory = "N";
range2.axisFill.fill = am4core.color("#0066CC");
range2.axisFill.fillOpacity = 0.3;

var range3 = categoryAxis.axisRanges.create();
range3.category = "SE";
range3.endCategory = "SW";
range3.axisFill.fill = am4core.color("#CC3333");
range3.axisFill.fillOpacity = 0.3;
range3.locations.endCategory = 0;

/* Create and configure series */
var series = chart.series.push(new am4charts.RadarSeries());
series.dataFields.valueY = "value";
series.dataFields.categoryX = "direction";
series.name = "Wind direction";
series.strokeWidth = 3;
series.fillOpacity = 0.2;

}); // end am4core.ready()
</script>