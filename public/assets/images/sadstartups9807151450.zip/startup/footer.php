            <footer>
                <div class="footer-bottom">
                    <div class="container">
                        <div class="pull-right font-s12 color-white">
                            © کلیه حقوق مادی و معنوی این سایت محفوظ می‌باشد.
                        </div>
                        <div class="clearfix"></div>
                    </div>
                </div>
            </footer> 
            <a rel="nofollow" id="scroll" class="scrollToTop color-white align-center font-s25 hide" href="#top">
                <i class="fa fa-chevron-up vertical"></i>
            </a>
          </div><!-- Wrapper -->
		<?php wp_footer(); ?>
		<?php
            $setting_analytics = get_option('setting_webpage_analytics');
            echo $setting_analytics; 
        ?>
<script>
jQuery(document).ready(function($) {
	$(function(){
    var current = location.pathname.slice(0, -1);;
    	$('#cssmenu li a').each(function(){
	        var $this = $(this);
        	if($this.attr('href').indexOf(current) !== -1){
	            $this.addClass('bg-dasboard');
	            if($this.parents().hasClass('has-sub')){
	        		$this.parents().eq(2).addClass('open');
	        		$this.parents().eq(1).show();
	        	}
	        }
	    })
	})
});
</script>
	</body>
</html>