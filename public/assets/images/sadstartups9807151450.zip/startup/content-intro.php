<div id="content-intro" class="container-fluid relative">
	<div class="intro-text colm5 colm absolute">
		<span class="bold color-white pad-b15">
			صد استارت آپ
		</span>
		<p class="color-white font-s14 align-justify">
۲۰ میلیارد تومان سرمایه‌گذاری
بر روی استارتاپ‌های برنده
<br />
ایده خلاقانه و موفقی دارید؟

		</p>
		<div class="btn-register font-s22 bold spacer-t25 align-center">
			<a class="color-white" href="<?php echo home_url('register') ?>">ارسال طرح و ایده</a>
		</div>
	</div>
</div>