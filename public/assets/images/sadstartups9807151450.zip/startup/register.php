<?php /* Template Name: Register  */?>
<?php
if(!is_user_logged_in()){
		session_start();
		$mobile = $_POST['mobile'];
		$_SESSION['register_id'] = $_GET['post_id'];
	if(isset($_POST['submit_mobile'])){
		$exists_mobile = mobile_exists( $mobile );
		if($exists_mobile!=-1){
			$user_id = $exists_mobile[0]->user_id;
			$mobile_verify = mt_rand(10000,99999);
			$message = "کدفعالسازی  $mobile_verify";
			$_SESSION['mobile_verify'] = $mobile_verify;
			send_sms($mobile,$message);
			$_SESSION['user_id'] = $user_id;
			wp_redirect(home_url('/register/?mobile=verify'));
		}else{
			$mobile_verify = mt_rand(10000,99999);
			$user_name = 'u'.randomString(8);
			$userdata  = array(
			    'user_login' =>  $user_name,
			    'user_pass'  =>  'mehrab'.$mobile_verify.'@0071', 
			);
			$user_id = wp_insert_user( $userdata );
			$_SESSION['user_id'] = $user_id;
			update_user_meta($user_id,'mobile',$mobile);
			update_user_meta($user_id,'mobile_verify',$mobile_verify); 
			$message = $mobile_verify;
			$_SESSION['mobile_verify'] = $mobile_verify;
			send_sms($mobile,$message);
			wp_redirect(home_url('/register/?mobile=verify'));
		}
	}elseif(isset($_POST['submit_verify'])){
		if($_SESSION['mobile_verify'] == $_POST['verify']){
			$user_id = $_SESSION['user_id'];
			$user = get_user_by( 'ID', $user_id );
			$user_login = $user->user_login;
			$mobile_verify = get_user_meta($user_id,'mobile_verify',true); 
			$userdata = array(
				'user_login' 	=> $user_login,
				'user_password' => 'mehrab'.$mobile_verify.'@0071',
			);
			$user = wp_signon( $userdata, false );
			if (!is_wp_error($user)) {
				wp_set_current_user($user -> ID);
				wp_set_auth_cookie($user -> ID);
			}
			$se_post_id = $_SESSION['register_id'];
			wp_redirect(home_url("/profile/"));
			session_unset();
		}else{
			wp_redirect(home_url('/register/?mobile=verify&very=eror'));
		}
	}
	
	
	$mobile_get = get_user_meta($_SESSION['user_id'],'mobile',true);
	if(isset($_POST['send_sms'])){
		$mobile_verify = mt_rand(10000,99999);
		$_SESSION['mobile_verify'] = $mobile_verify;
		$_SESSION['number_sms'] = $_SESSION['number_sms']+1;
		$message = "کدفعالسازی  $mobile_verify";
		send_sms($mobile_get,$message);
	}
?>
<?php get_header();?>
<style>
header , footer{
	display: none
}

</style>
<div class="container-fluide bg-red h100 pad-30 pad-0">
	<div class="container pad-t30">
		<div class="colm10 margin-auto box-shaddow-register border-ra10">
			<div class="colm6 colm pull-right bg-blue box-regiser-r pad-10">
				<div class="pad-20"></div>
				<form method="post" class="smart-validate">
				
				<div class="min-he300">
					<?php if(empty($_GET['mobile'])){?>
					<div class="align-right">
						<span class="bold show color-white align-center">ورود</span>
						<div class="spacer-t15 align-center">
							<span class="font-s13 color-silver color-white">لطفا شماره تلفن خود را وارد نمایید</span>
						</div>
					</div>
					<div class="spacer-t35  pad-0 pad-40">
						<div class="colm10 pull-right relative input-register">
							<label for="mobile" class="icon-right input-register">
								<input dir="ltr" type="text" name="mobile" placeholder="شماره همراه" data-rule-customphone="true" id="mobile" autofocus class="color-white bg-transparent digit font-s14 persian-digit englishnum number-input" autocomplete="off" required="">
							</label> 
						</div>
						<div class="colm2 pull-right relative input-register pad-r10">
							<label for="username" class="icon-right input-register">
								<input dir="ltr" class="digit font-s14 bg-transparent number-input  place-center" placeholder="+98" readonly>
							</label> 
						</div>
						
						<div class="clearfix"></div>
						
						<div class="register-head align-left pad-t30">
								<?php if(empty($_GET['mobile'])){?>
								<button type="submit" name="submit_mobile" class="dis-button btn-web iransans pad-15 bold">
									<span class="font-s17">مرحله بعد</span>
								</button>
								<?php }elseif($_GET['mobile']=='verify'){?>
									<button type="submit" name="submit_verify" class="iransans btn-web button-re pad-15 bold">
										<span class="font-s17">مرحله بعد</span>
									</button>
								<?php }?>
							</div>
					</div>
					<?php }elseif($_GET['mobile']=='verify'){?>
						<div class="align-center">
							<span class="bold show digit color-white"><?php echo $mobile_get; ?></span>
							<a href="<?php echo home_url('/register'); ?>" class="font-s13 color-white show">اصلاح شماره</a>
							<div class="spacer-t15">
								<span class="font-s13 color-white show">کد فعال سازی به گوشی شما ارسال شد. </span>
								<span class="font-s13 color-white show pad-t10">لطفا کد ارسالی را وارد نمایید.</span>
							</div>
						</div>
						
						<div class="spacer-t25 pad-0 pad-40 ">
							<div class="align-center">
								
									<span id="timer" class="digit color-white hide-timer"></span>
									<span class="font-s13 color-white send-sms pointer hide">ارسال مجدد پیام</span>
							</div>
							
							<div class="relative input-register spacer-t10">
								<label for="verify" class="icon-right input-register">
									<input dir="ltr" type="text" name="verify" id="verify" maxlength="5" class="digit bg-transparent color-white number-input font-s14" autocomplete="off" autofocus required="">
								</label>
								<?php if($_GET['very']=="eror"): ?>
									<label for="verify">کد وارد شده صحیح نمیباشد (دوباره تلاش کنید)</label>
								<?php endif ?>
							</div>
							
							<div class="register-head align-left pad-t30">
								<?php if(empty($_GET['mobile'])){?>
								<button type="submit" name="submit_mobile" class="dis-button btn-web iransans pad-15 bold">
									<span class="font-s17">مرحله بعد</span>
								</button>
								<?php }elseif($_GET['mobile']=='verify'){?>
									<button type="submit" name="submit_verify" class="iransans btn-web button-re pad-15 bold">
										<span class="font-s17">مرحله بعد</span>
									</button>
								<?php }?>
							</div>
							<div class="clearfix"></div>
						</div>
					<?php }?>
				</div>
			</form>
			</div>
			<div class="colm6 colm pull-right bg-green box-regiser-l pad-10">
				<div class="pad-t40 align-center font-s40 color-white">صــــد استــــارت آپ</div>
				<div class="pad-t20 align-center">
					<span class="color-white show"> </span>
					<img class="img-register" src="https://kaweb.ir/wp-content/uploads/2019/05/startup-1.png" />
				</div>
			</div>
			<div class="clearfix"></div>
		</div>
	</div>
</div>

<?php get_footer();?>
<?php }else{
	wp_redirect(home_url('/profile'));
}?>
<script>
jQuery(document).ready(function(){
	var uri = window.location.toString();
	if (uri.indexOf("?") > 0) {
	    var clean_uri = uri.substring(0, uri.indexOf("?"));
	    window.history.replaceState({}, document.title, clean_uri);
	}
});
</script>
