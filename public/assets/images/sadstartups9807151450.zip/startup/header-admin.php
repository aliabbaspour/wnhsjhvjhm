<?php
$user = wp_get_current_user();
$user_id = $user->ID;
$first 	 = $user->first_name.' '.$user->last_name;

$roles =get_user_meta($user_id,'roles',true);

?>
<style>

</style>
<!-- Mobile -->
<div class="mobile hide bg-gray overflow hide-mob ">
    <div class="relative pull-left pad-l10 hidden-md pad-t15 exit">
        <a class="exit pad-lheader" href="<?php echo wp_logout_url(home_url('/login')) ?>">خروج از حساب
            <i class="icon-pos font-s30 fa fa-times-circle pad-l5"></i>
        </a>
    </div>
    <div class="relative pull-left pad-l10 hidden-md pad-t15">
        <div class="pad-lheader">
            <i class="fa fa-bell color-menu font-s18 pointer"></i>
        </div>
    </div>
    <div class="relative pull-left pad-l10 hidden-md pad-t15">
        <div class="pad-lheader">
            <i class="fa fa-envelope color-menu font-s18 pointer"></i>
        </div>
    </div>
	<div>
		<div class="header-right-mob pull-right relative">
	        <i class="color-white fa fa-bars vertical"></i>
	    </div>
	    <div class="align-center pull-right pad-10 ">
	    	<h3 class="color-purple font-s16"><?php bloginfo('name') ?></h3>
	    </div>
	    <div class="header-icon-mob pull-left align-center">
	    	<a class="color-darkgray" href="<?php echo home_url('/register') ?>">
	    		<i class="icon-user-plus vertical vertical"></i>
	    	</a>
	    </div>
	    <div class="clearfix"></div>
	</div>
    <div class="mobile-menu-right"> 
	    <div class="mobile-menu-logo align-center pad-t20 pad-b20">
	        <a href="<?php echo home_url() ?>">
	            <img alt="logo" height="40" src="<?php bloginfo('template_url') ?>/assets/images/avatar1.png" />
	        </a>
	        <h2 class="color-white font-s16 pad-t10"><?php echo $first; ?></h2>
	    </div>
	    <div class="mobile-menu font-s13">
            <nav class="sidebar-wrapper">
                <div id="cssmenu" class="menu-drawer">
                    <ul class="font-s14">
                        <li class="pad-t10">
                            <a href="<?php echo home_url('/dashboard') ?>">
                                <i class="fa fa-laptop  vertical font-s22 pad-l15"></i>
                                میزکار
                            </a>
                        </li>
                        <!---- Super Admin ------>

                        <li class="pad-t10">
                            <a href="<?php echo home_url('/list-startup') ?>">
                                <i class="fa fa-rocket vertical font-s22 pad-l15"></i>
                                استارت آپ ها
                            </a>
                        </li>

                        <?php
                        $allowed_roles_high = array('administrator','editor');
                        if(is_user_logged_in() && array_intersect($allowed_roles_high, $user->roles ) || in_array('operational', $roles) ){
                            ?>

                            <li class="has-sub pad-t10">
                                <a href="" class="">
                                    <i class="fa fa-users vertical font-s22 pad-l15"></i>
                                    کاربران
                                </a>
                                <ul class="sub-menu">
                                    <li class="pad-t10">
                                        <a href="<?php echo home_url('/create-user') ?>" >
                                            <i class="fa fa-user-plus vertical font-s22 pad-l15"></i>
                                            اضافه کردن  کاربر
                                        </a>
                                    </li>
                                    <li class="pad-t10">
                                        <a href="<?php echo home_url('/list-user') ?>" >
                                            <i class="fa fa-users vertical font-s22 pad-l15"></i>
                                            لیست کاربران
                                        </a>
                                    </li>
                                </ul>
                            </li>
                            <li class="pad-t10">
                                <a href="<?php echo home_url('/create-cat') ?>">
                                    <i class="fa fa-folder-plus vertical font-s22 pad-l15"></i>
                                    افزودن دسته بندی
                                </a>
                            </li>

                        <?php }?>
                        <!---- Super Admin ------>
                        <?php
                        $allowed_roles_high = array('financial','leader','coach','administrator');
                        if(is_user_logged_in() && (array_intersect($allowed_roles_high, $roles )) || array_intersect($allowed_roles_high,$user->roles) ){
                            ?>
                            <li class="pad-t10">
                                <a href="<?php echo home_url('/manage-request') ?>">
                                    <i class="fa fa-file-invoice-dollar vertical font-s22 pad-l15"></i>
                                    مدیریت درخواست ها
                                </a>
                            </li>
                        <?php }?>
                        <?php
                        if(is_user_logged_in() ){
                            ?>
                            <li class="has-sub pad-t10">
                                <a href="" class="">
                                    <i class="fa fa-clipboard-list vertical font-s22 pad-l15"></i>
                                    لیست ها
                                </a>
                                <ul class="sub-menu">
                                    <?php $allowed_roles_high = array('administrator','manager'); ?>
                                    <?php if(array_intersect($allowed_roles_high,$roles) || array_intersect($allowed_roles_high,$user->roles)) {?>
                                        <li class="pad-t10">
                                            <a href="<?php echo home_url('/list-referee') ?>" class="">
                                                <i class="fa fa-file-alt vertical font-s22 pad-l15"></i>
                                                لیست داوران
                                            </a>
                                        </li>
                                    <?php }?>
                                    <li class="pad-t10">
                                        <a href="<?php echo home_url('/list-coach') ?>" class="">
                                            <i class="fa fa-file-alt vertical font-s22 pad-l15"></i>
                                            لیست منتورها
                                        </a>
                                    </li>
                                    <li class="pad-t10">
                                        <a href="<?php echo home_url('/list-investor') ?>" class="{{ activeinvestor }}">
                                            <i class="fa fa-file-alt vertical font-s22 pad-l15"></i>
                                            لیست سرمایه گذاران
                                        </a>
                                    </li>
                                </ul>
                            </li>
                        <?php }?>

                        <?php
                        $allowed_roles_high = array('administrator','subscriber');
                        if(is_user_logged_in() && (array_intersect($allowed_roles_high, $user->roles ))  ){
                            ?>
                            <li class="pad-t10">
                                <a href="<?php echo home_url('/request-money') ?>" class="">
                                    <i class="fa fa-file-alt vertical font-s22 pad-l15"></i>
                                    درخواست اعتبار
                                </a>
                            </li>

                        <?php } ?>
                        <li class="pad-t10">
                            <a href="<?php echo home_url('/box-message') ?>" class="">
                                <i class="fa fa-envelope vertical font-s22 pad-l15"></i>
                                صندوق پیام
                            </a>
                        </li>
                        <li class="has-sub pad-t10">
                            <a href="" class="">
                                <i class="fa fa-address-card vertical font-s22 pad-l15"></i>
                                حساب کاربری
                            </a>
                            <ul class="sub-menu">
                                <li class="pad-t10">
                                    <a href="<?php echo home_url('/profile') ?>" class="">
                                        <i class="fa fa-user-cog vertical font-s22 pad-l15"></i>
                                        تنظیمات
                                    </a>
                                </li>
                                <li class="pad-t10">
                                    <a href="<?php echo home_url('/chenge-password') ?>" class="">
                                        <i class="fa fa-lock vertical font-s22 pad-l15"></i>
                                        تغییر کلمه عبور
                                    </a>
                                </li>
                            </ul>
                        </li>
                    </ul>
                </div>
            </nav>
	    </div>
	</div>
	<div class="mob-swipe-bg"></div>
    <div class="mobile-search hide">
        <form method="get" class="mobile-search-form" action="<?php echo home_url() ?>">
            <div class="mobile-site-search">
                <i class="icon-android-close search-close"></i>
                <div class="mobile-search-input-box">
                    <input class="mobile-search-input" name="s" type="search" placeholder="جستجو کنید ...">
                </div>
            </div>
        </form>
    </div>
</div>
<div class="container-fluide bg-gray overflow">
	<!------ sidebar -------->
		<div class="sidebar hidden-xs wow fadeInRight" data-wow-duration="1.5s">
		<div class="logo relative pad-15 align-center color-blue wow fadeInDown" data-wow-duration="2s">
	 		<img width="140" src="<?php bloginfo('template_url') ?>/assets/images/logo-panel.svg" />
		 </div>
		 <nav class="sidebar-wrapper">
			<div id="cssmenu" class="menu-drawer">
				<ul class="font-s14">
					<li class="pad-t10">
						<a href="<?php echo home_url('/dashboard') ?>">
							<i class="fa fa-laptop  vertical font-s22 pad-l15"></i>
							میزکار
						</a>
					</li>
					<!---- Super Admin ------>

					<li class="pad-t10">
						<a href="<?php echo home_url('/list-startup') ?>">
							<i class="fa fa-rocket vertical font-s22 pad-l15"></i>							
							استارت آپ ها
						</a>
					</li>

					<?php 
						$allowed_roles_high = array('administrator','editor');
						if(is_user_logged_in() && array_intersect($allowed_roles_high, $user->roles ) || in_array('operational', $roles) ){
					?>
						
						<li class="has-sub pad-t10">
							<a href="" class="">
								<i class="fa fa-users vertical font-s22 pad-l15"></i>							
								کاربران 
							</a>
							<ul class="sub-menu">
								<li class="pad-t10">
									<a href="<?php echo home_url('/create-user') ?>" >
										<i class="fa fa-user-plus vertical font-s22 pad-l15"></i>		
										اضافه کردن  کاربر
									</a>
								</li>
								<li class="pad-t10">
									<a href="<?php echo home_url('/list-user') ?>" >
										<i class="fa fa-users vertical font-s22 pad-l15"></i>		
										لیست کاربران
									</a>
								</li>
							</ul>
						</li>
                        <li class="pad-t10">
                            <a href="<?php echo home_url('/create-cat') ?>">
                                <i class="fa fa-folder-plus vertical font-s22 pad-l15"></i>
                                افزودن دسته بندی
                            </a>
                        </li>
						
					<?php }?>
					<!---- Super Admin ------>
                    <?php
                    $allowed_roles_high = array('financial','leader','coach','administrator');
                    if(is_user_logged_in() && (array_intersect($allowed_roles_high, $roles )) || array_intersect($allowed_roles_high,$user->roles) ){
                    ?>
                        <li class="pad-t10">
                            <a href="<?php echo home_url('/manage-request') ?>">
                                <i class="fa fa-file-invoice-dollar vertical font-s22 pad-l15"></i>
                                مدیریت درخواست ها
                            </a>
                        </li>
                    <?php }?>
					<?php
				        if(is_user_logged_in() ){
					?>
						<li class="has-sub pad-t10">
							<a href="" class="">
								<i class="fa fa-clipboard-list vertical font-s22 pad-l15"></i>							
								لیست ها
							</a>
							<ul class="sub-menu">
                               <?php $allowed_roles_high = array('administrator','manager'); ?>
                                <?php if(array_intersect($allowed_roles_high,$roles) || array_intersect($allowed_roles_high,$user->roles)) {?>
								<li class="pad-t10">
									<a href="<?php echo home_url('/list-referee') ?>" class="">
										<i class="fa fa-file-alt vertical font-s22 pad-l15"></i>		
										لیست داوران
									</a>
								</li>
                                <?php }?>
								<li class="pad-t10">
									<a href="<?php echo home_url('/list-coach') ?>" class="">
										<i class="fa fa-file-alt vertical font-s22 pad-l15"></i>		
										لیست منتورها
									</a>
								</li>
								<li class="pad-t10">
									<a href="<?php echo home_url('/list-investor') ?>" class="{{ activeinvestor }}">
										<i class="fa fa-file-alt vertical font-s22 pad-l15"></i>		
										لیست سرمایه گذاران
									</a>
								</li>
							</ul>
						</li>
					<?php }?>

                    <?php
                    $allowed_roles_high = array('administrator','subscriber');
	                    if(is_user_logged_in() && (array_intersect($allowed_roles_high, $user->roles ))  ){
                    ?>
                            <li class="pad-t10">
                                <a href="<?php echo home_url('/request-money') ?>" class="">
                                    <i class="fa fa-file-alt vertical font-s22 pad-l15"></i>
                                    درخواست اعتبار
                                </a>
                            </li>

                    <?php } ?>
					<li class="pad-t10">
						<a href="<?php echo home_url('/box-message') ?>" class="">
							<i class="fa fa-envelope vertical font-s22 pad-l15"></i>							
							صندوق پیام
						</a>
					</li>
					<li class="has-sub pad-t10">
						<a href="" class="">
							<i class="fa fa-address-card vertical font-s22 pad-l15"></i>							
							حساب کاربری
						</a>
						<ul class="sub-menu">
							<li class="pad-t10">
								<a href="<?php echo home_url('/profile') ?>" class="">
									<i class="fa fa-user-cog vertical font-s22 pad-l15"></i>		
									تنظیمات
								</a>
							</li>
							<li class="pad-t10">
								<a href="<?php echo home_url('/chenge-password') ?>" class="">
									<i class="fa fa-lock vertical font-s22 pad-l15"></i>		
									تغییر کلمه عبور
								</a>
							</li>
						</ul>
					</li>
				</ul>
			</div>
		</nav>
		<div class="clearfix"></div>
	</div>	
	<!---- end sidebar ----->

	<div class="colm12 colm content">
		<div class="colm12 colm  pad-10 bg-gray color-menu min-h100">
			<div class="">
				<div class="font-s18 font-w300 pad-rheader pad-t10 pull-right">
					<span class="">
						<a href="" class="color-menu font-s20">
							<i class="fa fa-bel vertical"></i> 
						</a>
					</span>							
				</div>
				<div class="pad-lheader pull-left pad-t10 pad-l25-mob avatar-mob hide-mob">
					<div class="pull-right pad-t10 pad-l15">
						<h3 class=""><?php echo $first; ?></h3>
					</div>
                    <div class="relative pull-right pad-l20 pad-t15">
                        <div class="pad-lheader">
                            <i class="fa fa-bell color-menu font-s25 pointer"></i>
                        </div>
                    </div>
                    <div class="relative pull-right pad-l20 pad-t15">
                        <div class="pad-lheader">
                            <i class="fa fa-envelope color-menu font-s25 pointer"></i>
                        </div>
                    </div>
					<div class=" relative pull-right">
						<div class="pad-lheader color-menu font-s15">
							<img class="fa fa-user ver vertical avatar-user pointer" width="50" src="<?php bloginfo('template_url') ?>/assets/images/avatar1.png" />
							<!-------dopdown avatar-------->
							<div class="absolute dropd hide abso-avatar-main">
	                            <div class="absolute divdrop"></div>
	                            <ul> 
	                                <li><a href="<?php echo home_url('/dashboard/') ?>">میز کار</a></li> 
	                                <li><a href="<?php echo home_url('/chenge-password') ?>">تغییر رمز عبور</a></li>
	                                <li><a href="<?php echo wp_logout_url(home_url('/login')) ?>">خروج از حساب</a></li>
	                            </ul>
	                        </div>
                                <!-------dopdown avatar-------->
						</div>
					</div>		
					<div class="clearfix"></div>					
				</div>
				<div class="clearfix"></div>
			</div>
			<div class="colm12 colm pad-15 pad-0">
