<div id="content-support" class="container-fluid bg-purple">
	<div class="container">
		<div class="pad-t50 pad-b30">
			<div class="align-center font-s21 color-white  pad-b60">
				<span class="font-w500">حامیان و سرمایه گذاران</span>
			</div>
			<div class="slider-content">
				<?php $args = array( 'post_type' => 'support' , 'showposts' => 24 ) ?>
				<?php query_posts($args) ?>
				<?php while(have_posts()):the_post() ?>
					<div class="silder-box pad-20">
						<div class="slider-box-img pad-15">
							<?php the_post_thumbnail('thumbnail') ?>
						</div>
					</div>
				<?php endwhile;wp_reset_query() ?>
			</div>
		</div>
	</div>
</div>