<?php
	//require_once( 'library/breadcrumbs.php' );
	//require_once( 'library/cat-id.php' );
	require_once('library/cleanup.php');
	require_once('library/image-size.php');
	require_once('library/post-type.php');
	require_once('library/custom-field.php');
	//require_once( 'library/views.php' );
	require_once('library/pagination.php');
	//require_once( 'library/taxonomy.php' );
	require_once('library/navigation.php');
	require_once('library/enqueue-scripts.php');
	require_once('library/theme-support.php');
	require_once('library/widget-areas.php');
	require_once('library/sms.php');
	require_once('library/mail.php');
	require_once('library/database.php');
	require_once('library/role.php');
	//require_once( 'library/mail.php' );
	//require_once( 'library/widget-view.php' );
	require_once('library/rewrite.php');
	require_once('library/setting.php');
	require_once('library/notice.php');
	require_once('library/redirect.php');
	require_once('library/profile.php');
	require_once('library/Classes/index.php');
	function NumToEnglish($string)
	{
		$newNumbers = range(0 , 9);
		// 1. Persian HTML decimal
		$persianDecimal = array('&#1776;' , '&#1777;' , '&#1778;' , '&#1779;' , '&#1780;' , '&#1781;' , '&#1782;' , '&#1783;' , '&#1784;' , '&#1785;');
		// 2. Arabic HTML decimal
		$arabicDecimal = array('&#1632;' , '&#1633;' , '&#1634;' , '&#1635;' , '&#1636;' , '&#1637;' , '&#1638;' , '&#1639;' , '&#1640;' , '&#1641;');
		// 3. Arabic Numeric
		$arabic = array('٠' , '١' , '٢' , '٣' , '٤' , '٥' , '٦' , '٧' , '٨' , '٩');
		// 4. Persian Numeric
		$persian = array('۰' , '۱' , '۲' , '۳' , '۴' , '۵' , '۶' , '۷' , '۸' , '۹');
		$string = str_replace($persianDecimal , $newNumbers , $string);
		$string = str_replace($arabicDecimal , $newNumbers , $string);
		$string = str_replace($arabic , $newNumbers , $string);

		return str_replace($persian , $newNumbers , $string);
	}

	function jdateToTimestamp($date)
	{
		$date = NumToEnglish($date);
		$date = explode('/' , $date);
		$date = jalali_to_gregorian($date[0] , $date[1] , $date[2]);
		$date = implode("-" , $date);

		//$date = strtotime(date($date));
		return $date;
	}

	function randomString($length = 6)
	{
		$str = "";
		$characters = array_merge(range('0' , '9'));
		$max = count($characters) - 1;
		for($i = 0; $i < $length; $i++) {
			$rand = mt_rand(0 , $max);
			$str .= $characters[$rand];
		}

		return $str;
	}

	function action_list_startups($id , $boolean = TRUE)
	{

		$status = get_user_meta($id , 'status' , TRUE);
		switch($status) {
			case 'accepted':
				$icon = '<a  href="#"	rel="nofallow" class="bold"	style="color:  #1b9743;>
					<span>
						<i class="font-s20 ">تایید شده</i>
					</span>
				</a>';
				echo $icon;
				break;
			case 'failed':
				$icon = '<a  href="#"	rel="nofallow" class="bold"	style="color: #9a2249;>
				<span>
					<i class="font-s20 ">تایید نشده</i>
				</span>
			</a>';
				echo $icon;
				break;
			case 'pending':
				$icon = '<a href="#" rel="nofallow" class="bold" style="color:  #22989a;>
				<span>
					<i class="font-s20 ">در انتظار</i>
				</span>
			</a>';
				echo $icon;
				break;
			default:
				$icon = '<a href="#" rel="nofallow" class="bold" style="color:  #9a0009;>
				<span>
					<i class="font-s20 ">تکمیل نشده</i>
				</span>
			</a>';
				echo $icon;
				break;
		}
	}



	function action_list_request($id , $boolean = TRUE)
	{

		$status = get_post_meta($id , 'status' , TRUE);
		switch($status) {
            case 'confirm_leader':
                $icon = '<a  href="#"	rel="nofallow" class="bold"	style="color:  #1b9743;>
					<span>
						<i class="font-s20 ">تایید شده راهبر</i>
					</span>
				</a>';
                echo $icon;
                break;
            case 'failed_leader':
                $icon = '<a  href="#"	rel="nofallow" class="bold"	style="color:  #9a2249;>
					<span>
						<i class="font-s20 ">رد شده راهبر</i>
					</span>
				</a>';
                echo $icon;
                break;
			case 'confirm_financial':
				$icon = '<a  href="#"	rel="nofallow" class="bold"	style="color:  #1b9743;>
					<span>
						<i class="font-s20 ">تایید شده مالی</i>
					</span>
				</a>';
				echo $icon;
				break;
			case 'failed_financial':
				$icon = '<a  href="#"	rel="nofallow" class="bold"	style="color: #9a2249;>
				<span>
					<i class="font-s20 ">تایید نشده مالی</i>
				</span>
			</a>';
				echo $icon;
				break;
            case 'confirm_documents':
                $icon = '<a  href="#"	rel="nofallow" class="bold"	style="color: #9a2249;>
				<span>
					<i class="font-s20 ">تایید شده اسناد</i>
				</span>
			</a>';
                echo $icon;
                break;
            case 'failed_documents':
                $icon = '<a  href="#"	rel="nofallow" class="bold"	style="color: #9a2249;>
				<span>
					<i class="font-s20 ">تایید نشده اسناد</i>
				</span>
			</a>';
                echo $icon;
                break;
			case 'pending':
				$icon = '<a href="#" rel="nofallow" class="bold" style="color:  #22989a;>
				<span>
					<i class="font-s20 ">در انتظار</i>
				</span>
			</a>';
				echo $icon;
				break;
				default:
				$icon = '<a href="#" rel="nofallow" class="bold" style="color:  #9a0009;>
				<span>
					<i class="font-s20 ">نامشخص</i>
				</span>
			</a>';
				echo $icon;
				break;
		}
	}



	/*
	 * abrz edited
	 * create object ajax
	 */
	function get_roles()
	{
		$user_id = get_current_user_id();
		$roles = get_user_meta($user_id , 'roles' , TRUE);

		return $roles;
	}

	function ajax_vb()
	{
		// Enqueue script
		wp_localize_script('vb_ajax_dashboard_script' , 'vb_ajax_dashboard_vars' , array('vb_ajax_url' => admin_url('admin-ajax.php') , 'roles' => get_roles()));
	}

	add_action('wp_footer' , 'ajax_vb' , 100);
	/*
		 * abrz edited
		 * create object ajax
		 */
	require_once("library/googleplusoauth.php");

	class Google_Plus_Login_Widget extends WP_Widget
	{
		public function __construct()
		{
			parent::__construct("Google_Plus_login_widget" , ",ورود به گوگل" , array("description" => __("Display a Google+ Login Button")));
		}

		public function form($instance)
		{
			// Check values
			if($instance) {
				$title = esc_attr($instance['title']);
				$api_key = $instance['api_key'];
				$secret_key = $instance['secret_key'];
				$googleplus_app_name = $instance['googleplus_app_name'];
			} else {
				$title = '';
				$api_key = '';
				$secret_key = '';
				$googleplus_app_name = '';
			}
			?>

        <p>
            <label for="<?php echo $this->get_field_id('title'); ?>"><?php echo "عنوان"; ?></label>
            <input class="widefat" id="<?php echo $this->get_field_id('title'); ?>"
                   name="<?php echo $this->get_field_name('title'); ?>" type="text" value="<?php echo $title; ?>"/>
        </p>

        <p>
            <label for="<?php echo $this->get_field_id('api_key'); ?>"><?php echo "client ID"; ?></label>
            <input type="text" class="widefat" id="<?php echo $this->get_field_id('api_key'); ?>"
                   name="<?php echo $this->get_field_name('api_key'); ?>" value="<?php echo $api_key; ?>"/>
        </p>

        <p>
            <label for="<?php echo $this->get_field_id('secret_key'); ?>"><?php echo "Client Secret"; ?></label>
            <input type="text" class="widefat" id="<?php echo $this->get_field_id('secret_key'); ?>"
                   name="<?php echo $this->get_field_name('secret_key'); ?>" value="<?php echo $secret_key; ?>"/>
        </p>

        <p>
            <label for="<?php echo $this->get_field_id('googleplus_app_name'); ?>"><?php echo "App Name"; ?></label>
            <input type="text" class="widefat" id="<?php echo $this->get_field_id('googleplus_app_name'); ?>"
                   name="<?php echo $this->get_field_name('googleplus_app_name'); ?>"
                   value="<?php echo $googleplus_app_name; ?>"/>
        </p>
        <!---->
        <!--			<p>-->
        <!--				While creating a Twitter app use "--><?php //echo get_site_url() . '/wp-admin/admin-ajax.php?action=googleplus_oauth_callback'
				?><!--" as callback URL.-->
        <!--			</p>-->

			<?php
		}

		public function update($new_instance , $old_instance)
		{
			$instance = $old_instance;
			$instance['title'] = strip_tags($new_instance['title']);
			$instance['api_key'] = strip_tags($new_instance['api_key']);
			$instance['secret_key'] = strip_tags($new_instance['secret_key']);
			$instance['googleplus_app_name'] = strip_tags($new_instance['googleplus_app_name']);
			update_option("googleplus_client_id" , $new_instance['api_key']);
			update_option("googleplus_client_secret" , $new_instance['secret_key']);
			update_option("googleplus_app_name" , $new_instance['googleplus_app_name']);

			return $instance;
		}

		public function widget($args , $instance)
		{
			extract($args);
			$title = apply_filters('widget_title' , $instance['title']);
			echo $before_widget;
			if($title) {
				echo $before_title . $title . $after_title;
			}
			if(is_user_logged_in()) {
				?>
          <a href="<?php echo wp_logout_url(get_permalink()); ?>" title="Logout"><input type="button"
                                                                                        value="Logout"/></a>
				<?php
			} else {
				?>
          <a href="<?php echo site_url() . '/wp-admin/admin-ajax.php?action=googleplus_oauth_redirect'; ?>"><input
                      type="button" value="Login Using Google+"/></a>
				<?php
			}
			echo $after_widget;
		}
	}

	register_widget("Google_Plus_Login_Widget");



?>