<?php /* Template Name: StartUp  */?>

<?php 
session_start();
$user_id = $_SESSION['user_id'];
if(array_key_exists('verify',$_SESSION) && !empty($_SESSION['verify'])) {
	if(isset($_POST['startup_name'])){
		$user_id = $_SESSION['user_id'];
		update_user_meta($user_id,'startup_name',$_POST['startup_name']);
		update_user_meta($user_id,'website',$_POST['website']);
		update_user_meta($user_id,'province_startup',$_POST['province_startup']);
		update_user_meta($user_id,'city_startup',$_POST['city_startup']);
		update_user_meta($user_id,'start_date',$_POST['start_date']);
		update_user_meta($user_id,'prototype',$_POST['prototype']);
		update_user_meta($user_id,'investment',$_POST['investment']);
        update_user_meta($user_id,'team_number',$_POST['team_number']);
        update_user_meta($user_id,'mentor_name',$_POST['mentor_name']);
        update_user_meta($user_id,'cat',$_POST['cat']);
		
        update_user_meta($user_id,'steps',3);
		$_SESSION['step3'] = "ok";
	/*--------- crop ----------*/	
			if(!empty($_POST["avatar_base64"])){
        $dataURL = $_POST["avatar_base64"];
        $dataURL = str_replace('data:image/jpeg;base64,', '', $dataURL);
        $dataURL = str_replace(' ', '+', $dataURL);
        $image_data = base64_decode($dataURL);
        $photo = 'avatar'.uniqid().'.jpg';
        
        $upload_dir = wp_upload_dir();
        $filename = basename($photo);
        if(wp_mkdir_p($upload_dir['path']))
            $file = $upload_dir['path'] . '/' . $filename;
        else
            $file = $upload_dir['basedir'] . '/' . $filename;
        file_put_contents($file, $image_data);
        
        $wp_filetype = wp_check_filetype($filename, null );
        $attachment = array(
            'post_mime_type' => $wp_filetype['type'],
            'post_title' => sanitize_file_name($filename),
            'post_content' => '',
            'post_status' => 'inherit'
        );
        $attach_id = wp_insert_attachment( $attachment, $file, $post_id );
        require_once(ABSPATH . 'wp-admin/includes/image.php');
        $attach_data = wp_generate_attachment_metadata( $attach_id, $file );
        wp_update_attachment_metadata( $attach_id, $attach_data );
        update_user_meta($user_id, 'avatar', $attach_id); 
    }
	/*------- end crop --------*/	
		wp_redirect(home_url('/team/?step=4'));
	}
	$get_cat    = get_user_meta($user_id,'cat',true);
	$cat_1  = $cat['economical'];
	$cat_2  = $cat['social'];
	$cat_3  = $cat['ai'];
	$cat_4  = $cat['education'];
	$cat_5  = $cat['cultural'];
	$cat_6  = $cat['dr'];
    $cat_7  = $cat['learn'];
    $cat_8  = $cat['energy'];
    $cat_9  = $cat['bio'];
    $cat_10 = $cat['health'];
    $cat_11 = $cat['finance'];
    $cat_12 = $cat['food'];
    $cat_13 = $cat['multimedia'];
    $cat_14 = $cat['art'];
    $cat_15 = $cat['big_data'];
    $cat_16 = $cat['robot'];
    $cat_17 = $cat['transport'];
    $cat_18 = $cat['environment'];
    $cat_19 = $cat['charity'];
    $cat_20 = $cat['human'];
    $cat_21 = $cat['services'];
    $cat_22 = $cat['nano'];
    $cat_23 = $cat['virtual'];
    $cat_24 = $cat['internet'];
    $cat_25 = $cat['publish'];
    $cat_26 = $cat['tourist'];
    $cat_27 = $cat['city'];
    $cat_28 = $cat['hard'];

    $startup_name = get_user_meta($user_id,'startup_name',true);
	$website = get_user_meta($user_id,'website',true);
	$start_date = get_user_meta($user_id,'start_date',true);
	$prototype = get_user_meta($user_id,'prototype',true);
	$investment = get_user_meta($user_id,'investment',true);
	$team_number = get_user_meta($user_id,'team_number',true);
	$province_startup = get_user_meta($user_id,'province_startup',true);
	$city_startup = get_user_meta($user_id,'city_startup',true);
	$avatar_id  		= get_user_meta($user_id,'avatar',true);
	$mentor_name  		= get_user_meta($user_id,'mentor_name',true);
	$avatar 			= wp_get_attachment_image_src($avatar_id,'thumbnail');
?>
<?php get_header();?>
<style>
header , footer ,.mobile{
	display: none;
}
.hide-tab{
	display: none;
}
</style>
<div id="section-step" class="container-fluide bg-gray">
	<div class="container pad-20 pad-step pad-50-tmob min-100vh flex-center">
		<div id="section-step-content" class="colm8 colm10-tab colm margin-auto pad-40 pad-20-tab  pad-10-mob bg-white spacer-t40 spacer-b40">
			<div>
				<?php require_once 'steps.php'; ?>
			</div>
			<div class="colm10 colm11-tab colm margin-auto pad-5-mob">
				<div class="pad-b5">
					<h2 class="font-s30 color6">معرفی استارتاپ</h2>
                    <p class="color-darkgray font-s14 pad-t15">لطفا اطلاعات مربوط به استارتاپ خود را پر کنید  </p>
				</div>
				<div class="spacer-t5">
					<form method="post" class="smart-validate" enctype="multipart/form-data">
						<div class="person">
							<div id="avatarbox" class="avatar-box pad-10 flex-center spacer-b10">
						        <?php if($avatar_id){ ?>
						        <img class="img-avatar" src="<?php echo $avatar[0] ?>">
						        <?php }else{ ?> 
						        		<!--<img class="img-avatar" src="<?php// bloginfo('template_url')?>/assets/images/im.png">-->
						                <p class="color-darkgray font-s24  align-center"><i class="fa fa-upload"></i></p>
						                <p class="color-darkgray font-s14  align-center">لوگو تیم را بارگذاری کنید</p>                
						        <?php } ?>
						    </div>
						    <input type="file" name="avatar" id="avatar">
						    <textarea  name="avatar_base64" class="avatar-base64 hide"></textarea>
							<div class="frm-row">
								<div class="colm6 colm pull-right pad-5">
									<label for="startup-name" class="gui-label pad-5">نام استارتاپ  </label>
									<label class="relative">
										<span class="icon-gui flex-center"><i class="fa fa-rocket vertical"></i></span>
										<input type="text" class="gui-input sans-digit" value="<?php echo $startup_name; ?>" name="startup_name" placeholder="مثال : رویداد" required>
									</label>
								</div>
								<div class="colm6 colm pull-right pad-5">
									<label for="website" class="gui-label pad-5">سایت استارتاپ </label>
									<label class="relative">
										<span class="icon-gui flex-center"><i class="fab fa-internet-explorer vertical"></i></span>
										<input type="text" dir="ltr" class="gui-input sans-digit" value="<?php echo $website; ?>" name="website" id="website" placeholder="http://100startup.ir" data-rule-website="true" >
									</label>
								</div>
								<div class="clearfix"></div>
							</div>
							
							<div class="frm-row">
		                        <div class="colm6 colm pull-right pad-5">
		                            <label for="province-startup" class="gui-label pad-5"> استان محل استقرار</label>
		                            <label class="relative">
		                                <select id="province-startup" class="province gui-input sans-digit" name="province_startup" data-value="<?php echo $province_startup; ?>" required />
		                                    <option value="">لطفا یک استان را انتخاب کنید</option>
		                                </select>
		                            </label>  
		                         </div>
		                        <div class="colm6 colm pull-right pad-5">
		                            <label for="city-tstartup" class="gui-label pad-5">شهر محل استقرار</label>
		                            <label class="relative">
		                                <select id="city-startup" class="city gui-input sans-digit" name="city_startup" data-value="<?php echo $city_startup; ?>" required />
		                                    <option value="">لطفا یک شهر را انتخاب کنید</option>
		                                </select>
		                            </label>  
		                         </div>
		                         
		                        <div class="clearfix"></div>
	                    	</div>

							<div class="frm-row">
								<div class="colm6 colm pull-right pad-5">
									<label for="mentor-name" class="gui-label pad-5">نام منتور</label>
									<label class="relative">
										<span class="icon-gui flex-center"><i class="fa fa-user vertical"></i></span>
										<input type="text" class="gui-input sans-digit" value="<?php echo $mentor_name; ?>" name="mentor_name" placeholder="مثال : علی عباسپور" >
									</label>
								</div>
								<div class="colm6 colm pull-right pad-5">
									<label for="start-date" class="gui-label pad-5">تاریخ شروع به کار </label>
									<label class="relative">
										<span class="icon-gui flex-center"><i class="fa fa-calendar-alt"></i></span>
										<input dir="ltr" class="gui-input sans-digit" name="start_date" value="<?php echo $start_date; ?>" id="start-date" autocomplete="off" readonly placeholder="1398/10/02" required>
									</label>
								</div>
							</div>
							<div class="frm-row">
								<div class="colm6 colm pull-right pad-5">
									<label for="prototype" class="gui-label pad-5">آیا نمونه اولیه ساخته اید </label>
									<label class="relative">
										<span for="prototype" class="flex-center icon-select">
                                            <i class="fa fa-chevron-down vertical"></i>
                                        </span>
                                        <select class="gui-select sans-digit" id="prototype" name="prototype" required>
                                            <option value="">انتخاب کنید</option>
                                            <option value="بله" <?php selected($prototype,'بله') ?>>بله</option>
                                            <option value="خیر" <?php selected($prototype,'خیر') ?>>خیر</option>
                                        </select>
									</label>
								</div>
								<div class="colm6 colm pull-right pad-5">
									<label for="investment" class="gui-label pad-5 font-s13">آیا تا‌کنون ‌سرمایه ‌جذب‌کرده‌اید </label>
									<label class="relative">
										<span class="icon-select flex-center">
                                            <i class="fa fa-chevron-down vertical"></i>
                                        </span>
                                        <select class="gui-select sans-digit" id="investment" name="investment" required>
                                            <option value="">انتخاب کنید</option>
                                            <option value="بله" <?php selected($investment,'بله') ?>>بله</option>
                                            <option value="خیر" <?php selected($investment,'خیر') ?>>خیر</option>
                                        </select>
									</label>
								</div>
                                <div class="clearfix"></div>
                            </div>
                            <div class="align-center spacer-t10">
                                <label for="catc" class="gui-label spacer-b20">انتخاب دسته بندی ضروری می باشد </label>
                                <label class="relative">
                                <a class="button-pop font-s13" id="catc" href="#open-modal1">انتخاب دسته بندی</a>
                                </label>
                            </div>
							<div id="open-modal1" class="modal-window">
								<div class="content colm6 colm margin-auto">
									<a href="#modal-close" title="بستن" class="modal-close"><i class="fa fa-times"></i></a>
									<h1 class="digit">حداکثر 3 دسته بندی انتخاب شود</h1>
									<div class="contentt">
										<div class="spacer-t10">
                                            <?php

                                            $cats = get_terms(array('taxonomy'=>'category','hide_empty'=>false)) ;

                                            foreach($cats as $cat)	{

                                                $name_cat = $cat->name;
                                                if($name_cat!=='دیگر'){
                                                    $slug = $cat->slug;
                                                    $term_id =$cat->term_id;
                                                    $attachment = get_term_meta($term_id,'cat_logo');
                                                    $attachment_id = $attachment[0];
                                                    $logo = wp_get_attachment_image_src($attachment_id,'thumbnail');
                                                    $logo_url = $logo[0];
                                                    $category = 'cat['.$slug.']';
                                                    ?>
                                                    <div class="colm2 colm6-mob align-center pull-right cat-image">
                                                        <input class="cat-check" id="cat<?php echo $term_id ?>" name="cat[<?php echo $slug ?>]" value="<?php echo $term_id ?>" type="checkbox" <?=  (in_array($term_id , $get_cat) ? 'checked="checked"' : '' ) ?>/>
                                                        <label for="cat<?php echo $term_id ?>" >
                                                            <img width="" src="<?php echo $logo_url ; ?>" />
                                                            <div class="cat-title"><?php echo $name_cat; ?></div>
                                                        </label>
                                                    </div>
                                                    <?php ; } }?>
											<div class="clearfix"></div>
										</div>
									</div>
								</div>   
							</div> 
						</div>
						<div class="align-left spacer-t40">
							<div class="pull-right pad-5-mob colm5-mob">
								<a href="<?php echo home_url('/register/') ?>" class="btn-prv font-s13 colm">مرحله قبل </a>
							</div>
							<div class="pull-left pad-5-mob colm7-mob">
								<button type="submit" class="btn-web  colm disabled">مرحله بعد </button>
							</div>
			     			<div class="clearfix"></div>
						</div>
					</form>
				</div>
			</div>
		</div>
	</div>
</div>
<div class="popup-frame hide" >
    <div class="resize-frame pad-20">   
        <div class="crop-image"> 
            <img id="imgs" src="<?php bloginfo('template_url')?>/assets/images/avatar.png">
        </div> 
        <div id="crop" class="btn-ui align-center font-s14 font-w3">بـرش تصویر</div> 
        <img src="<?php bloginfo('template_url')?>/assets/images/button-close.png" class="closeicon" />  
    </div>
</div>
<?php get_footer();?>
<?php }else {wp_redirect('/register');}?>
<!----- checkbox ---->
<script>
jQuery(document).ready(function($){

    $(".cat-check").change(function(){
	    var max= 3;
	    if( $(".cat-check:checked").length == max ){
	        $(".cat-check").attr('disabled', 'disabled');
	        $(".cat-check:checked").removeAttr('disabled');
	    }else{
	         $(".cat-check").removeAttr('disabled');
	    }
	    var min = 0 ;
		if( $(".cat-check:checked").length > min ){
	    	$(".btn-web").prop( "disabled", false );
	    }else{
	    	$(".btn-web").prop( "disabled", true );
	    }
	})
    $('.cat-check').each(function() {
        var max= 3;
        if( $(".cat-check:checked").length == max ){
            $(".cat-check").attr('disabled', 'disabled');
            $(".cat-check:checked").removeAttr('disabled');
        }else{
            $(".cat-check").removeAttr('disabled');
        }
    })
	var min = 0 ;
	if( $(".cat-check:checked").length > min ){
    	$(".btn-web").prop( "disabled", false );
    }else{
    	$(".btn-web").prop( "disabled", true );
    }
	
	var uri = window.location.toString();
	if (uri.indexOf("?") > 0) {
	    var clean_uri = uri.substring(0, uri.indexOf("?"));
	    window.history.replaceState({}, document.title, clean_uri);
	}
});
</script>
