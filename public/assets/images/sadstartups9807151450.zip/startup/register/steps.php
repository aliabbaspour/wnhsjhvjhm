<?php
$page = $post->post_name;
$step = (isset($_GET['step'])) ? $_GET['step']:'' ;
if($page == 'verify' || $step == 2){
	$step = 2 ;
}elseif($page == 'startup' || $step == 3){
	$step = 3 ;
}elseif($page == 'team' || $step == 4){
	$step = 4 ;
}elseif($page == 'uploads' || $step == 5){
	$step = 5 ;
}elseif($page == 'presentation' || $step == 6){
	$step = 6 ;
}elseif($page == 'finish' || $step == 7){
    $step = 7 ;
}else{
	$step = 1 ;
}
?>
<div id="steps">
    <ul>
        <li><div class="step <?php echo ($step == 1 )?"active":''; ?>" data-desc="آغاز ثبت نام" align="">1</div></li>
        <li><div class="step <?php echo ($step == 2 )?"active":''; ?>" data-desc="اعتبارسنجی" align="">2</div></li>
        <li><div class="step <?php echo ($step == 3 )?"active":''; ?>" data-desc="معرفی استارتاپ" align="">3</div></li>
        <li><div class="step <?php echo ($step == 4 )?"active":''; ?>" data-desc="اطلاعات تیم" align="">4</div></li>
        <li><div class="step <?php echo ($step == 5 )?"active":''; ?>" data-desc="معرفی ویدئویی" align="">5</div></li>
        <li><div class="step <?php echo ($step == 6 )?"active":''; ?>" data-desc="پیچ دک" align="">6</div></li>
        <li><div class="step <?php echo ($step == 7 )?"active":''; ?>" data-desc="تایید نهایی" align="">7</div></li>
    </ul>
</div>