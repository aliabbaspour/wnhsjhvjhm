<?php /* Template Name: Team  */?>
<?php 
session_start();
if(array_key_exists('step3',$_SESSION) && !empty($_SESSION['step3'])) {
	if(isset($_POST['first_name'])){
		$user_id = $_SESSION['user_id'];
		$birthday = jdateToTimestamp($_POST['birthday']);
		update_user_meta($user_id,'first_name',$_POST['first_name']);
		update_user_meta($user_id,'last_name',$_POST['last_name']);
		update_user_meta($user_id,'birthday',$birthday);
		update_user_meta($user_id,'linkedin',$_POST['linkedin']);
		update_user_meta($user_id,'expertise',$_POST['expertise']);
		update_user_meta($user_id,'educationl',$_POST['educationl']);
		update_user_meta($user_id,'side','رهبر تیم');
		update_user_meta($user_id,'average',$_POST['average']);
		update_user_meta($user_id,'stock',$_POST['stock']);
        update_user_meta($user_id,'introduction',$_POST['introduction']);
        update_user_meta($user_id,'better',$_POST['better']);
        update_user_meta($user_id,'defect_team',$_POST['defect_team']);
        update_user_meta($user_id,'reagent',$_POST['reagent']);
        update_user_meta($user_id,'steps',4);
		$update_user = array(
			'ID'=>$user_id,
			'user_email'=>$_POST['email'],
		);
		wp_update_user($update_user);
		 
		$_SESSION['step4'] = "ok";
		
		$firstname_ar= $_POST['first_namel'];
		$lastname_ar = $_POST['last_namel'];
		$mobilel 	 = $_POST['mobilel'];
		$email_ar	 = $_POST['email_l'];
		$linkdinl	 = $_POST['linkdinl'];
		$birthday_ar = $_POST['birthdayl'];
		$expertisel  = $_POST['expertisel'];
		$educationl1  = $_POST['educationl1'];
		$sidel  	 = $_POST['sidel'];
		$averagel 	 = $_POST['averagel'];
		$stockl 	 = $_POST['stockl'];
		$id			 = $_POST['id'];
		
		$first_name_u = $_POST['first_nameu'];
		$last_nameu   = $_POST['last_nameu'];
		$i =0;
		foreach($firstname_ar as $number){
			$x = $i++;
			$birthday = jdateToTimestamp($birthday_ar[$x]);
			if(empty($number)){
				
			}else{
				if(!empty($id[$x])){
					$query = array(
						'ID'=>$id[$x]
					);
					$data = array(
						'first_name'=>$firstname_ar[$x],
						'last_name'=>$lastname_ar[$x],
						'mobile'=>$mobilel[$x],
						'email'	=>$email_ar[$x],
						'socials'=>$linkdinl[$x],
						'birthday'=>$birthday,
						'expertise'=>$expertisel[$x],
						'education'=>$educationl1[$x],
						'side'=>$sidel[$x],
						'average'=>$averagel[$x], 
						'stock'=>$stockl[$x], 
					);
					update_datas('group_user',$data,$query);
				}else{
					$data = array(
						'user_id'=>$user_id,
						'first_name'=>$firstname_ar[$x],
						'last_name'=>$lastname_ar[$x],
						'mobile'=>$mobilel[$x],
						'email'	=>$email_ar[$x],
						'socials'=>$linkdinl[$x],
						'birthday'=>$birthday,
						'expertise'=>$expertisel[$x],
						'education'=>$educationl1[$x],
						'side'=>$sidel[$x],
						'average'=>$averagel[$x],
						'stock'=>$stockl[$x],
						'status'=>'publish'
					);	
					insert_data('group_user',$data);
				}
			}
		}
		wp_redirect(home_url('/uploads/?step=5'));
	}

if(isset($_POST['ajax_del'])){
	$post_id = $_POST['post_id']; 
	$query = array(
		'ID'=>$post_id
	);
	$data = array(
		'status'=>'draft',
	);
	update_datas('group_user',$data,$query);
}
	$user_id = $_SESSION['user_id'];
	$role = $_SESSION['role'];
	$user = get_user_by( 'id', $user_id );
	$first_name = get_user_meta($user_id,'first_name',true);
	$last_name  = get_user_meta($user_id,'last_name',true);
	$mobile		= get_user_meta($user_id,'mobile',true);
	$birthday	= get_user_meta($user_id,'birthday',true);
	
    $introduction = get_user_meta($user_id,'introduction',true);
    $better 	  = get_user_meta($user_id,'better',true);
    $defect_team  = get_user_meta($user_id,'defect_team',true);
    $linkedin	  	  = get_user_meta($user_id,'linkedin',true);
    $expertise	  = get_user_meta($user_id,'expertise',true);
    $education	  = get_user_meta($user_id,'education',true);
    $educationl	  = get_user_meta($user_id,'educationl',true);
    $expertise	  = get_user_meta($user_id,'expertise',true);
    $side	  	  = get_user_meta($user_id,'side',true);
    $average	  = get_user_meta($user_id,'average',true);
    $stock	  = get_user_meta($user_id,'stock',true);
    $reagent	  = get_user_meta($user_id,'reagent',true);
    $start_date = get_user_meta($user_id,'start_date',true);
    $user_info = get_userdata($user_id);
	$email  = $user_info->user_email;
?>
<?php get_header();?>
<style>
header , footer ,.mobile{
	display: none;
}
.hide-tab{
	display: none;
}
</style>

<div id="section-step" class="container-fluide bg-gray">
	<div  class="container pad-20 pad-step pad-50-tmob min-100vh flex-center">
		<div id="section-step-content" class="colm8 colm10-tab colm margin-auto pad-40 pad-20-tab pad-10-mob bg-white spacer-t40 spacer-b40">
			<div>
				<?php require_once 'steps.php'; ?>
			</div>
			<div class="colm10 colm11-tab colm margin-auto pad-5-mob">
				<div class="pad-b5">
					<h2 class="font-s30 color6">تیم</h2>
                    <p class="color-darkgray font-s14 pad-t15">لطفا اطلاعات تیم خود را وارد کنید  </p>
				</div>
				<div class="spacer-t10">
					<form method="post" class="smart-validate" enctype="multipart/form-data">
						<div>
                            <div class="frm-row">
                                <div class="pad-5 char-count">
                                    <label for="introduction" class="gui-label pad-5">  نحوه آشنایی اعضای تیم با یکدیگر  </label>
                                    <label class="relative text-counter">
                                        <textarea  name="introduction" id="introduction" maxlength="255"  class="gui-textarea" placeholder="تعدادی از اعضای تیم رو از طریق جابینجا شناختم، با تعدادی از قبل همکار بودم و تعدادی از افراد تیم را هم از دوستانم معرفی کرده‌اند." required ><?php echo $introduction; ?></textarea>
                                    	<p class="align-left font-w200 font-s12 color-blue pad-l5"></p>
                                    </label>
                                </div>
                                <div class="pad-5 char-count">
                                    <label for="better" class="gui-label pad-5"> چه چیز باعث شده شما بهتر از بقیه باشید ؟</label>
                                    <label class="relative">
                                        <textarea name="better" maxlength="255" id="better" required id="team-excerpt1" class="gui-textarea" placeholder="تلاش شبانه‌روزی، هوشمندی در شیوه توسعه کار و شبکه گسترده که برای تمامی آن‌ها در فایل ارائه دلایل و مستنداتی ذکر شده است. علاوه بر این ما افرادی را در تیم داریم که در حوزه خرید میوه و سبزیجات به صورت مستقیم کار کرده‌اند و با این بازار آشنا هستند. شبکه تامین‌کنندگان ما برای این کار سه برابر استارتاپ ب است و روند رشد ما دو برابر استارتاپ ب بوده است." required><?php echo $better; ?></textarea>
                                    	<p class="align-left font-w200 font-s12 color-blue pad-l5"></p>
                                    </label>
                                </div>
                                <div class="pad-5 char-count">
                                    <label for="defect" class="gui-label pad-5"> تیم شما چه چیزی کم دارد ؟ </label>
                                    <label class="relative">
                                        <textarea name="defect_team" id="defect" required  maxlength="255" class="gui-textarea" placeholder="سرمایه مناسب برای توسعه‌ی نمایندگی‌ها و همچنین برخی مجوزها برای صدور ضمانت‌نامه خرید و ... ." required><?php echo $defect_team; ?></textarea>
                                    	<p class="align-left font-w200 font-s12 color-blue pad-l5"></p>
                                    </label>
                                </div>
                                <div class="pad-5 char-count">
                                    <label for="reagent" class="gui-label pad-5">معرف شما چه کسی بوده ؟</label>
                                    <label class="relative">
                                        <textarea name="reagent" id="reagent" required  maxlength="255" class="gui-textarea" required><?php echo $reagent; ?></textarea>
                                    	<p class="align-left font-w200 font-s12 color-blue pad-l5"></p>
                                    </label>
                                </div>
                            </div>
						</div>
						
						
						<div class="person" id="personn">
							
							<h2 class="bold font-s20 pad-15 bg-gray border-ra5">اعضای تیم</h2>
							<h3 class="pad-15 bold">رهبر تیم</h3>
							<div class="frm-row">
								<div class="colm6 colm pull-right pad-5">
									<label for="first-name" class="gui-label pad-5">نام :</label>
									<label class="relative">
										<span class="icon-gui flex-center"><i class=" fa fa-user vertical"></i></span>
										<input type="text" class="gui-input sans-digit" id="first-name" value="<?php echo $first_name; ?>" name="first_name" placeholder="مثال : محمد" data-rule-lettersonly="true" autocomplete="off" required>
									</label>
								</div>
								<div class="colm6 colm pull-right pad-5"> 
									<label for="last-name" class="gui-label pad-5">نام خانوادگی :</label>
									<label class="relative">
										<span class="icon-gui flex-center"><i class=" fa fa-user vertical"></i></span>
										<input type="text" class="gui-input sans-digit" value="<?php echo $last_name; ?>" name="last_name" placeholder="مثال : محمدی" data-rule-lettersonly="true" id="last-name" autocomplete="off" required>
									</label>
								</div>
								<div class="clearfix"></div>
							</div>
							<div class="frm-row">
								<div class="colm6 colm pull-right pad-5">
									<label for="mobile" class="gui-label pad-5"> شماره همراه:</label>
									<label class="relative">
										<span class="icon-gui flex-center"><i class=" fa fa-mobile"></i></span>
										<input dir="ltr" class="gui-input sans-digit" readonly value="<?php echo $mobile; ?>" id="mobile" >
									</label>
								</div>
								<div class="colm6 colm pull-right pad-5">
									<label for="email" class="gui-label pad-5">ایمیل :</label>
									<label class="relative">
										<span class="icon-gui flex-center"><i class=" fa fa-at"></i></span>
										<input dir="ltr" type="email" class="gui-input sans-digit" name="email" id="email" value="<?php echo $email; ?>"  placeholder="example@gmail.com" required>
									</label>
								</div>
								<div class="clearfix"></div>
							</div>
							<div class="frm-row">
								<div class="colm6 colm pull-right pad-5">
									<label for="linkedin" class="gui-label pad-5">لینکدین :</label>
									<label class="relative">
										<span class="icon-gui flex-center"><i class=" fab fa-linkedin-in vertical"></i></span>
										<input dir="ltr" type="text" class="gui-input sans-digit" value="<?php echo $linkedin; ?>"  name="linkedin" id="linkedin" >
									</label>
								</div>
								<div class="colm6 colm pull-right pad-5">
									<label for="birthday" class="gui-label pad-5"> تاریخ تولد :</label>
									<label class="relative">
										<span class="icon-gui flex-center"><i class=" fa fa-birthday-cake"></i></span>
										<input dir="ltr" class="gui-input sans-digit datepicker-gregorian" name="birthday" value="<?php echo date('Y-m-d',strtotime($birthday)); ?>" id="birthday" autocomplete="off" readonly required placeholder="1398/10/02" >
									</label>
								</div>
								
								<div class="clearfix"></div>
							</div>
							<div class="frm-row">
								<div class="colm6 colm pull-right pad-5">
									<label for="expertise" class="gui-label pad-5">تخصص:</label>
									<label class="relative">
										<span class="icon-gui flex-center"><i class=" fa fa-laptop-code vertical"></i></span>
										<input type="text" class="gui-input sans-digit" name="expertise" value="<?php echo $expertise; ?>" id="expertise" placeholder="مثال : نرم افزار" required>
									</label>
								</div>

                                <div class="colm6 colm pull-right pad-5">

								<label class="gui-label pad-5">تحصیلات:</label>
                                    <label  class="relative">
                                        <span class="icon-gui flex-center"><i class=" fa fa-user-graduate vertical"></i></span>
                                        <select class="gui-input sans-digit" name="educationl">
                                            <option value="">میزان تحصیلات خود را انتخاب کنید</option>
                                            <option value="1"<?php if ( $educationl == 1 ) echo 'selected="selected"'; ?>>زیر دیپلم</option>
                                            <option value="2"<?php if ( $educationl == 2 ) echo 'selected="selected"'; ?>>دیپلم</option>
                                            <option value="3"<?php if ( $educationl == 3 ) echo 'selected="selected"'; ?>>فوق دیپلم</option>
                                            <option value="4"<?php if ( $educationl == 4 ) echo 'selected="selected"'; ?>>لیسانس</option>
                                            <option value="4"<?php if ( $educationl == 5 ) echo 'selected="selected"'; ?>>فوق لیسانس</option>
                                            <option value="4"<?php if ( $educationl == 6 ) echo 'selected="selected"'; ?>>دکتری</option>
                                            <option value="4"<?php if ( $educationl == 7 ) echo 'selected="selected"'; ?>>فوق دکتری</option>
                                        </select>
                                    </label>

                                </div>
								
								<div class="clearfix"></div>
							</div>
							<!--<div class="frm-row">
								<div class="colm12 colm pad-5">
									<label for="side" class="gui-label pad-5"> سمت در استارت آپ :</label>
									<label class="relative">
										<span class="icon-gui flex-center"><i class=" fa fa-book-reader"></i></span>
										<input dir="rtl" class="gui-input sans-digit" name="side" value="<?php echo $side; ?>" id="side" autocomplete="off" placeholder="سمت استارت آپ" >
									</label>
								</div>
							</div>-->
							
							<div class="frm-row">
								<div class="colm6 colm pad-5 pull-right">
									<label for="average" class="gui-label pad-5"> زمان اختصاص داده شده به استارتاپ در طول ماه:</label>
									<label class="relative">
										<span class="icon-gui flex-center"><i class=" fa fa-clock vertical"></i></span>
										<input type="number" class="gui-input sans-digit" name="average" value="<?php echo $average; ?>" id="average" placeholder="مثال : 100 ساعت" >
									</label>
								</div>
								<div class="colm6 colm pad-5 pull-right">
									<label for="stock" class="gui-label pad-5">میزان سهام :</label>
									<label class="relative">
										<span class="icon-gui flex-center"><i class=" fa fa-percentage vertical"></i></span>
										<input type="number" class="gui-input sans-digit" name="stock" value="<?php echo $stock; ?>" id="stock" placeholder="مثال :  20 درصد" >
									</label>
								</div>
								<div class="clearfix"></div>
							</div>
						</div>

						<!------ Foreach ------>
						<?php
							$args = array(
								'showposts'=>10,
								'query'=>array(
									array(
										'key'=>'user_id',
										'value'=>$user_id,
										'compare'=>'='
									),
									array(
										'key'=>'status',
										'value'=>'publish',
										'compare'=>'='
									)
								)
							);
							$group_user = query_data('group_user',$args);
						?>
						<?php foreach($group_user as $number_s): ?>
							
							<div class="team">
								<div class="remove-group align-right pointer close_user relative" data-id="<?php echo $number_s->id; ?>">
									<div class="absolute font-s16 flex-center close-u">
										<span class="">
											<i class="fa fa-times-circle color-red"></i>
										</span>
									</div>
								</div>
						<div class="">
							<input type="text" name="id[]" value="<?php echo $number_s->id; ?>" class="hide" />
							<div class="frm-row">
								<div class="colm6 colm pull-right pad-5">
									<label for="first-name" class="gui-label pad-5">نام :</label>
									<label class="relative">
										<span class="icon-gui flex-center"><i class=" fa fa-user vertical"></i></span>
										<input type="text" class="gui-input sans-digit"  value="<?php echo $number_s->first_name; ?>" name="first_namel[]" placeholder="مثال : محمد" data-rule-lettersonly="true" autocomplete="off" required>
									</label>
								</div>
								<div class="colm6 colm pull-right pad-5">
									<label for="first-name" class="gui-label pad-5">نام خانوادگی :</label>
									<label class="relative">
										<span class="icon-gui flex-center"><i class=" fa fa-user vertical"></i></span>
										<input type="text" class="gui-input sans-digit" value="<?php echo $number_s->last_name; ?>" name="last_namel[]" placeholder="مثال : محمدی" data-rule-lettersonly="true"  autocomplete="off" required>
									</label>
								</div>
								<div class="clearfix"></div>
							</div>
							<div class="frm-row">
								<div class="colm6 colm pull-right pad-5">
									<label for="" class="gui-label pad-5"> شماره همراه:</label>
									<label class="relative">
										<span class="icon-gui flex-center"><i class=" fa fa-mobile"></i></span>
										<input dir="ltr" class="gui-input sans-digit"  data-rule-customphone="true" name="mobilel[]" value="<?php echo $number_s->mobile; ?>"  autocomplete="off" placeholder="09000000000" required>
									</label>
								</div>
								<div class="colm6 colm pull-right pad-5">
									<label class="gui-label pad-5">ایمیل :</label>
									<label class="relative">
										<span class="icon-gui flex-center"><i class=" fa fa-at vertical"></i></span>
										<input dir="ltr" type="email" class="gui-input sans-digit" name="email_l[]"  value="<?php echo $number_s->email; ?>" placeholder="example@gmail.com" required>
									</label>
								</div>
								<div class="clearfix"></div>
							</div>
							<div class="frm-row">
								<div class="colm6 colm pull-right pad-5">
									<label class="gui-label pad-5">لینکدین :</label>
									<label class="relative">
										<span class="icon-gui flex-center"><i class=" fab fa-linkedin-in vertical"></i></span>
										<input dir="ltr" type="text" class="gui-input sans-digit" value="<?php echo $number_s->socials;  ?>"  name="linkdinl[]" >
									</label>
								</div>
								<div class="colm6 colm pull-right pad-5">
									<label class="gui-label pad-5"> تاریخ تولد :</label>
									<label class="relative">
										<span class="icon-gui flex-center"><i class="fa fa-birthday-cake"></i></span>
										<input dir="ltr" class="gui-input sans-digit datepicker-gregorian" name="birthdayl[]" value="<?php echo date('Y-m-d',strtotime($number_s->birthday)); ?>" autocomplete="off" readonly placeholder="1398/10/02" required>
									</label>
								</div>
								<div class="clearfix"></div>
							</div>
							<div class="frm-row">
								<div class="colm6 colm pull-right pad-5">
									<label for="expertise" class="gui-label pad-5">تخصص:</label>
									<label class="relative">
										<span class="icon-gui flex-center"><i class=" fa fa-laptop-code vertical"></i></span>
										<input type="text" class="gui-input sans-digit" name="expertisel[]" value="<?php echo $number_s->expertise; ?>" placeholder="مثال : نرم افزار" required>
									</label>
								</div>
								
								<div class="colm6 colm pull-right pad-5">

								<label class="gui-label pad-5">تحصیلات:</label>
                                    <label  class="relative">
                                        <span class="icon-gui flex-center"><i class=" fa fa-user-graduate vertical"></i></span>
                                        <select class="gui-input sans-digit" name="educationl1[]">
                                            <option value="">میزان تحصیلات خود را انتخاب کنید</option>
                                            <option value="1"<?php if ( $number_s->education == 1 ) echo 'selected="selected"'; ?>>زیر دیپلم</option>
                                            <option value="2"<?php if ( $number_s->education == 2 ) echo 'selected="selected"'; ?>>دیپلم</option>
                                            <option value="3"<?php if ( $number_s->education == 3 ) echo 'selected="selected"'; ?>>فوق دیپلم</option>
                                            <option value="4"<?php if ( $number_s->education == 4 ) echo 'selected="selected"'; ?>>لیسانس</option>
                                            <option value="5"<?php if ( $number_s->education == 5 ) echo 'selected="selected"'; ?>>فوق لیسانس</option>
                                            <option value="6"<?php if ( $number_s->education == 6 ) echo 'selected="selected"'; ?>>دکتری</option>
                                            <option value="7"<?php if ( $number_s->education == 7 ) echo 'selected="selected"'; ?>>فوق دکتری</option>
                                        </select>
                                    </label>

								</div>
								
								<div class="clearfix"></div>
							</div>
							<div class="frm-row">
								<div class="colm12 colm pad-5">
									<label for="sidel" class="gui-label pad-5"> سمت در استارت آپ :</label>
									<label class="relative">
										<span class="icon-gui flex-center"><i class=" fa fa-book-reader"></i></span>
										<input dir="rtl" class="gui-input sans-digit " name="sidel[]" value="<?php echo $number_s->side; ?>"  autocomplete="off" placeholder="سمت استارت آپ" required>
									</label>
								</div>
							</div>
							<div class="frm-row">
								<div class="colm6 colm pad-5 pull-right">
									<label class="gui-label pad-5"> زمان اختصاص داده شده به استارتاپ در طول ماه:</label>
									<label class="relative">
										<span class="icon-gui flex-center"><i class=" fa fa-clock vertical"></i></span>
										<input type="number" class="gui-input sans-digit" name="averagel[]" value="<?php echo $number_s->average; ?>"  placeholder="مثال : 100 ساعت" >
									</label>
								</div>
								<div class="colm6 colm pad-5 pull-right">
									<label class="gui-label pad-5">میزان سهام :</label>
									<label class="relative">
										<span class="icon-gui flex-center"><i class=" fa fa-percentage vertical"></i></span>
										<input type="number" class="gui-input sans-digit" name="stockl[]" value="<?php echo $number_s->stock; ?>"  placeholder="مثال :  20 درصد" >
									</label>
								</div>
								<div class="clearfix"></div>
							</div>
								<hr />
								</div>
							</div>
						<?php endforeach ?>
						<!------ Foreach ------>
						<div class="team">
							<div class="hide clone relative">
                                <div class="remove-group align-right pointer close_user relative close-ta">
                                    <div class="absolute font-s16 flex-center close-u">
										<span class="">
											<i class="fa fa-times-circle color-red"></i>
										</span>
                                    </div>
                                </div>
                                <h2 class="bold font-s20 pad-15 bg-gray border-ra5 spacer-t20">عضو گروه</h2>
								<input type="text" name="id[]" value="" class="hide" />
								<input type="text" name="remove[]" value="" class="remove_web hide" />
								<div class="frm-row">
								<div class="colm6 colm pull-right pad-5">
									<label for="first-namel" class="gui-label pad-5">نام :</label>
									<label class="relative">
										<span class="icon-gui flex-center"><i class=" fa fa-user verticall"></i></span>
										<input type="text" class="gui-input sans-digit"  value="<?php ?>" name="first_namel[]" placeholder="مثال : محمد" data-rule-lettersonly="true"  autocomplete="off" required aria-selected="true">
									</label>
								</div>
								<div class="colm6 colm pull-right pad-5">
									<label for="last-namel" class="gui-label pad-5">نام خانوادگی :</label>
									<label class="relative">
										<span class="icon-gui flex-center"><i class=" fa fa-user vertical"></i></span>
										<input type="text" class="gui-input sans-digit" value="<?php  ?>" name="last_namel[]" placeholder="مثال : محمدی" data-rule-lettersonly="true" autocomplete="off" required>
									</label>
								</div>
								<div class="clearfix"></div>
							</div>
							<div class="frm-row">
								<div class="colm6 colm pull-right pad-5">
									<label for="mobilel" class="gui-label pad-5"> شماره همراه:</label>
									<label class="relative">
										<span class="icon-gui flex-center"><i class=" fa fa-mobile"></i></span>
										<input dir="ltr" class="gui-input sans-digit" name="mobilel[]" data-rule-customphone="true" value="<?php ?>" autocomplete="off" placeholder="09000000000" required>
									</label>
								</div>
								<div class="colm6 colm pull-right pad-5">
									<label for="email-l" class="gui-label pad-5">ایمیل :</label>
									<label class="relative">
										<span class="icon-gui flex-center"><i class="fa fa-at"></i></span>
										<input dir="ltr" type="email" class="gui-input sans-digit" name="email_l[]" value="<?php ?>"  placeholder="example@gmail.com" required>
									</label>
								</div>
								<div class="clearfix"></div>
							</div>
							<div class="frm-row">
								<div class="colm6 colm pull-right pad-5">
									<label class="gui-label pad-5">لینکدین :</label>
									<label class="relative">
										<span class="icon-gui flex-center"><i class=" fab fa-linkedin-in vertical"></i></span>
										<input dir="ltr" type="text" class="gui-input sans-digit" value="<?php ?>"  name="linkdinl[]">
									</label>
								</div>
								<div class="colm6 colm pull-right pad-5">
									<label for="birthdayl" class="gui-label pad-5"> تاریخ تولد :</label>
									<label class="relative">
										<span class="icon-gui flex-center"><i class=" fa fa-birthday-cake"></i></span>
										<input dir="ltr" class="gui-input sans-digit datepicker" name="birthdayl[]" value="<?php ?>"  autocomplete="off" placeholder="1398/10/02" required>
									</label>
								</div>

								<div class="clearfix"></div>
							</div>
							<div class="frm-row">
								<div class="colm6 colm pull-right pad-5">
									<label for="expertisel" class="gui-label pad-5">تخصص:</label>
									<label class="relative">
										<span class="icon-gui flex-center"><i class=" fa fa-laptop-code vertical"></i></span>
										<input type="text" class="gui-input sans-digit" name="expertisel[]" value="<?php ?>"  placeholder="مثال : نرم افزار" required>
									</label>
								</div>

                                <div class="colm6 colm pull-right pad-5">

								<label class="gui-label pad-5">تحصیلات:</label>
                                    <label  class="relative">
                                        <span class="icon-gui flex-center"><i class=" fa fa-user-graduate vertical"></i></span>
                                        <select class="gui-input sans-digit" name="educationl1[]">
                                            <option value="">میزان تحصیلات خود را انتخاب کنید</option>
                                            <option value="1"<?php if ( $educationl == 1 ) echo 'selected="selected"'; ?>>زیر دیپلم</option>
                                            <option value="2"<?php if ( $educationl == 2 ) echo 'selected="selected"'; ?>>دیپلم</option>
                                            <option value="3"<?php if ( $educationl == 3 ) echo 'selected="selected"'; ?>>فوق دیپلم</option>
                                            <option value="4"<?php if ( $educationl == 4 ) echo 'selected="selected"'; ?>>لیسانس</option>
                                            <option value="5"<?php if ( $educationl == 5 ) echo 'selected="selected"'; ?>>فوق لیسانس</option>
                                            <option value="6"<?php if ( $educationl == 6 ) echo 'selected="selected"'; ?>>دکتری</option>
                                            <option value="7"<?php if ( $educationl == 7 ) echo 'selected="selected"'; ?>>فوق دکتری</option>
                                        </select>
                                    </label>

                                </div>

								<div class="clearfix"></div>
							</div>
							<div class="frm-row">
								<div class="colm12 colm pad-5">
									<label for="sidel" class="gui-label pad-5"> سمت در استارت آپ :</label>
									<label class="relative">
										<span class="icon-gui flex-center"><i class=" fa fa-book-reader"></i></span>
										<input dir="rtl" class="gui-input sans-digit" name="sidel[]" value="<?php  ?>" autocomplete="off" placeholder="سمت استارت آپ" required>
									</label>
								</div>
							</div>
							<div class="frm-row">
								<div class="colm6 colm pad-5 pull-right">
									<label for="averagel" class="gui-label pad-5"> زمان اختصاص داده شده به استارتاپ در طول ماه:</label>
									<label class="relative">
										<span class="icon-gui flex-center"><i class=" fa fa-clock vertical"></i></span>
										<input type="number" class="gui-input sans-digit" name="averagel[]" value="<?php ?>"  placeholder="مثال : 100 ساعت" >
									</label>
								</div>
								<div class="colm6 colm pad-5 pull-right">
									<label for="stockl" class="gui-label pad-5">میزان سهام :</label>
									<label class="relative">
										<span class="icon-gui flex-center"><i class=" fa fa-percentage vertical"></i></span>
										<input type="number" class="gui-input sans-digit" name="stockl[]" value="<?php ?>"  placeholder="مثال :  20 درصد" >
									</label>
								</div>
							</div>
							<hr />
							</div>
                            <div class=" pointer btn-add flex-center">
                                <i class="add-team plus-rot fa fa-plus-circle vertical spacer-t10"></i>
                            </div>
                            <h3 class="align-center font-s13 spacer-t5">اضافه کردن اعضا</h3>
						</div>

						<div class="align-left spacer-t40">
							<div class="pull-right colm5-mob pad-5-mob">
								<a href="<?php echo home_url('/startup/?step=3') ?>" class="btn-prv font-s13 colm">مرحله قبل </a>
							</div>
							<div class="align-left spacer-t40">
								<div class="pull-left colm7-mob pad-5-mob">
									<button type="submit" class="btn-web colm">مرحله بعد </button>
								</div>

				     			<div class="clearfix"></div>
							</div>
			     			<div class="clearfix"></div>
						</div>
					</form>
				</div>
			</div>
		</div>
	</div>
</div>
<?php $count_number = count($group_user); 
$number_js = 5 - $count_number;
?>
<?php get_footer();?>
<?php }else {wp_redirect('/register');}?>
<script>
jQuery(document).ready(function($){
	$(document).on("click",".remove-group",function(){
		  $(this).parent().remove();
		  $('.loader').show();
		setInterval(function() {
		  $('.loader').hide();
		}, 200);
	})
	$(".add-team").on("click",function(){
		if($('.group').length < <?php echo $number_js ?>) {
            $('.clone').clone().addClass('group').removeClass('clone hide').insertBefore('.clone');
		}
	})
	
	var uri = window.location.toString();
	if (uri.indexOf("?") > 0) {
	    var clean_uri = uri.substring(0, uri.indexOf("?"));
	    window.history.replaceState({}, document.title, clean_uri);
	}
});
</script>

<script>
    new WOW().init();
</script>
