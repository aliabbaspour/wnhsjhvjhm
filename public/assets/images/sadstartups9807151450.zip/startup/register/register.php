<?php /* Template Name: Register2  */?>
<?php if(!is_user_logged_in()){?>
<?php
session_start();
$_SESSION['verify'] = 'ok';
if(isset($_POST['mobile'])){
	$mobile = $_POST['mobile'];
    $role = $_POST['role'];
	$exists_mobile = mobile_exists( $mobile );
	if($exists_mobile != -1){
		$user_id = $exists_mobile[0]->user_id;
		$mobile_verify = mt_rand(10000,99999);
		$message = $mobile_verify;
        $_SESSION['user_id'] = $user_id;
        $_SESSION['step'] = 1;
		$_SESSION['mobile_exists'] = 'ok';
		$_SESSION['mobile_verify'] = $mobile_verify;
		$_SESSION['mobile'] = $mobile;
		$time = strtotime(date("Y-m-d H:i:s"));
		$expir_time = strtotime('+2 minutes', $time);
		$_SESSION['expir_time'] = $expir_time ;
		send_sms($mobile,$message);
		wp_redirect(home_url('/verify/?step=2'));
        //wp_redirect(home_url('/startup/?step=3'));
		//wp_redirect(home_url("/follow-up/?status=exists&mobile=$mobile"));
	}else{
		$mobile_verify = mt_rand(10000,99999);
		$user_name = 'u'.randomString(8);
		$userdata  = array(
		    'user_login' =>  $user_name,
		    'user_pass'  =>  'barekat'.$mobile_verify.'@0071',
		);
		$user_id = wp_insert_user( $userdata );
        update_user_meta($user_id,'mobile',$mobile);
		update_user_meta($user_id,'steps',1);
		
        $message = $mobile_verify;
        $_SESSION['user_id'] = $user_id;
        $_SESSION['step'] = 1;
		$_SESSION['mobile_verify'] = $mobile_verify;
		$_SESSION['mobile'] = $mobile;
		/*
		$headers .= "MIME-Version: 1.0\r\n";
		$headers .= "Content-Type: text/html;charset=UTF-8" . "\r\n";
		$message_email = "<html><body>";
		$message_email .= "<div style='width:90%; margin:0 auto; background:#eee; padding:20px; border-radius:5px;'>
								<h2 style='color:#2D6CA2; text-align:center;'>
									 کدرهگیری جهت ادامه روند شما در سایت صد استـــارت آپ : <br /><span style='color:#ff9b9b; text-align:center; margin-top:15px;'>$code</span> 
								</h2>
					   </div>";
		$message_email .= "</body></html>";
		$subject = "ثبت نام در 100 استارت آپ";
	    $email = $_POST['email'];
		wp_mail($email, $subject, $message_email, $headers);
		*/
		
		send_sms($mobile,$message);
		wp_redirect(home_url('/verify/?step=2'));
	}
}
if(array_key_exists('user_id',$_SESSION) && !empty($_SESSION['user_id'])) {
    $user_id = $_SESSION['user_id'];
    $user_info = get_userdata($user_id);
    $first_name = $user_info->first_name;
    $last_name = $user_info->last_name;
    $email = $user_info->user_email;
    $mobile = get_user_meta($user_id,'mobile',true);
    $linkedin =  get_user_meta($user_id,'linkedin',true) ;
}
?>
<?php get_header();?>
<style>
header , footer ,.mobile{
	display: none;
}
.hide-tab{
	display: none;
}
</style>
<div id="section-step" class="container-fluide  min-100vh flex-center"> 
	<div class="container pad-20 pad-step pad-50-tmob">
		<div id="section-step-content" class="colm8 colm10-tab colm margin-auto pad-40 pad-20-tab pad-10-mob bg-white spacer-t40 spacer-b40">
			<div>
				<?php require_once 'steps.php'; ?>
			</div>
			<div class="colm10 colm11-tab colm margin-auto pad-5-mob">
				<div class="pad-b20">
					<h2 class="font-s30 color6">خوش آمدید</h2>
					<p class="color-darkgray font-s14 align-justify pad-t15">در حال انتقال سرور</p>
				</div>
				<div class="spacer-t5">
					<!---<form method="post" class="smart-validate" >
						<div class="frm-row pad-5 colm colm9 margin-auto">
                            <label for="mobile" class="gui-label pad-5">تلفن همراه </label>
							<label class="relative">
								<span class="icon-gui flex-center"><i class="fa fa-phone vertical"></i></span>
								<input dir="ltr" type="tel" placeholder="091212345678" class="gui-input sans-digit englishnum number-input" data-msg-required="لطفا شماره همراه خود را وارد کنید" name="mobile" data-rule-customphone="true" id="mobile" value="<?php if($mobile) echo $mobile;?>" required>
							</label>
						</div>
						<div class="align-left spacer-t40">
			     			<button type="submit" class="btn-web colm" >مرحله بعد </button>
						</div>
					</form>--->
				</div>
			</div>
		</div>
	</div>
</div>
<?php get_footer() ?>
<?php }else{
	wp_redirect(home_url('/dashboard'));
}?>


<?php 
$headers[] = 'From: Me Myself <support@100startup.ir>';
 
wp_mail( 'golchin.saeed@gmail.com', 'subject', 'test',$headers);
mail( 'golchin.saeed@gmail.com', 'subject', 'test');
?>