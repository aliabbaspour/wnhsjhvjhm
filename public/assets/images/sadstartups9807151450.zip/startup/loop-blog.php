<div class="colm colm4 pull-right pad-5">
	<div class="blog-content relative">
		<div class="blog-image responsive">
			<a href="<?php the_permalink() ?>">
				<?php the_post_thumbnail('medium-crop') ?>
			</a>
		</div>
		<div class="blog-title absolute pad-5 colm12">
			<a class="font-s13 color-white" href="<?php the_permalink() ?>">
				<?php the_title();?>
			</a>
		</div>
	</div>
</div>