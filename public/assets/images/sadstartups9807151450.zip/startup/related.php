<div class="related-post">
	<ul>
		<?php
		$category = wp_get_post_categories($post -> ID);
		//$tags = wp_get_post_tags($post->ID);
		$args = array('post__not_in' => array($post -> ID), 'showposts' => 10, 'category__in' => $category/*,'tag__in'=>$tags*/);
		query_posts($args);
		?>
		<?php while(have_posts()):the_post()
		?>
		<li class="colm colm6 pull-right">
			<a href="<?php the_permalink() ?>"> <?php the_title()?></a>
		</li>
		<?php endwhile; ?>
	</ul>
	<div class="clearfix"></div>
</div>