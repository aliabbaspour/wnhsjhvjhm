<?php //Template Name: api ?>
<?php
header("Content-type: application/json; charset=utf-8");

if ($_GET['field'] ) {
	$name = $_GET['field'];
	$args = array('role' => 'managers', 'search' => '*' . esc_attr($search_term) . '*', 'fields' => 'all', 'meta_query' => array('relation' => 'OR', array('key' => 'ID', 'value' => $name, 'compare' => 'LIKE'), array('key' => 'display_name', 'value' => $name, 'compare' => 'LIKE'), array('key' => 'first_name', 'value' => $name, 'compare' => 'LIKE'), array('key' => 'last_name', 'value' => $name, 'compare' => 'LIKE'), array('key' => 'user_login', 'value' => $name, 'compare' => 'LIKE'), array('key' => 'email', 'value' => $name, 'compare' => 'LIKE'), ));

	$user_query = new WP_User_Query($args);

	$users = $user_query -> get_results();
	$referee = array();
	foreach ($users as $uq) {
		if(in_array('referee',get_user_meta($uq->ID , 'roles' , true))){
			$referee[] = array('id' => $uq -> ID, 'name' => $uq -> display_name, );
		}
	}

	$json_referee = json_encode($referee);
	echo $json_referee;
}elseif($_GET['field']  && $_GET['type'] == 'companion'){
	$name = $_GET['companion'];
	$args = array('role' => 'managers', 'search' => '*' . esc_attr($search_term) . '*', 'fields' => 'all', 'meta_query' => array('relation' => 'OR', array('key' => 'ID', 'value' => $name, 'compare' => 'LIKE'), array('key' => 'display_name', 'value' => $name, 'compare' => 'LIKE'), array('key' => 'first_name', 'value' => $name, 'compare' => 'LIKE'), array('key' => 'last_name', 'value' => $name, 'compare' => 'LIKE'), array('key' => 'user_login', 'value' => $name, 'compare' => 'LIKE'), array('key' => 'email', 'value' => $name, 'compare' => 'LIKE'),array('key' =>  'roles' , 'value' =>  serialize('leader'), 'compare' => 'LIKE') ));
	$user_query = new WP_User_Query($args);
	$users = $user_query -> get_results();
	$referee = array();
	foreach ($users as $uq) {
		$companion[] = array('id' => $uq -> ID, 'name' => $uq -> display_name, );
	}
	$json_companion = json_encode($companion);
	echo $json_companion;
}
?>