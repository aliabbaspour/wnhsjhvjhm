<?php
$user_id = get_query_var( 'id_m');
if(isset($_POST['btn_companion'])){
	if(!empty($_POST['companion'])) update_user_meta($user_id,'companion',$_POST['companion']);
	update_user_meta($user_id,'status_process','chose_referee');
	wp_redirect(home_url("/information/$user_id"));
}
$mentor_name  = get_user_meta($user_id,'mentor_name',true);
$status_process  = get_user_meta($user_id,'status_process',true);
$companion_id = get_user_meta($user_id , 'companion' , true);
$companion  = get_user_meta($companion_id,'first_name',true).' '.get_user_meta($companion_id,'last_name',true);

if($status_process=='companion') $disable = ''; else $disable = 'disabled';

?>
<form method="post" id="choosementor">
	<div class="frm-row pad-20">
		<div class="colm8 colm margin-auto pad-5">
			<label for="" class="gui-label pad-5 align-right">راهبر پیشنهاد شده:</label>
			<label class="relative">
				<span class="icon-gui flex-center"><i class=" fa fa-chalkboard-teacher vertical"></i></span>
				<input type="text" class="gui-input sans-digit" value="<?=  $companion ?? ""; ?>" disabled>
			</label>
		</div>
		<div class="colm8 colm margin-auto pad-5">
			<label for="" class="gui-label pad-5 align-right">انتخاب راهبر:</label>
			<label class="relative"> 
				<span class="icon-gui flex-center"><i class=" fa fa-chalkboard-teacher vertical"></i></span>
				<input type="text" oninput="searchApi('search_companion','companion-result' , 'companion')"  class="search_companion referee-name gui-input sans-digit" value="<?=  $companion ?? ""; ?>" placeholder="مثال : علی عباسپور"  <?php echo $disable?>>
				<input type="hidden" class="referee-id" name="companion" value="<?=  $companion_id ?? ""; ?>"/>
				<div class="companion-result"></div>
			</label>
		</div>
		<div class="clearfix"></div>
	</div>
    <div class="align-center">
    	<button name="btn_companion" type="submit" class="btn-panel pad-10 color-white iransans" <?php echo $disable?>>بروزرسانی</button>
	</div>
</form>