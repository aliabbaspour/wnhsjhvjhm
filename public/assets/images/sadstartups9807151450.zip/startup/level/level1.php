
<form method="post">
    <div class="pad-t40 pad-5">
        <label for="" class="pad-5 color-blue font-s13 bold font-w300">نظر منتور</label>
        <label class="relative">
            <textarea name="admin_comment" class="gui-input sans-digit" id="admin-comment"></textarea>
        </label>
    </div>
    <div class="pad-t10 pad-b15">
        <button type="submit" name="status" value="failed" class="icon-dabir times transparent-btn pad-5 iransans align-center">
            <span><i class="fa fa-times"></i></span>
            <p class="font-s11">رد</p>
        </button>
        <button type="submit" name="status" value="confirm_financial" class="icon-dabir transparent-btn accept pad-5 iransans align-center">
            <span><i class="fa fa-check"></i></span>
            <p class="font-s11">تایید</p>
        </button>
    </div>
</form>



