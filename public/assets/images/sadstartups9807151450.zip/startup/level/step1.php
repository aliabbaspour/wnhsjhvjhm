<?php
$current_user = wp_get_current_user();
$current_user_id = $current_user->ID;
$user_id = get_query_var( 'id_m');

$datar = array(
		'query'=>array(
			array(
				'key'=>'author_id',
				'value'=>$current_user_id,
				'compare'=>'='
			),
			array(
				'key'=>'user_id',
				'value'=>$user_id,
				'compare'=>'='
			)
		)
	);
$accept_referee = query_data('operational',$datar);

if(isset($_POST['btn_select_referee'])){
		$date = current_time( 'mysql' );
	
		if(!empty($accept_referee[0]->id)){
		$query = array(
			'ID'=>$accept_referee[0]->id
		);
		$data = array(
			'referee1'=>$_POST['referee1'],
			'referee2'=>$_POST['referee2'],
			'referee3'=>$_POST['referee3'],
			'referee4'=>$_POST['referee4'],
			'date'=>$date,
			'status'=>$data_referee[0]->status+1
		);
		update_datas('operational',$data,$query);
		}else{
			$data =array( 
			'user_id'=>$user_id,
			'author_id'=>$current_user_id,
			'referee1'=>$_POST['referee1'],
			'referee2'=>$_POST['referee2'],
			'referee3'=>$_POST['referee3'],
			'referee4'=>$_POST['referee4'],
			'date'=>$date,
			'status'=>1
		);
		$select_referee = insert_data('operational', $data);
			
			
		}
	
	

	
	
	if(!empty($_POST['referee1'])) update_user_meta($user_id,'referee1',$_POST['referee1']);
	if(!empty($_POST['referee2'])) update_user_meta($user_id,'referee2',$_POST['referee2']);
	if(!empty($_POST['referee3'])) update_user_meta($user_id,'referee3',$_POST['referee3']);
	if(!empty($_POST['referee4'])) update_user_meta($user_id,'referee4',$_POST['referee4']);
	update_user_meta($user_id,'status_process','accept_modir');
	wp_redirect(home_url("/information/$user_id"));
}
	$status_process  = get_user_meta($user_id,'status_process',true);

if($status_process=='chose_referee') $disable = ''; else $disable = 'disabled';

?>
<form method="post" id="choosementor">
	<div class="frm-row pad-20">
		<?php for ($i=1; $i < 5 ; $i++) {?> 
			<?php 
				$referee = get_user_meta($user_id,"referee$i",true); 
				$referee = get_user_meta($referee,'first_name',true).' '.get_user_meta($referee,'last_name',true);
				$y='referee'.$i; 
				
				
				$id_referee = $accept_referee[0]->$y;
				$user = get_user_by( 'id', $id_referee );
				//print_r($id_referee);
				//$first = $user->first_name.' '.$user->last_name;
			?>
			<div class="colm6 colm pull-right pad-5">
				<label for="referee<?php echo $i ?>" class="gui-label pad-5">داور <?php echo $i ?> :</label>
				<label class="relative">
					<span class="icon-gui flex-center"><i class="fa fa-chalkboard-teacher vertical"></i></span>
					<input type="text" class="referee-name gui-input sans-digit referee-search" oninput="searchApi('referee-search','referee-result' , 'referee' )" id="referee<?php echo $i ?>" value="<?php echo $referee;?>" placeholder="مثال : علی عباسپور" <?php echo $disable?> >
					<input type="hidden" class="referee-id" name="referee<?php echo $i ?>" />
					<div class="referee-result"></div>
				</label>
			</div>
		<?php }?>
		<div class="clearfix"></div>
	</div>
    <div class="align-center">
    	<button type="submit" name="btn_select_referee" class="btn-panel pad-10 color-white iransans" <?php echo $disable?>>بروزرسانی</button>
	</div>
</form>