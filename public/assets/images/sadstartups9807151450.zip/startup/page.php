<?php get_header(); ?>
<div class="container-fluid">
    <div class="container">
    
    </div>
</div>
<?php get_footer(); ?>

