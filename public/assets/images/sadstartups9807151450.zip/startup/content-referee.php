<div id="content-referee" class="container-fluid">
	<div class="container pad-b40">
		<div class="colm9 colm margin-auto">
			<div class="pad-b25 font-s18 pad-r20">
				<span class="color6 font-w5">داوران طرح</span>
			</div>
			<div class="referee-body">
				<?php $args = array( 'showposts' => 3 , 'post_type' => 'referee' ) ?>
				<?php query_posts($args) ?>
				<?php while(have_posts()):the_post() ?>
					<div class="colm4 colm pull-right pad-20 align-center">
						<div class="pad-20 academi-inner">
							<div class="academi-img">
								<?php the_post_thumbnail('thumbnail') ?>
							</div>
							<div class="font-s17 color3 pad-t20 pad-b5 font-w500">
								<?php the_title() ?>
							</div>
							<div class="academi-excerpt font-s13 color6">
								<?php the_excerpt() ?>
							</div>
						</div>
					</div>
				<?php endwhile;wp_reset_query() ?>
				<div class="clearfix"></div>
			</div>
		</div>
	</div>
</div>