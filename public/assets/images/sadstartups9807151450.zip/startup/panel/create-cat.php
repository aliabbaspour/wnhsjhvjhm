<?php // template name: create-cat ?>
<?php

$user = wp_get_current_user();
$user_id = $user->ID;
$allowed_roles_high = array('administrator','editor');
if(is_user_logged_in() && (array_intersect($allowed_roles_high , $user->roles)) ){
    if(isset($_POST['submit'])){
    $args = array(
        'description'=>$_POST['cat_expressions'],
        'slug'=>$_POST['cat_slug'],
    );
    $term_id = wp_insert_term($_POST['cat_name'],'category',$args);
        if ( ! is_wp_error( $term_id ) )
        {
            $cat_id = $term_id['term_id'];
            require_once(ABSPATH . 'wp-admin/includes/image.php');
            require_once(ABSPATH . 'wp-admin/includes/file.php');
            require_once(ABSPATH . 'wp-admin/includes/media.php');
            $attachment_id = media_handle_upload('cat_logo',0);
            if(is_wp_error($attachment_id)){
                $error = 2 ;
            }else{
                add_term_meta($cat_id,'cat_logo',$attachment_id);
            }
        }
        else
        {
            $error = 1 ;
        }
    }
?>

<?php get_header(); ?>
<?php get_header('admin'); ?>
<?php if($error == 1) echo'err' ?>
    <?php if($error == 2) echo'err2' ; ?>
<div class="colm8 colm12-tab colm margin-auto spacer-t30 wow fadeInDown"  data-wow-duration="1.5s">
    <form action="" method="post" class="smart-validate" enctype="multipart/form-data">
        <div class="body-form relative">
            <div class="bg-chart4 body-form-top absolute flex-center">
                <div class="fa fa-file vertical font-s30 color-white"></div>
            </div>
            <div class="absolute title-panel">
                <h3 class="font-w300 font-s18 pad-r25">ایجاد دسته بندی</h3>
            </div>
            <div class="pad-30">
                <div class="frm-row spacer-t30">
                    <div class="colm5 colm pull-right pad-5">
                        <label for="cat-title" class="gui-label pad-5">نام دسته بندی :</label>
                        <label class="relative">
                            <span class="icon-gui flex-center"><i class=" fa fa-folder-plus vertical"></i></span>
                            <input type="text" class="gui-input sans-digit" id="cat-title" name="cat_name" required>
                        </label>
                    </div>
                    <div class="colm5 colm pull-right pad-5">
                        <label for="cat-slug" class="gui-label pad-5">نامک :</label>
                        <label class="relative">
                            <span class="icon-gui flex-center"><i class=" fa fa-font vertical"></i></span>
                            <input type="text" class="gui-input sans-digit" id="cat-slug" name="cat_slug" data-rule-lettersonlyen="true" required>
                        </label>
                    </div>
                    <div class="colm2 colm pull-right pad-5">
                        <div>
                            <div class="fileUpload blue-btn btn width100">
                                <span>افزودن لوگو دسته</span>
                                <input type="file" name="cat_logo" class="uploadlogo" id="imgInp" accept="image/*" onchange="loadFile(event)" required>
                            </div>
                        </div>
                    </div>
                    <div class="colm12 colm pull-right pad-5">
                        <label for="cat_expressions" class="gui-label pad-5">توضیحات :</label>
                        <label class="relative">
                            <textarea cols="70" rows="3" class="gui-input sans-digit" id="cat_expressions" name="cat_expressions" data-rule-lettersonly="true"></textarea>
                        </label>
                    </div>
                    <div class="colm12 colm">
                        <img id="output" class="pre-logo hide">
                    </div>

                </div>
                <div class="margin-auto align-center pad-t10">
                    <button type="submit" name="submit" class="btn-panel pad-10 color-white iransans">افزودن</button>
                </div>
        </div>
    </form>

</div>




<?php get_footer(); ?>
<?php get_footer('admin'); ?>
<?php }else{wp_redirect(home_url('/404'));} ?>
<style>
    header , footer {
        display: none;
    }
    .form-height {
        height: 650px;
    }
    .pre-logo {
        width:  200px;
        height: 200px;
        margin-right: auto;
        margin-left: auto;
        border-radius: 50%;
        border: 2px double #ebebeb;
        padding: 6px;
    }
    .hide {
        display: none;
    }

    .pad-ri {
        padding-right: 25%;
    }
    .blue-btn:hover,
    .blue-btn:active,
    .blue-btn:focus,
    .blue-btn {
        background: transparent;
        border: solid 1px #27a9e0;
        border-radius: 20px;
        color: #27a9e0;
        font-size: 16px;
        text-align: center;
        margin-bottom: 20px;
        outline: none !important;
        padding: 6px 20px;
    }

    .fileUpload {
        position: relative;
        overflow: hidden;
        height: 43px;
        margin-top: 30px;
    }

    .fileUpload input.uploadlogo {
        position: absolute;
        top: 0;
        right: 0;
        margin: 0;
        padding: 0;
        font-size: 20px;
        text-align: center;
        cursor: pointer;
        opacity: 0;
        filter: alpha(opacity=0);
        width: 100%;
        height: 42px;
    }

    /*Chrome fix*/
    input::-webkit-file-upload-button {
        cursor: pointer !important;
        height: 42px;
        width: 100%;
    }
</style>
<script>
    jQuery(document).ready(function($) {
        $('.uploadlogo').change(function() {
            $('.pre-logo').removeClass('hide').addClass('show');
        })
    })

    new WOW().init();

    var loadFile = function(event) {
        var output = document.getElementById('output');
        output.src = URL.createObjectURL(event.target.files[0]);
    };

</script>