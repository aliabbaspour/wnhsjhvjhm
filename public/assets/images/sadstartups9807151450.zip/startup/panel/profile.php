<?php /*Template Name: profile */ ?>
<?php
$user = wp_get_current_user();
$user_id = $user->ID;
$user_role = $user->roles[0];
if(is_user_logged_in() ){
?>
<?php get_header() ?>
<?php get_header('admin') ?>
<style>
	.hide-tab{
		display: none;
	}
</style>
<div class="colm8 colm12-tab colm margin-auto spacer-t50">
	<form action="" method="post" class="smart-validate" enctype="multipart/form-data">
			<div class="body-form relative">
				<div class="bg-chart4 body-form-top absolute flex-center">
					<div class="fa fa-address-card vertical font-s30 color-white"></div>
				</div>
				<div class="absolute title-panel">
					<h3 class="font-w300 font-s18 pad-r25">پروفایل</h3>
				</div>
				 <div class="pad-30"> 
					<div class="frm-row  spacer-t30">
							<div class="colm6 colm pull-right pad-5">
								<label for="mobilel" class="gui-label pad-5"> شماره همراه:</label>
								<label class="relative">
									<span class="icon-gui flex-center"><i class=" color-black fa fa-mobile"></i></span>
									<input dir="ltr" class="gui-input sans-digit" name="mobilel[]" data-rule-customphone="true" value="<?php ?>" autocomplete="off" placeholder="09XXXXXXX" required>
								</label>
							</div>
							<div class="colm6 colm pull-right pad-5">
								<label for="email-l" class="gui-label pad-5">ایمیل :</label>
								<label class="relative">
									<span class="icon-gui flex-center"><i class=" color-black fa fa-at vertical"></i></span>
									<input dir="ltr" type="email" class="gui-input sans-digit" name="email_l[]" value="<?php ?>"  placeholder="example@gmail.com" required>
								</label>
							</div>
							<div class="clearfix"></div>
						</div>
						<div class="frm-row">
							<div class="colm6 colm pull-right pad-5">
								<label class="gui-label pad-5">لینکدین :</label>
								<label class="relative">
									<span class="icon-gui flex-center"><i class=" color-black fab fa-linkedin-in vertical"></i></span>
									<input dir="ltr" type="text" class="gui-input sans-digit" placeholder="mylinkedin" value="<?php ?>"  name="linkdinl[]">
								</label>
							</div>
							<div class="colm6 colm pull-right pad-5">
								<label for="birthdayl" class="gui-label pad-5"> تاریخ تولد :</label>
								<label class="relative">
									<span class="icon-gui flex-center"><i class=" color-black fa fa-birthday-cake"></i></span>
									<input dir="ltr" class="gui-input sans-digit datepicker" name="birthdayl[]" value="<?php ?>"  autocomplete="off" placeholder="1398/10/02">
								</label>
							</div>
							
							<div class="clearfix"></div>
						</div>
						<div class="frm-row">
							<div class="colm6 colm pull-right pad-5">
								<label for="expertisel" class="gui-label pad-5">تخصص:</label>
								<label class="relative">
									<span class="icon-gui flex-center"><i class="color-black fa fa-laptop-code vertical"></i></span>
									<input type="text" class="gui-input sans-digit" name="expertisel[]" value="<?php ?>"  placeholder="مثال : نرم افزار" >
								</label>
							</div>
							
							<div class="colm6 colm pull-right pad-5">
								<label for="educationl" class="gui-label pad-5">تحصیلات:</label>
								<label class="relative">
									<span class="icon-gui flex-center"><i class="color-black fa fa-user-graduate vertical"></i></span>
									<input type="text" class="gui-input sans-digit" name="educationl[]" value="<?php  ?>"  placeholder="مثال : دکتری" >
								</label>
							</div>
							
							<div class="clearfix"></div>
						</div>
					</div>
	                <div class="margin-auto align-center pad-b25">
	                    <button type="submit" class="btn-panel pad-10 color-white iransans">بروزرسانی</button>
	                </div>
				</div>
            </div>
		</div>	
	</form>
</div>
	<style>
		header , footer{
			display: none;
		}
	</style>
<?php get_footer('admin'); ?>
<?php get_footer(); ?>
<?php }else{
	wp_redirect(home_url());
}?>