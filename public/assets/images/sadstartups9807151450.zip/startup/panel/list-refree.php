<?php //Template Name: List-referee ?>
<?php
$user = wp_get_current_user();
$user_id = $user->ID;
$user_role = $user->roles;
$roles =get_user_meta($user_id,'roles',true);
$allowed_all= array('editor', 'administrator');
if(is_user_logged_in() && (array_intersect($allowed_all, $user->roles )) || (in_array('operational', $roles )) ){
	$args=array(
    'number' => -1,
    'meta_query' => array(
		array(
			'key'     => 'roles',
			'value'   => serialize(strval('referee')),
			'compare' => 'LIKE',
		)
	),
	
);
$user_query = new WP_User_Query($args); 

$query_referee = array(
	'meta_key' => 'status_davar',
	'meta_value' => 'davari',
);
$count_referee = query_count('usermeta',$query_referee);

$query_pending = array(
	'meta_key' => 'status',
	'meta_value' => 'pending',
);
$count_pending = query_count('usermeta',$query_pending);

$status_davar	= get_user_meta($user_id,'status_davar',true);
$status			= get_user_meta($user_id,'status',true);
?>
<?php get_header() ?>
<?php get_header('admin') ?>
<style>
	.hide-tab{
		display: none;
	}
</style>
<div class="pad-t20">
	<div class="frm-row pad-b30 flex-center-row">
		<div class="colm4 colm12-tab colm pull-right pad-15 pad-0 spacer-b25-mob spacer-b30-tab spacer-t25-mob spacer-t30-tab wow fadeInLeftBig" data-wow-duration="2s">
			<div class="body-form pad-15 relative">
				<a href="#" class="pad-b10 color6">
					<div class="bg-chart1 icon-cat-panel absolute  flex-center">
						<i class="fa fa-times vertical font-s30 color-white"></i>
					</div>
					<div class="align-right">
						<h4 class="font-w200 font-s15">تیم های داوری نشده</h4>
						<h4 class="font-w300 font-s20 title-panel"><?php echo $count_pending; ?></h4>
					</div>
				</a>
				<div class="border-t-chart font-w200 font-s12 pad-t10">
					<span class="font-w300">
						<i class="fa fa-chart-bar pad-l5 verticall"></i>
					</span>
					<span>
					آمار تیم های داوری نشده
					</span>
				</div>
			</div>
		</div>
		<div class="colm4 colm12-tab colm pull-right pad-15 pad-0 spacer-b25-mob spacer-b30-tab wow wow zoomIn" data-wow-duration="2s">
			<div class="body-form pad-15 relative">
				<a href="#" class="pad-b10 color6">
					<div class="bg-chart3 icon-cat-panel absolute  flex-center">
						<i class="fa fa-users vertical font-s30 color-white"></i>
					</div>
					<div class="align-right">
						<h4 class="font-w200 font-s15">تمام داوران</h4>
						<h4 class="font-w300 font-s20 title-panel"><?php echo count($user_query->get_results()) ?></h4>
					</div>
				</a>
				<div class="border-t-chart font-w200 font-s12 pad-t10">
					<span class="font-w300">
						<i class="fa fa-chart-bar pad-l5 verticall"></i>
					</span>
					<span>
						آمار تمام داوران
					</span>
				</div>
			</div>
		</div>
		<div class="colm4 colm12-tab colm pull-right pad-15 pad-0 spacer-b25-mob spacer-b30-tab wow fadeInRightBig" data-wow-duration="2s">
			<div class="body-form pad-15 relative">
				<a href="#" class="pad-b10 color6">
					<div class="bg-chart2 icon-cat-panel absolute flex-center">
						<i class=" fa fa-check vertical font-s30 color-white"></i>
					</div>
					<div class="align-right">
						<h4 class="font-w200 font-s15">تیم های داوری شده</h4>
						<h4 class="font-w300 font-s20 title-panel"><?php echo $count_referee; ?></h4>
					</div>
				</a>
				<div class="border-t-chart font-w200 font-s12 pad-t10">
					<span class="font-w300">
						<i class="fa fa-chart-bar pad-l5 vertical"></i>
					</span>
					<span>
						آمار تیم های داوری شده
					</span>
				</div>
			</div>
		</div>
		<div class="clearfix"></div>
	</div>
	<div class="body-form relative  wow fadeInUp" data-wow-duration="2s">
		<div class="bg-chart2 body-form-top absolute flex-center">
			<i class="fa fa-users vertical font-s30 color-white"></i>
		</div>
		<div class="absolute title-panel">
			<h3 class="font-w300 font-s18">تمام داوران</h3>
		</div>
		<div class="frm-row pad-t25-mob pad-t30-tab">
			<div class="colm4 colm pull-left pull-none relative pad-20">
			     <input class="input-panel align-right" placeholder="جستجو کنید..." type="search" name="" value=""  >
			     <span class="bar"></span>
		    </div>
		</div>
		<div class="frm-row pad-t40">
			<div class="overflow-scroll pad-b40">
				<?php
					$allowedRoles = array('editor', 'administrator','managers');
					$number=-1;
					$list = new list_users();
					$list->referee($allowedRoles , $number);
				?>
			</div>
		</div>
	</div>
</div>
<style>
	header , footer{
		display: none;
	}
</style>
<?php get_footer('admin'); ?>
<?php get_footer(); ?>
<?php }else{
	wp_redirect(home_url());
}?>
<script>
	new WOW().init();
</script>