<?php //Template Name: Massage-box ?>
<?php
$user = wp_get_current_user();

if(is_user_logged_in()){

?>
<?php get_header() ?>
<?php get_header('admin') ?>
<div class="pad-t20">
    <div class="frm-row colm12 colm">
        <div class="body-form relative">
            <div class="bg-chart5">
                <i class="fa fa-address-book"></i>
            </div>
        </div>
    </div>
</div>
<style>
header ,footer{
    display:none;
}
</style>
<?php get_footer('admin'); ?>
<?php get_footer(); ?>

<?php }else{
    wp_redirect(home_url());
}?>


