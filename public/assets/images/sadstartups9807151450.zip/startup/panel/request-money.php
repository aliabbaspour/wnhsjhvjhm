<?php /*  Template Name: request-money     */ ?>
<?php
$user = wp_get_current_user();
$user_id = $user->ID;
$user_role = $user->roles;
$roles =get_user_meta($user_id,'roles',true);
$allowed = array('subscriber', 'administrator');
if (is_user_logged_in() && (array_intersect($allowed, $roles)) || array_intersect($allowed, $user->roles)) {

    $args = array('number' => -1,'role__in' => array( 'referee' ));
    $user_query = new WP_User_Query($args);
    $args = array('number' => -1,'role__in' => array( 'investor' ));
    $user_query_investor = new WP_User_Query($args);

    $args = array(
        'number' => -1,
        'role__in' => array( 'coach' ),
    );
    $user_query_coach = new WP_User_Query($args);
    $args = array(
        'number' => -1,
        'role__not_in' => array('editor', 'administrator','managers','investor','coach','secretariat','referee','operational'),
    );
    $user_query_sub = new WP_User_Query($args);

    if(isset($_POST['request_title'])){
        $post_request  = array(
            'post_type'=>'requestmoney',
            'post_title'=>$_POST['request_title'],
            'post_content'=>$_POST['request_expression'],
            'post_status'=>'publish',
            'author'=>$user_id
        );
        $request_id = wp_insert_post($post_request);

        update_post_meta($request_id,'status',"pending");
        update_post_meta($request_id,'request_cat',$_POST['request_cat']);
        update_post_meta($request_id,'request_money',$_POST['request_money']);

    }


    function count_requests($query = NULL){
        global $user;
        $args = array(
            'post_type' =>  'requestmoney',
            'author'=>$user->ID,
            'showposts' =>  '-1',
            'meta_query'    =>  array(
                'relation '  => 'OR',
                $query

            )
        );

        return count(get_posts($args));
    }
    $query_pending = array(
        'key' =>  'status',
        'value' =>  'pending',
    ) ;

    $count_pending = count_requests($query_pending);
    $count_all =  count_requests();

    ?>
    <?php get_header() ?>
    <?php get_header('admin') ?>
    <div class="all">
        <div class="frm-row">
            <div>
                <div class="colm3 colm12-tab colm pull-right pad-15 pad-5-mob spacer-b25-mob wow fadeInDown" data-wow-duration="1s">
                    <div class="body-form pad-15 relative">
                        <div class="pad-b10">
                            <div class="bg-chart2 icon-cat-panel absolute  flex-center">
                                <i class="fa fa-clipboard-check vertical font-s30 color-white"></i>
                            </div>
                            <div class="align-right">
                                <a href="#" class="color-darkgray font-w200 font-s15">تایید شده</a>
                                <h4 class="font-w300 font-s20 title-panel"><?php echo count($user_query->get_results()) ?></h4>
                            </div>
                        </div>
                        <div class="border-t-chart font-w200 font-s12 pad-t10">
						<span class="font-w300">
							<i class="fa fa-chart-bar pad-l5 verticall"></i>
						</span>
                            <span>آمار درخواست های تایید شده</span>
                        </div>
                    </div>
                </div>
                <div class="colm3 colm12-tab colm pull-right pad-15 wow pad-5-mob spacer-b25-mob fadeInDown" data-wow-duration="1s">
                    <div class="body-form pad-15 relative">
                        <div class="pad-b10">
                            <div class="bg-chart1 icon-cat-panel absolute flex-center">
                                <i class="fa fa-window-close vertical font-s30 color-white"></i>
                            </div>
                            <div class="align-right">
                                <a href="#" class="color-darkgray font-w200 font-s15">تایید نشده</a>
                                <h4 class="font-w300 font-s20 title-panel"><?php echo count($user_query->get_results()) ?></h4>
                            </div>
                        </div>
                        <div class="border-t-chart font-w200 font-s12 pad-t10">
						<span class="font-w300">
							<i class="fa fa-chart-bar pad-l5 vertical"></i>
						</span>
                            <span>آمار درخواست های تایید نشده</span>
                        </div>
                    </div>
                </div>
                <div class="colm3 colm12-tab colm pull-right pad-15 wow pad-5-mob spacer-b25-mob fadeInDown" data-wow-duration="2s">
                    <div class="body-form pad-15 relative">
                        <div class="pad-b10">
                            <div class="bg-chart4 icon-cat-panel absolute flex-center">
                                <i class="fa fa-hourglass-half  vertical font-s30 color-white"></i>
                            </div>
                            <div class="align-right">
                                <a href="<?php echo home_url('/request-money/?status=pending') ?>" class="color-darkgray font-w200 font-s15">در حال انتظار</a>
                                <h4 class="font-w300 font-s20 title-panel"><?php echo $count_pending?></h4>
                            </div>
                        </div>
                        <div class="border-t-chart font-w200 font-s12 pad-t10">
						<span class="font-w300">
							<i class="fa fa-chart-bar pad-l5 vertical"></i>
						</span>
                            <span>آمار درخواست های در حال انتظار</span>
                        </div>
                    </div>
                </div>
                <div class="colm3 colm12-tab colm pull-right pad-15 wow pad-5-mob spacer-b25-mob fadeInDown" data-wow-duration="2.5s">
                    <div class="body-form pad-15 relative">
                        <div class="pad-b10">
                            <div class="bg-chart3 icon-cat-panel absolute  flex-center">
                                <i class="fa fa-poll-h vertical font-s30 color-white"></i>
                            </div>
                            <div class="align-right">
                                <a href="#" class="color-darkgray font-w200 font-s15">همه درخواست ها</a>
                                <h4 class="font-w300 font-s20 title-panel"><?php echo $count_all; ?></h4>
                            </div>
                        </div>
                        <div class="border-t-chart font-w200 font-s12 pad-t10">
					<span class="font-w300">
						<i class="fa fa-chart-bar pad-l5 vertical"></i>
					</span>
                            <span>آمار همه درخواست ها</span>
                        </div>
                    </div>
                </div>
                <div class="clearfix"></div>
            </div>
        </div>
        <div class="spacer-t20">
            <div class="colm9 colm12-tab colm12-tab colm pull-right pad-15 pad-5-mob wow slideInRight" data-wow-duration="1.5s">
                <div class="body-form relative pad-b10">
                    <div class="payam">
                        <div class="bg-chart6 body-form-top absolute flex-center">
                            <i class="fa fa-history vertical font-s30 color-white"></i>
                        </div>
                        <div class="absolute title-panel">
                            <h3 class="font-w300 font-s18">تاریخچه درخواست ها</h3>
                        </div>
                    </div>
                    <div class="pad-table overflow-scroll">
                        <table class="table color6">
                            <thead>
                            <tr>
                                <th class="center">عنوان</th>
                                <th class="center">دسته</th>
                                <th class="center">تاریخ</th>
                                <th class="center">مبلغ</th>
                                <th class="center">وضعیت</th>
                                <th class="center">جزئیات</th>
                            </tr>
                            </thead>
                            <tbody>
                            <?php
                            $args = array(
                                'post_per_page' => -1,
                                'post_type' => 'requestmoney',
                                'author' => $user_id
                            );
                            query_posts($args);
                            while (have_posts()):the_post();?>
                                <tr class="<?php echo $class; ?>">
                                    <td class="center"><?php the_title();?></td>
                                    <td class="center"><?php echo get_post_meta($post->ID,'request_cat',true); ?></td>
                                    <td class="center"><?php the_time('Y/m/d H:i');?></td>
                                    <td class="center"><?php echo get_post_meta($post->ID,'request_money',true); ?></td>
                                    <td class="center"><?php action_list_request($post->ID) ?></td>
                                    <td class="center">
                                        <a class="color-silver" title="نمایش" href="<?php the_permalink();?>"
                                        <span>
	                                	<i class="align-center font-s20 fa fa-address-card"></i>
									</span>
                                        </a>
                                    </td>
                                </tr>
                            <?php endwhile; wp_reset_query();?>
                            </tbody>
                        </table>
                    </div>
                </div>
            </div>
        </div>

        <div class="colm3 colm pad-t15 pull-left wow slideInLeft" data-wow-duration="1.5s">
            <div class="frm-row">
                <button class="btn-requste iransans colm12 colm">ایجاد درخواست</button>
            </div>
            <!-- modal -->
            <div class="modal-overlay">
                <div class="modal">

                    <a class="close-modal">
                        <svg viewBox="0 0 20 20">
                            <path fill="#000000" d="M15.898,4.045c-0.271-0.272-0.713-0.272-0.986,0l-4.71,4.711L5.493,4.045c-0.272-0.272-0.714-0.272-0.986,0s-0.272,0.714,0,0.986l4.709,4.711l-4.71,4.711c-0.272,0.271-0.272,0.713,0,0.986c0.136,0.136,0.314,0.203,0.492,0.203c0.179,0,0.357-0.067,0.493-0.203l4.711-4.711l4.71,4.711c0.137,0.136,0.314,0.203,0.494,0.203c0.178,0,0.355-0.067,0.492-0.203c0.273-0.273,0.273-0.715,0-0.986l-4.711-4.711l4.711-4.711C16.172,4.759,16.172,4.317,15.898,4.045z"></path>
                        </svg>
                    </a><!-- close modal -->

                    <div class="modal-content">
                        <form id="form_test" method="post" action="">
                            <div class="pad-15">
                                <div class="colm4 colm pull-right pad-5 pad-t20">
                                    <label for="request-title" class="pull-right font-w300 font-s15 color-blue">عنوان درخواست:</label>
                                    <label class="relative">
                                        <span class="icon-gui flex-center"><i class=" fa fa-asterisk vertical"></i></span>
                                        <input type="text" class="x gui-input sans-digit pad-t10" id="request_title" value="" name="request_title" required>
                                    </label>
                                </div>
                                <div class="colm4 colm pull-right pad-5 pad-t20">
                                    <label for="request-title" class="pull-right font-w300 font-s15 color-blue">مبلغ مورد نیاز (تومان):</label>
                                    <label class="relative">
                                        <span class="icon-gui flex-center"><i class=" fa fa-file-invoice-dollar vertical"></i></span>
                                        <input type="number" class="x gui-input sans-digit colm pad-t10" value="" id="request_money" name="request_money" data-rule-letternumbe="true" required>
                                    </label>
                                </div>
                                <div class="colm4 colm pull-right pad-5 pad-t20">
                                    <label for="prototype" class="pull-right font-w300 font-s15 color-blue">دسته</label>
                                    <label class="relative">
                                <span for="prototype" class="flex-center icon-select">
                                    <i class="fa fa-chevron-down vertical"></i>
                                </span>
                                        <select class="x gui-select sans-digit" id="request_cat" name="request_cat" required>
                                            <option value="">انتخاب کنید</option>
                                            <option value="پشتیبانی" <?php selected($request_cat,'پشتیبانی') ?>>پشتیبانی</option>
                                            <option value="نیروی انسانی" <?php selected($request_cat,'نیروی انسانی') ?>>نیروی انسانی</option>
                                            <option value="بازاریابی" <?php selected($request_cat,'بازاریابی') ?>>بازاریابی</option>
                                            <option value="هزینه نمونه های اول" <?php selected($request_cat,'هزینه نمونه های اول') ?>>هزینه نمونه های اول</option>
                                        </select>
                                    </label>
                                </div>
                                <div class="clearfix"></div>
                                <div class="colm12 colm  pad-5 pad-t20">
                                    <label for="request-title" class="pull-right font-w300 font-s15 color-blue">توضیحات:</label>
                                    <label class="relative">
                                        <textarea type="text" cols="50" rows="3" class="x gui-input sans-digit pad-t10" id="request_expression" name="request_expression" required></textarea>
                                    </label>
                                </div>

                            </div>
                        </form>
                        <div class="pad-5-mob colm7-mob">
                            <button id="disable-req" class="y colm btn-sub pointer" onclick="sentData()">ارسال<span class="loader-request"></span></button>
                        </div>
                    </div><!-- content -->
                </div><!-- modal -->
            </div><!-- overlay -->
        </div>
    </div>
    <div id="toast">
        <div id="img">وضعیت</div>
        <div id="desc">درخواست شما با موفقیت ارسال شد</div>
    </div>

    <div id="toast-err">
        <div id="img-err">وضعیت</div>
        <div id="desc-err">درخواست شما ارسال نشد دوباره تلاش کنید</div>
    </div>

    <div id="toast-not">
        <div id="img-not">وضعیت</div>
        <div id="desc-not">لطفا همه فیلد ها را پر کنید</div>
    </div>

    <style>
        header , footer{
            display: none;
        }

        .loader-request {
            border: 3px solid #f3f3f3;
            border-radius: 50%;
            border-top: 3px solid #3498db;
            width: 20px;
            height: 20px;
            animation: spin 1s linear infinite;
            -webkit-animation: spin 1s linear infinite;
            display: none;
            margin-right: auto;
            margin-left: auto;
        }

        @-webkit-keyframes spin {
            0% { -webkit-transform: rotate(0deg); }
            100% { -webkit-transform: rotate(360deg); }
        }

        @keyframes spin {
            0% { transform: rotate(0deg); }
            100% { transform: rotate(360deg); }
        }



    </style>

    <?php get_footer(); ?>
    <?php get_footer('admin'); ?>
    <script>
        new WOW().init();
    </script>

    <script>

        jQuery(document).ready(function($){
            var elements = $('.modal-overlay, .modal');

            $('.btn-requste').click(function(){
                elements.addClass('active');
            });

            $('.close-modal').click(function(){
                elements.removeClass('active');
            });


        });

        function sentData() {
            jQuery( ".y" ).prop( "disabled", true );
            jQuery('.loader-request').css('display','block');
            var request_title = jQuery('#request_title').val();
            var request_money = jQuery('#request_money').val();
            var request_expression = jQuery('#request_expression').val();
            var request_cat = jQuery('#request_cat').val();

            if((request_title.length > 0) && (request_money.length > 0) && (request_expression.length > 0) && (request_cat.length > 0)) {
                jQuery.ajax({
                    url: '',
                    method:'POST',
                    data: jQuery('#form_test').serialize(),
                    success: function() {
                        jQuery( ".x" ).prop( "disabled", true );
                        jQuery('.loader-request').css('display','none');
                        var x = document.getElementById("toast");
                        x.className = "show";
                        setTimeout(function(){ x.className = x.className.replace("show", ""); }, 5000);
                        setTimeout(function(){ location.reload(); }, 4000);
                    }
                }).error(function(){
                    jQuery( ".x" ).prop( "disabled", true );
                    jQuery('.loader-request').css('display','none');
                    var x = document.getElementById("toast-err");
                    x.className = "show";
                    setTimeout(function(){ x.className = x.className.replace("show", ""); }, 5000);
                    setTimeout(function(){ location.reload(); }, 4000);
                })
            }else {
                jQuery( ".y" ).prop( "disabled", false );
                var x = document.getElementById("toast-not");
                jQuery('.loader-request').css('display','none');
                x.className = "show";
                setTimeout(function(){ x.className = x.className.replace("show", ""); }, 5000);
            }
        };

    </script>

    <style>
        .btn-requste {
            background: linear-gradient(45deg, #267b81, #538e40);
            position: relative;
            color: #fff;
            border: none;
            padding: 10px;
            border-radius:3px;
            font-size:14px;
            letter-spacing: 1px;
            cursor: pointer;
            box-shadow: 0 10px 20px rgba(0, 0, 0, 0.1);
            transition: background 0.25s cubic-bezier(0.55, 0, 0.1, 1);
        }
        .btn-requste:focus {
            outline: none;
        }

        .modal-overlay {
            display: flex;
            align-items: center;
            justify-content: center;
            position: fixed;
            top: 0;
            left: 0;
            width: 100%;
            height: 100%;
            z-index: 5;
            background-color: rgba(0, 0, 0, 0.6);
            opacity: 0;
            visibility: hidden;
            -webkit-backface-visibility: hidden;
            backface-visibility: hidden;
            transition: opacity 0.6s cubic-bezier(0.55, 0, 0.1, 1), visibility 0.6s cubic-bezier(0.55, 0, 0.1, 1);
        }
        .modal-overlay.active {
            opacity: 1;
            visibility: visible;
        }


        .modal {
            display: flex;
            align-items: center;
            justify-content: center;
            position: relative;
            margin: 0 auto;
            background-color: #fff;
            width: 600px;
            max-width: 75rem;
            min-height: 20rem;
            padding: 1rem;
            border-radius: 3px;
            opacity: 0;
            overflow-y: auto;
            visibility: hidden;
            box-shadow: 0 2px 10px rgba(0, 0, 0, 0.1);
            -webkit-backface-visibility: hidden;
            backface-visibility: hidden;
            -webkit-transform: scale(1.2);
            transform: scale(1.2);
            transition: all 0.6s cubic-bezier(0.55, 0, 0.1, 1);
        }
        .modal .close-modal {
            position: absolute;
            cursor: pointer;
            top: 5px;
            right: 15px;
            opacity: 0;
            -webkit-backface-visibility: hidden;
            backface-visibility: hidden;
            transition: opacity 0.6s cubic-bezier(0.55, 0, 0.1, 1), -webkit-transform 0.6s cubic-bezier(0.55, 0, 0.1, 1);
            transition: opacity 0.6s cubic-bezier(0.55, 0, 0.1, 1), transform 0.6s cubic-bezier(0.55, 0, 0.1, 1);
            transition: opacity 0.6s cubic-bezier(0.55, 0, 0.1, 1), transform 0.6s cubic-bezier(0.55, 0, 0.1, 1), -webkit-transform 0.6s cubic-bezier(0.55, 0, 0.1, 1);
            transition-delay: 0.3s;
        }
        .modal .close-modal svg {
            width: 1.75em;
            height: 1.75em;
        }
        .modal .modal-content {
            opacity: 0;
            -webkit-backface-visibility: hidden;
            backface-visibility: hidden;
            transition: opacity 0.6s cubic-bezier(0.55, 0, 0.1, 1);
            transition-delay: 0.3s;
        }
        .modal.active {
            visibility: visible;
            opacity: 1;
            -webkit-transform: scale(1);
            transform: scale(1);
        }
        .modal.active .modal-content {
            opacity: 1;
        }
        .modal.active .close-modal {
            -webkit-transform: translateY(10px);
            transform: translateY(10px);
            opacity: 1;
        }


    </style>
<?php }else{
    wp_redirect(home_url());
}?>