<?php // Template Name: coach register ?>
<?php 
$user = wp_get_current_user();
$user_id = $user->ID;
$user_role = $user->roles[0];
$roles =get_user_meta($user_id,'roles',true);
$allowed_roles_high = array('administrator','editor');
if(is_user_logged_in() && (array_intersect($allowed_roles_high, $current_user->roles ))  || in_array('operational' , $roles) ){
?>
<?php get_header() ?>
<?php get_header('admin') ?>
<style>
    header , footer{
        display:none;
    }
</style>
<div class="colm6 colm12-tab colm margin-auto spacer-t50">
	<form action="" method="post" class="smart-validate" enctype="multipart/form-data">
		<div class="body-form relative">
			<div class="bg-chart4 body-form-top absolute flex-center">
				<div class="fa fa-user-plus vertical font-s30 color-white"></div>
			</div>
			<div class="absolute title-panel">
				<h3 class="font-w300 font-s18 ">ثبت نام منتور</h3>
			</div>
			 <div class="pad-30"> 
				<div class="frm-row  spacer-t30">
                    <div class="colm10 colm margin-auto pad-5">
						<label for="mobile" class="gui-label pad-5"> شماره همراه منتور:</label>
						<label class="relative">
							<span class="icon-gui flex-center"><i class="fa fa-mobile"></i></span>
							<input dir="ltr" class="gui-input sans-digit" id="mobile" name="mobile" data-rule-customphone="true" placeholder="09XXXXXXX" required>
						</label>
					</div>
				</div>
			</div>
            <div class="margin-auto align-center pad-b25">
                <button type="submit" name="passwrod_btn" class="btn-panel pad-10 color-white iransans">ثبت</button>
            </div>
		</div>	
	</form>
</div>
<?php get_footer() ?>
<?php get_footer('admin') ?>
<?php }else{
        wp_redirect(home_url());
} ?>