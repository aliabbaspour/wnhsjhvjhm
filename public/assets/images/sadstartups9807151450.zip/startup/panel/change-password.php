<?php //Template Name: chenge password ?>
<?php
$user = wp_get_current_user();
$user_id = $user->ID;
$user_role = $user->roles[0];
if(is_user_logged_in() ){

if(isset($_POST['passwrod_btn'])){
	if($_POST['password'] != $_POST['repeatPassword']){
		$message = 1;
	}elseif(!empty($_POST['password'])){
		wp_set_password($_POST['password'],$user_id); 
		ps_redirect_after_logout();
	}
}
	
?>
<?php get_header() ?>
<?php get_header('admin') ?>
<style>
	.hide-tab{
		display: none;
	}
</style>
<div class="colm6 colm12-tab colm margin-auto spacer-t50">
	<form action="" method="post" class="smart-validate" enctype="multipart/form-data">
		<div class="body-form relative">
			<div class="bg-chart4 body-form-top absolute flex-center">
				<div class="fa fa-lock vertical font-s30 color-white"></div>
			</div>
			<div class="absolute title-panel">
				<h3 class="font-w300 font-s18 ">تغیر رمزعبور</h3>
			</div>
			 <div class="pad-30"> 
				<div class="frm-row  spacer-t30">
					<div class="colm10 colm margin-auto pad-5">
						<label for="new-pass" class="gui-label pad-5"> رمز عبور جدید:</label>
						<label class="relative">
							<span class="icon-gui flex-center"><i class=" color-black fa fa-star-of-life"></i></span>
							<input dir="ltr" type="password" class="gui-input sans-digit" name="password" id="password"  value=""  required>
						</label>
					</div>
					<div class="colm10 colm margin-auto pad-5">
						<label for="repeat-pass" class="gui-label pad-5">تکرار رمز عبور :</label>
						<label class="relative">
							<span class="icon-gui flex-center"><i class=" color-black fa fa-star-of-life vertical"></i></span>
							<input dir="ltr" type="password" class="gui-input sans-digit" data-rule-equalTo="#password" name="repeatPassword" id="repeatPassword" value="">
						</label>
					</div>
				</div>
			</div>
            <div class="margin-auto align-center pad-b25">
                <button type="submit" name="passwrod_btn" class="btn-panel pad-10 color-white iransans">تغیر رمز عبور</button>
            </div>
		</div>	
	</form>
</div>
<style>
	header , footer{
		display: none;
	}
</style>
<?php get_footer('admin'); ?>
<?php get_footer(); ?>
<?php }else{
	wp_redirect(home_url());
}?>
<script>
	new WOW().init();
</script>