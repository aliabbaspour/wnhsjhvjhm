<?php //Template Name: List-coach ?>
<?php
$user = wp_get_current_user();
$user_id = $user->ID;
$user_role = $user->roles[0];
$allowed_all= array('editor', 'administrator','managers');
if(is_user_logged_in() && (array_intersect($allowed_all, $user->roles )) ){
$args=array(
    'number' => -1,
    'role__in' => array( 'coach' ),
	
);
$user_query_coach = new WP_User_Query($args);  
?>
<?php get_header() ?>
<?php get_header('admin') ?>
<style>
	.hide-tab{
		display: none;
	}
</style>
<div class="pad-t20">
	<!--<div class="frm-row pad-b30 flex-center-row">
		<div class="colm4 colm12-tab colm pull-right pad-15 pad-0 spacer-t25-mob spacer-b25-mob spacer-t30-tab spacer-b30-tab wow fadeInLeftBig" data-wow-duration="2s">
			<div class="body-form pad-15 relative">
				<a href="#" class="pad-b10 color6">
					<div class="bg-chart1 icon-cat-panel absolute  flex-center">
						<i class="fa fa-times vertical font-s30 color-white"></i>
					</div>
					<div class="align-right">
						<h4 class="font-w200 font-s15">مربیان بدون تیم</h4>
						<h4 class="font-w300 font-s20 title-panel">0</h4>
					</div>
				</a>
				<div class="border-t-chart font-w200 font-s12 pad-t10">
					<span class="font-w300">
						<i class="fa fa-chart-bar pad-l5 verticall"></i>
					</span>
					<span>
						آمار مربیان بدون تیم
					</span>  
				</div>
			</div>
		</div>--->
		<div class="colm4 colm12-tab colm margin-auto pad-15 pad-0 spacer-b25-mob spacer-b30-tab wow zoomIn" data-wow-duration="2s"> 
			<div class="body-form pad-15 relative">
				<a href="#" class="pad-b10 color6">
					<div class="bg-chart3 icon-cat-panel absolute  flex-center">
						<i class="fa fa-chalkboard-teacher vertical font-s30 color-white"></i> 
					</div>
					<div class="align-right">
						<h4 class="font-w200 font-s15">تمام مربیان</h4>
						<h4 class="font-w300 font-s20 title-panel"><?php echo count($user_query_coach->get_results()); ?></h4>
					</div>
				</a>
				<div class="border-t-chart font-w200 font-s12 pad-t10">
					<span class="font-w300">
						<i class="fa fa-chart-bar pad-l5 verticall"></i>
					</span>
					<span>
						آمار تمام مربیان
					</span>
				</div>
			</div>
		</div>
		<!---<div class="colm4 colm12-tab colm pull-right pad-15 pad-0 spacer-b25-mob spacer-b30-tab wow fadeInRightBig" data-wow-duration="2s">
			<div class="body-form pad-15 relative">
				<a href="#" class="pad-b10 color6">
					<div class="bg-chart2 icon-cat-panel absolute flex-center">
						<i class=" fa fa-check vertical font-s30 color-white"></i>
					</div>
					<div class="align-right">
						<h4 class="font-w200 font-s15">مربیان با تیم</h4>
						<h4 class="font-w300 font-s20 title-panel">0</h4>
					</div>
				</a>
				<div class="border-t-chart font-w200 font-s12 pad-t10">
					<span class="font-w300">
						<i class="fa fa-chart-bar pad-l5 vertical"></i>
					</span>
					<span>
						آمار مربیان با تیم
					</span>
				</div>
			</div>
		</div>--->
		<div class="clearfix"></div>
	</div>
	<div class="body-form relative  wow fadeInUp" data-wow-duration="2s">
		<div class="bg-chart4 body-form-top absolute flex-center">
			<i class="fa fa-chalkboard-teacher vertical font-s30 color-white"></i>
		</div>
		<div class="absolute title-panel">
			<h3 class="font-w300 font-s18">تمام مربیان</h3>
		</div>
		<div class="frm-row pad-t25-mob pad-t30-tab">
			<div class="colm4 colm pull-left pull-none relative pad-20">
			     <input class="input-panel align-right" placeholder="جستجو کنید..." type="search" name="" value=""  >
			     <span class="bar"></span>
		    </div>
		</div>
		<div class="frm-row pad-t40">
			<div class="overflow-scroll pad-b40">
				<?php
					$allowedRoles = array('editor', 'administrator','managers');
					$number=-1;
					$list = new list_users();
					$list->coach($allowedRoles , $number);
				?>
			</div>
		</div>
	</div>
</div>
<style>
	header , footer{
		display: none;
	}
</style>
<?php get_footer('admin'); ?>
<?php get_footer(); ?>
<?php }else{
	wp_redirect(home_url());
}?>
<script>
	new WOW().init();
</script>