<?php // Template Name: Create User ?>
<?php  
$user = wp_get_current_user();
$user_id = $user->ID;
$user_role = $user->roles[0];
$roles =get_user_meta($user_id,'roles',true);
$allowed_roles_high = array('administrator','editor');
if(is_user_logged_in() && (array_intersect($allowed_roles_high, $user->roles ))|| in_array('operational', $roles) ){
	if(isset($_POST['submit'])){
		$username = $_POST['user_name'];
		$exists_user_name = user_name_exists( $username );
		$mobile = $_POST['mobile'];
		$exists_mobile = mobile_exists( $mobile );
		if($exists_mobile != -1){
			wp_redirect(home_url('/create-user/?message=error'));
		}elseif($exists_user_name != -1){
			wp_redirect(home_url('/create-user/?message=error2'));
		}else{
			$user_args = array(
				'first_name'=> $_POST['first_name'],
				'last_name' => $_POST['last_name'],
				'user_pass' => $_POST['password'],
				'user_email' => $_POST['email'],
				'user_login'=>$_POST['user_name'],
				'role'       =>'managers',
			);
			$user_id = wp_insert_user($user_args);
			update_user_meta($user_id,'email', $_POST['email']);
			update_user_meta($user_id,'mobile', $_POST['mobile']);
			update_user_meta($user_id,'user_name', $_POST['user_name']);
            update_user_meta($user_id,'coeff_user', $_POST['coeff_user']);
            update_user_meta($user_id,'roles', $_POST['roles']);
            update_user_meta($user_id,'cats', $_POST['cats']);
            update_user_meta($user_id,'referee_expertise', $_POST['referee_expertise']);
			update_user_meta($user_id,'mentor_expertise', $_POST['mentor_expertise']);
			wp_redirect(home_url('/create-user/?message=ok'));
		}

	}
?>
<?php get_header() ?>
<?php get_header('admin') ?>
<style>
	.hide-tab{
		display: none;
	}
</style>
<?php if($_GET['message']=='ok') {?>
	<div class="colm8 colm margin-auto alert-sucsess bg-white flex-center color-black font-w400 font-s15 border-ra5 a pad-20 wow fadeInDown"  data-wow-duration="1.5s">
		<h2 class="flex-center-row"><i class="fa fa-check pad-l5"></i>کاربر با موفیقت ایجاد شد</h2>
	</div>
<?php }?>
<?php if($_GET['message']=='error') {?>
	<div class="colm8 colm margin-auto alert-sucsess bg-white flex-center color-black font-w400 font-s15 border-ra5 a pad-20 wow fadeInDown"  data-wow-duration="1.5s">
		<h2 class="flex-center-row"><i class="fa fa-times pad-l5"></i>شماره تلفن در سیستم ثبت شده است</h2>
	</div>
<?php }?>
<?php if($_GET['message']=='error2') {?>
	<div class="colm8 colm margin-auto alert-sucsess bg-white flex-center color-black font-w400 font-s15 border-ra5 a pad-20 wow fadeInDown"  data-wow-duration="1.5s">
		<h2 class="flex-center-row"><i class="fa fa-times pad-l5"></i>نام کاربری در سیستم ثبت شده است</h2>
	</div>
<?php }?>
<div class="colm8 colm12-tab colm margin-auto spacer-t30 wow fadeInDown"  data-wow-duration="1.5s">
	<form action="" method="post" class="smart-validate" enctype="multipart/form-data">
		<div class="body-form relative">
			<div class="bg-chart4 body-form-top absolute flex-center">
				<div class="fa fa-user-plus vertical font-s30 color-white"></div>
			</div>
			<div class="absolute title-panel">
				<h3 class="font-w300 font-s18 pad-r25">ایجاد کاربر</h3>
			</div>
		 <div class="pad-30"> 
			<div class="frm-row spacer-t30">
				<div class="colm6 colm pull-right pad-5">
					<label for="first-name" class="gui-label pad-5">نام :</label>
					<label class="relative">
						<span class="icon-gui flex-center"><i class=" fa fa-user vertical"></i></span>
						<input type="text" class="gui-input sans-digit" id="first-name" name="first_name" placeholder="مثال : محمد" data-rule-lettersonly="true" required>
					</label>
				</div>
				<div class="colm6 colm pull-right pad-5"> 
					<label for="last-name" class="gui-label pad-5">نام خانوادگی :</label>
					<label class="relative">
						<span class="icon-gui flex-center"><i class=" fa fa-user vertical"></i></span>
						<input type="text" class="gui-input sans-digit" name="last_name" placeholder="مثال : محمدی" data-rule-lettersonly="true" id="last-name" required>
					</label>
				</div>
				<div class="clearfix"></div>
			</div>
			<div class="frm-row">
				<div class="colm6 colm pull-right pad-5">
					<label for="user-name" class="gui-label pad-5">نام کاربری :</label>
					<label class="relative">
						<span class="icon-gui flex-center"><i class=" fa fa-laptop-code vertical"></i></span>
						<input type="text" class="gui-input sans-digit" id="user-name" name="user_name" placeholder="مثال : U-8468655" data-rule-lettersonlyen="true" required>
					</label>
				</div>
				<div class="colm6 colm pull-right pad-5"> 
					<label for="email" class="gui-label pad-5">ایمیل :</label>
					<label class="relative">
						<span class="icon-gui flex-center"><i class=" fa fa-at vertical"></i></span>
						<input type="email" class="gui-input sans-digit" name="email" placeholder="مثال : email@email.com"  id="email" required>
					</label>
				</div>
				<div class="clearfix"></div>
			</div>
			<div class="frm-row">
					<div class="colm6 colm pull-right pad-5">
						<label for="mobile" class="gui-label pad-5"> شماره همراه:</label>
						<label class="relative">
							<span class="icon-gui flex-center"><i class="fa fa-mobile"></i></span>
							<input dir="ltr" class="gui-input sans-digit" id="mobile" name="mobile" data-rule-customphone="true" placeholder="09XXXXXXX" required>
						</label>
					</div>
					<div class="colm6 colm pull-right pad-5">
						<label for="password" class="gui-label pad-5">رمز عبور :</label>
						<label class="relative">
							<span class="icon-gui flex-center"><i class=" fa fa-key vertical"></i></span>
							<input type="password" class="gui-input sans-digit" id="password" name="password" required>
						</label>
					</div>
                <div class="colm6 colm pull-right pad-5">
                    <label for="first-name" class="gui-label pad-5">ضریب کاربر :</label>
                    <label class="relative">
                        <span class="icon-gui flex-center"><i class=" fa fa-prescription vertical"></i></span>
                        <input type="number" class="gui-input sans-digit" id="coeff-user" name="coeff_user" required>
                    </label>
                </div>
					<div class="clearfix"></div>
				</div>
				<div class="frm-row">
					<h2 class="font-w300 font-s16 spacer-t20 spacer-b10 pad-10 border-b-panel">انتخاب نقش ها</h2>
					
					<?php
						$naghsh = array(
							array(
								'key' 	=> "financial",
								'lable'	=> "مالی"
							),
							array(
								'key' 	=> "leader",
								'lable'	=> "راهبر ارشد"
							),
							array(
								'key' 	=> "investor",
								'lable'	=> "سرمایه گذار"
							),
							array(
								'key' 	=> "coach",
								'lable'	=> "مربی"
							),
							array(
								'key' 	=> "referee",
								'lable'	=> "داور"
							),
							array( 
								'key' 	=> "operational",
								'lable'	=> "مدیر عملیاتی"
							),
						);
						
						for($i=0 ;$i < count($naghsh);$i++):
					?>
					<div class="colm3 colm pull-right pad-5 spacer-b5">
						<input type="checkbox" id="<?php echo $naghsh[$i]['key']; ?>"  name="roles[]" value="<?php echo $naghsh[$i]['key']; ?>"<?php if(in_array($naghsh[$i]['key'],$roles))echo 'checked'; ?>>
			  			<label for="<?php echo $naghsh[$i]['key']; ?>"><?php echo $naghsh[$i]['lable']; ?></label>
					</div>
					<?php endfor?>
					<div class="clearfix"></div>
				</div>
             <div class="frm-row">
                 <h2 class="font-w300 font-s16 spacer-t20 spacer-b10 pad-10 border-b-panel">انتخاب دسته ها</h2>

                 <?php
                 $cat = array(
                     array(
                         'key' 	=> "medicine",
                         'lable'	=> "پزشکی"
                     ),
                     array(
                         'key' 	=> "culture",
                         'lable'	=> "فرهنگی"
                     ),
                     array(
                         'key' 	=> "AI",
                         'lable'	=> "هوش مصنوعی"
                     ),
                     array(
                         'key' 	=> "sport",
                         'lable'	=> "ورزشی"
                     ),

                 );

                 for($i=0 ;$i < count($cat);$i++):
                     ?>
                     <div class="colm3 colm pull-right pad-5 spacer-b5">
                         <input type="checkbox" id="<?php echo $cat[$i]['key']; ?>"  name="cats[]" value="<?php echo $cat[$i]['key']; ?>"<?php if(in_array($cat[$i]['key'],$cat))echo 'checked'; ?>>
                         <label for="<?php echo $cat[$i]['key']; ?>"><?php echo $cat[$i]['lable']; ?></label>
                     </div>
                 <?php endfor?>
                 <div class="clearfix"></div>
             </div>
	            <div class="margin-auto align-center pad-t25">
	                <button type="submit" name="submit" class="btn-panel pad-10 color-white iransans">بروزرسانی</button>
	            </div>
            </div>
		</div>
	</form>
</div>
<style>
input[type=checkbox] + label {
  cursor: pointer;
  font-size: 13px;
} 

input[type=checkbox] {
  display: none;
}

input[type=checkbox] + label:before {
	content: "\2714";
	border: 0.1em solid #bbb;
	display:inline-block;
	border-radius: 0.2em;
	width: 19px;
	height: 19px;
	margin-left:5px;
	text-align:center;
	vertical-align:middle;
	color: transparent;
	transition: 0.5s;
}

input[type=checkbox] + label:active:before {
  transform: scale(0);
}

input[type=checkbox]:checked + label:before {
  background-color: MediumSeaGreen;
  border-color: MediumSeaGreen;
  color: #fff;
}
	header , footer{
		display: none;
	}
</style>
<?php get_footer('admin'); ?>
<?php get_footer(); ?>
<?php }else{wp_redirect(home_url('/404'));} ?>
<script>
	new WOW().init();
</script>
<script>
jQuery(document).ready(function($){
	window.setTimeout(function() {
	    $(".alert-sucsess").fadeTo(500, 0).slideUp(500, function(){
	        $(this).remove(); 
	    });
	}, 4000);
	var uri = window.location.toString();
	if (uri.indexOf("?") > 0) {
	    var clean_uri = uri.substring(0, uri.indexOf("?"));
	    window.history.replaceState({}, document.title, clean_uri);
	}
});
</script>

 