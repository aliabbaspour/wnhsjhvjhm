<?php //Template Name: List User ?>
<?php
$user = wp_get_current_user();
$user_id = $user->ID;
$user_role = $user->roles[0];
$allowed_all= array('editor', 'administrator','managers');
if(is_user_logged_in() && (array_intersect($allowed_all, $user->roles )) ){
$args = array(
	'number' => -1,
	'role__not_in' => array('editor', 'administrator'),
	'orderby' => 'ID',
	'order' => 'DESC',
);
$user_query = new WP_User_Query($args); 
?>
<?php get_header() ?>
<?php get_header('admin') ?>
<style>
	.hide-tab{
		display: none;
	}  
</style>
<div class="pad-t20">
	<div class="frm-row pad-b30 flex-center-row">
		<div class="colm4 colm12-tab colm pull-right pad-15 pad-0 spacer-b25-mob spacer-b30-tab spacer-t25-mob spacer-t30-tab wow wow zoomIn" data-wow-duration="2s">
			<div class="body-form pad-15 relative">
				<a href="#" class="pad-b10 color6">
					<div class="bg-chart3 icon-cat-panel absolute  flex-center">
						<i class="fa fa-users vertical font-s30 color-white"></i>
					</div>
					<div class="align-right">
						<h4 class="font-w200 font-s15"> کاربران سامانه</h4>
						<h4 class="font-w300 font-s20 title-panel"><?php echo count($user_query->get_results()) ?></h4>
					</div>
				</a>
				<div class="border-t-chart font-w200 font-s12 pad-t10">
					<span class="font-w300">
						<i class="fa fa-chart-bar pad-l5 verticall"></i>
					</span>
					<span>
						آمار همه کاربران
					</span>
				</div>
			</div>
		</div>
		<div class="clearfix"></div>
	</div>
	<div class="body-form relative wow fadeInUp" data-wow-duration="2s">
		<div class="bg-chart2 body-form-top absolute flex-center">
			<i class="fa fa-users vertical font-s30 color-white"></i>
		</div>
		<div class="absolute title-panel">
			<h3 class="font-w300 font-s18">همه کاربران</h3>
		</div>
		<div class="frm-row pad-t25-mob pad-t30-tab">
			<div class="colm4 colm pull-left pull-none relative pad-20">      
			     <input class="input-panel align-right" placeholder="جستجو کنید..." type="search" name="" value=""  >
			     <span class="bar"></span>
		    </div>
		</div>
		<div class="frm-row pad-t40">
			<div class="overflow-scroll pad-b40">
				<table class="table color6 retable">
					<thead>
						<tr>
							<th>ردیف</th>
							<th>نام و نام خانوادگی</th>
							<th>ایمیل</th>
							<th>موبایل</th>
							<th class="center">وضعیت</th>
						 </tr>
					</thead>
					<tbody>
						<?php 
						 $args=array(
							'number' => -1,
							'role__not_in' => array('editor', 'administrator'),
		                    'orderby' => 'ID',
		                    'order' => 'DESC',
	                    );
						$user_query = new WP_User_Query($args); 
						$i=1;
						if ( ! empty( $user_query->get_results() ) ) {
							foreach ( $user_query->get_results() as $user ) {
							$user_id 	= $user->ID;
							$user_login	= $user->user_login;
							$role 		= $user->roles[0];
							$firstname  = get_user_meta($user_id,'first_name',true);
	    					$lastname   = get_user_meta($user_id,'last_name',true);
	    					$mobile   = get_user_meta($user_id,'mobile',true);
							$status = get_user_meta($user_id,'status',true);
						?>
						 <tr>
							<td class="iransansdigit"><?php echo $i++; ?></td>
							<td><?php if($firstname && $last_name){ echo $firstname.' '.$last_name;}else{echo $user_login;} ?></td>
							<td><?php if($user->user_email){echo $user->user_email;}else{echo 'email does not exist';} ?></td>
							<td><?php if($mobile){echo $mobile;}else{echo 'no phone number';}?></td>
							<td class="center">
								<a class="color-silver" title="نمایش" href="<?php echo home_url("/information/$user_id") ?>" 
									<span>
										<i class="align-center font-s20 fa fa-address-card"></i>
									</span>								
								</a>
							</td>
				  		</tr>
				  		<?php		
							}wp_reset_query();
						}
						?>
					</tbody>
				</table>
			</div>
		</div>
	</div>
</div>
<style>
	header , footer{
		display: none;
	}
</style>
<?php get_footer('admin'); ?>
<?php get_footer(); ?>
<?php }else{
	wp_redirect(home_url());
}?>
<script>
	new WOW().init();
</script>