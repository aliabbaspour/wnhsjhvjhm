<?php //Template Name: Information  ?>
<?php
$current_user = wp_get_current_user();
$current_user_id = $current_user->ID;
$current_user_role = $current_user->roles[0];
$allowed_referee = array('operational','coach','mentor','investor');
$allowed_all = array('editor', 'administrator');
$allowed_tab = array('coach', 'operational');
$allowed_roles = array('editor', 'administrator','managers');
$roles =get_user_meta($current_user_id,'roles',true); 
if(is_user_logged_in() && (array_intersect($allowed_roles, $current_user->roles )) ){
    $user_id  = get_query_var( 'id_m');
    $user = get_user_by( 'id', $user_id );
    
    if(isset($_POST['status'])){
        update_user_meta($user_id,'admin_comment',$_POST['admin_comment']);
        if($_POST['status'] == 'accepted'){
            update_user_meta($user_id,'status','accepted');
            update_user_meta($user_id,'status_process','companion');

        }elseif($_POST['status'] == 'failed'){
            update_user_meta($user_id,'status','failed');
        }
        wp_redirect(home_url("/information/$user_id"));
    }

    if(isset($_POST['status_modir'])){
        update_user_meta($user_id,'status_process','accept_modir');
        update_user_meta($user_id,'modir_comment',$_POST['modir_comment']);
        if($_POST['status_modir'] == 'accepted_modir'){

            update_user_meta($user_id,'status_modir','accepted_modir');


        }elseif($_POST['status_modir'] == 'failed_modir'){

            update_user_meta($user_id,'status_modir','failed_modir');

        }
        wp_redirect(home_url("/information/$user_id"));
    }

    $datar = array(
        'query'=>array(
            array(
                'key'=>'author_id',
                'value'=>$current_user_id,
                'compare'=>'='
            ),
            array(
                'key'=>'user_id',
                'value'=>$user_id,
                'compare'=>'='
            )
        )
    );
    $data_referee = query_data('referee',$datar);
// داوری
    if(isset($_POST['btn_problem_store'])){
        $date = current_time( 'mysql' );
        if(!empty($data_referee[0]->id)){
            $query = array(
                'ID'=>$data_referee[0]->id
            );
            $data = array(
                'score_full'=>$_POST['score_full'],
                'score_coordination'=>$_POST['score_coordination'],
                'score_ability'=>$_POST['score_ability'],
                'score_market'=>$_POST['score_market'],
                'score_growth'=>$_POST['score_growth'],
                'score_competition'=>$_POST['score_competition'],
                'score_targetmarket'=>$_POST['score_targetmarket'],
                'score_suggestedvalue' =>$_POST['score_suggestedvalue'],
                'score_mvp'=>$_POST['score_mvp'],
                'score_transparency'=>$_POST['score_transparency'],
                'score_advantage'=>$_POST['score_advantage'],
                'score_strategy'=>$_POST['score_strategy'],
                'score_precise'=>$_POST['score_precise'],
                'score_comment'=>$_POST['score_comment'],
                'scorestatus'=>"false",
                'status'=>$data_referee[0]->status+1
            );
            update_datas('referee',$data,$query);
        }else{
            $data =array(
                'user_id'=>$user_id,
                'author_id'=>$current_user_id,
                'score_full'=>$_POST['score_full'],
                'score_coordination'=>$_POST['score_coordination'],
                'score_ability'=>$_POST['score_ability'],
                'score_market'=>$_POST['score_market'],
                'score_growth'=>$_POST['score_growth'],
                'score_competition'=>$_POST['score_competition'],
                'score_targetmarket'=>$_POST['score_targetmarket'],
                'score_suggestedvalue' =>$_POST['score_suggestedvalue'],
                'score_mvp'=>$_POST['score_mvp'],
                'score_transparency'=>$_POST['score_transparency'],
                'score_advantage'=>$_POST['score_advantage'],
                'score_strategy'=>$_POST['score_strategy'],
                'score_precise'=>$_POST['score_precise'],
                'score_comment'=>$_POST['score_comment'],
                'scorestatus'=>"false",
                'date'=>$date,
                'status'=>1
            );
            $score_referee = insert_data('referee', $data);
        }






        update_user_meta($user_id,'status_davar','davari');
        update_user_meta($user_id,'suggested_referee1',$_POST['suggested_referee1']);
        update_user_meta($user_id,'suggested_referee2',$_POST['suggested_referee2']);
        update_user_meta($user_id,'suggested_referee3',$_POST['suggested_referee3']);
        update_user_meta($user_id,'suggested_referee4',$_POST['suggested_referee4']);


        wp_redirect(home_url("/information/$user_id"));
    }
    
    if(isset($_POST['score_accept_status'])){

        $query = array(
            'ID'=>$data_referee[0]->id
        );
        $data = array(
            'scorestatus'=>"accepted",
        );
        update_datas('referee',$data,$query);

        wp_redirect(home_url("/information/$user_id"));
    }

    if(isset($_POST['score_feiled_status'])){

        $query = array(
            'ID'=>$data_referee[0]->id
        );
        $data = array(
            'scorestatus'=>"failed",
        );
        update_datas('referee',$data,$query);

        wp_redirect(home_url("/information/$user_id"));
    }


    $first 				= $user->first_name.' '.$user->last_name;
    $firstname 			= $user->first_name;
    $lastname 			= $user->last_name;
    $email 				= $user->user_email;
    $mobile   			= get_user_meta($user_id,'mobile',true);
    $startup_name 		= get_user_meta($user_id,'startup_name',true);
    $start_date 		= get_user_meta($user_id,'start_date',true);
    $introduction 		= get_user_meta($user_id,'introduction',true);
    $better 	  		= get_user_meta($user_id,'better',true);
    $website 			= get_user_meta($user_id,'website',true);
    $investment 		= get_user_meta($user_id,'investment',true);
    $dabir_ok 			= get_user_meta($user_id,'dabir_ok',true);
    $admin_comment 		= get_user_meta($user_id,'admin_comment',true);
    $prototype 			= get_user_meta($user_id,'prototype',true);
    $linkedin 			=  get_user_meta($user_id,'linkedin',true) ;
    $better 	  		= get_user_meta($user_id,'better',true);
    $defect_team  		= get_user_meta($user_id,'defect_team',true);
    $problem			= get_user_meta($user_id,'problem',true);
    $mysolution 		= get_user_meta($user_id,'mysolution',true);
    $solution 			= get_user_meta($user_id,'solution',true);
    $market_size    	= get_user_meta($user_id,'market_size',true);
    $defect 			= get_user_meta($user_id,'defect',true);
    $expertise	  		= get_user_meta($user_id,'expertise',true);
    $educationl	  	    = get_user_meta($user_id,'educationl',true);
    $stock	            = get_user_meta($user_id,'stock',true);
    $side	  	  		= get_user_meta($user_id,'side',true);
    $birthday			= get_user_meta($user_id,'birthday',true);
    $average	  		= get_user_meta($user_id,'average',true);
    $defect	  			= get_user_meta($user_id,'defect',true);
    $problem_store	  	= get_user_meta($user_id,'problem_store',true);
    $breadth_store	  	= get_user_meta($user_id,'breadth_store',true);
    $modir_comment	  	= get_user_meta($user_id,'modir_comment',true);
    $status			  	= get_user_meta($user_id,'status',true);
    $status_referee		= get_user_meta($user_id,'status_referee',true);
    $status_process		= get_user_meta($user_id,'status_process',true);
    $status_modir		= get_user_meta($user_id,'status_modir',true);

    $referee1= get_user_meta($user_id,'referee1',true);
    $referee2= get_user_meta($user_id,'referee2',true);
    $referee3= get_user_meta($user_id,'referee3',true);
    $referee4= get_user_meta($user_id,'referee4',true);

    $select_refree	  = get_user_meta($user_id,'select_refree',true);
    $scores			  = get_user_meta($user_id,'scores',true);
    $suggested_referee1= get_user_meta($user_id,'suggested_referee1',true);
    $suggested_referee2= get_user_meta($user_id,'suggested_referee2',true);
    $suggested_referee3= get_user_meta($user_id,'suggested_referee3',true);
    $suggested_referee4= get_user_meta($user_id,'suggested_referee4',true);




    $video =  get_user_meta($user_id,'video',true);
    $pdf = get_user_meta($user_id,'pdf',true);

    $class = "این فیلد خالی می باشد";

    $score_full =$data_referee[0]->score_full;
    $score_coordination = $data_referee[0]->score_coordination;
    $score_ability = $data_referee[0]->score_ability;
    $score_market = $data_referee[0]->score_market;
    $score_growth = $data_referee[0]->score_growth;
    $score_competition = $data_referee[0]->score_competition;
    $score_targetmarket = $data_referee[0]->score_targetmarket;
    $score_suggestedvalue = $data_referee[0]->score_suggestedvalue;
    $score_mvp = $data_referee[0]->score_mvp;
    $score_transparency = $data_referee[0]->score_transparency;
    $score_advantage = $data_referee[0]->score_advantage;
    $score_strategy = $data_referee[0]->score_strategy;
    $score_precise = $data_referee[0]->score_precise;
    $score_comment = $data_referee[0]->score_comment;
    $score_status = $data_referee[0]->score_status;

    $datarr = array(
        'query'=>array(
            array(
                'key'=>'user_id',
                'value'=>$user_id,
                'compare'=>'='
            )
        )
    );
    $data_referee = query_data('referee',$datarr);
    $query_a = array(
        'user_id' => $user_id,
    );
    $query_aa = query_count('referee',$query_a);
    $tab1="tab1";
    $tabfin="tabfin";
    $tabfin5="tabfin5";
    switch($educationl) {
        case '1': $educationl = 'زیر دیپلم'; break;
        case '2': $educationl = 'دیپلم'; break;
        case '3': $educationl = 'فوق دیپلم'; break;
        case '4': $educationl = 'لیسانس'; break;
        case '5': $educationl = 'فوق لیسانس'; break;
        case '6': $educationl = 'دکتری'; break;
        case '7': $educationl = 'فوق دکتری'; break;
    }
    print_r($status);
    ?>
    <?php get_header() ?>
    <?php get_header('admin') ?>
    <style>
        footer,header{
            display: none
        }
        .hide-tab{
            display: none;
        }
        .pad-card{
            padding:5px 20px;
        }
        .accept-card{
            border-radius: 0px 3px 5px 0;
        }
        .times-card{
            border-radius: 3px 0 0 5px;
            background: #f30000;
        }
    </style>
    <div class="colm12 colm  margin-auto">
        <div class="spacer-t25">
            <div class="colm9 colm12-tab colm pull-right pad-10 pad-0">
                <?php if(  array_intersect($allowed_tab, $roles ) || array_intersect($allowed_all, $current_user->roles )): ?>
                    <div class="body-form  wow fadeInUpBig spacer-b30" data-wow-duration="1s">
                        <div class="flex">
                            <div class="colm2 font-s10 colm pull-right taga">
                                <a href="#">
                                    <div class="<?php if($status_process=="companion" ){echo $tab1; }else{echo $tabfin; } ?> flex-center sg-tab" data-id="4">اختصاص راهبر</div>
                                </a>
                            </div>
                            <div class="colm2 font-s10 colm pull-right taga ">
                                <a href="#">
                                    <div class="<?php if($status_process=="chose_referee" ){echo $tab1; }else{echo $tabfin; } ?> flex-center sg-tab " data-id="1">اختصاص داور</div>
                                </a>
                            </div>
                            <div class="active-tab  colm2 font-s10 colm pull-right taga">
                                <a href="#">
                                    <div class="<?php if($status_process=="accept_modir" ){echo $tab1; }else{echo $tabfin; } ?> flex-center sg-tab" data-id="2">داوری غیر حضوری</div>
                                </a>
                            </div>
                            <div class="colm2 font-s10 colm pull-right taga">
                                <a href="#">
                                    <div class="<?php if($status_process=="dfvdf" ){echo $tab1; }else{echo $tabfin; } ?> flex-center sg-tab" data-id="3">داوری حضوری</div>
                                </a>
                            </div>
                            <div class="colm2 font-s10 colm pull-right taga ">
                                <a href="#">
                                    <div class="<?php if($status_process=="dfvd" ){echo $tab1; }else{echo $tabfin; } ?> flex-center sg-tab" data-id="5">پیش قرارداد</div>
                                </a>
                            </div>
                            <div class="colm2 font-s10 colm pull-right taga">
                                <a href="#">
                                    <div class="<?php if($status_process=="dfv" ){echo $tab1; }else{echo $tabfin5; } ?> flex-center  sg-tab" data-id="5">وضعیت نهایی</div>
                                </a>
                            </div>
                            <div class="clearfix"></div>
                        </div>
                        
                        <div class="cnt4 sg-content pad-b25 align-center <?php if($status_process=="companion" ){echo show; $disable=''; }else{echo hide; } ?>" id="4">
                            <?php get_template_part('level/step4') ?>
                        </div>
                        <div class="cnt1 sg-content align-center pad-b25 <?php if($status_process=="chose_referee" ){echo show; $disable='';}else{echo hide; } ?>" id="1">
                            <?php get_template_part('level/step1') ?>
                        </div>
                        <div class="cnt2 sg-content align-center <?php if($status_process=="accept_modir" ){echo show; $disable='';}else{echo hide; } ?>" id="2">
                            <?php get_template_part('level/step2') ?>
                        </div>
                        <div class="cnt3 sg-content align-center <?php if($status_process=="fffvdf" ){echo show; $disable='';}else{echo hide; } ?>" id="3">
                            <?php get_template_part('level/step3') ?>
                        </div>
                        <div class="cnt5 sg-content align-center <?php if($status_process=="weew" ){echo show; $disable='';}else{echo hide; } ?>" id="5">
                            <?php get_template_part('level/step5') ?>
                        </div>
                        <div class="cnt6 sg-content align-center <?php if($status_process=="rtgr" ){echo show; $disable='';}else{echo hide; } ?>" id="6">
                            <?php get_template_part('level/step6') ?>
                        </div>
                    </div>
                <?php endif ?>

               
                    <?php 

                    if($referee1 == $current_user_id || $referee2 == $current_user_id || $referee3 == $current_user_id || $referee4 == $current_user_id){
                        $referee = true;
                    }

                    if((in_array('referee' , $roles) && $referee == true)){?>
                    <div class="body-form frm-row relative spacer-b30 pad-t40 pad-5-mob wow fadeInUpBig" data-wow-duration="1s">
                        <div class="bg-chart2 body-form-top absolute flex-center">
                            <i class="fa fa-balance-scale vertical font-s30 color-white"></i>
                        </div>
                        <div class="absolute title-panel">
                            <h3 class="font-w300 font-s18 ">داوری</h3>
                        </div>
                        <div class="pull-left frm-row pad-l30">
                            <a class="btn-team iransans colm12 colm" href="#team">اطلاعات تیم</a>
                        </div>
                        <form method="post">
                            <div class="pad-card">
                                <h4 class="font-w300 font-s16 spacer-t30">تیم</h4>
                                <div class="colm12 colm frm-row slidecontainer  pad-5 pad-t20">
                                    <div class="colm4 colm6-tab pull-right-tab colm pad-10 ">
                                        <label for="breadth_store" class="gui-label pad-5">کامل بودن تیم</label>
                                        <div class="rate-part">
                                            <input type="range" min="1" max="5" value="<?php if($score_full){echo $score_full;}else{echo 0;}?>" class="renge" name="score_full">
                                            <span class="font-s11">امتیاز:</span>
                                            <p class="font-s11 inlin-block"></p>
                                        </div>
                                    </div>
                                    <div class="colm4 colm6-tab pull-right-tab colm pad-10">
                                        <label for="breadth_store" class="gui-label pad-5">هماهنگی و انسجام اعضا </label>
                                        <div class="rate-part">
                                            <input type="range" min="1" max="5" value="<?php if($score_coordination){echo $score_coordination;}else{echo 0;} ?>" class="renge" name="score_coordination">
                                            <span class="font-s11">امتیاز:</span>
                                            <p class="font-s11 inlin-block"></p>
                                        </div>
                                    </div>
                                    <div class="colm4 colm6-tab pull-right-tab colm pad-10">
                                        <label for="breadth_store" class="gui-label pad-5">توانمندی تیم برای اجرای این کسب‌وکار</label>
                                        <div class="rate-part">
                                            <input type="range" min="1" max="5" value="<?php  if($score_ability){echo $score_ability;}else{echo 0;} ?>" class="renge" name="score_ability">
                                            <span class="font-s11">امتیاز:</span>
                                            <p class="font-s11 inlin-block"></p>
                                        </div>
                                    </div>
                                </div>
                                <hr>
                            </div>
                            <div class="pad-card">
                                <h4 class="font-w300 font-s16 spacer-t10">بازار</h4>
                                <div class="colm12 colm frm-row pad-5 pad-t20 slidecontainer">
                                    <div class="colm4 colm6-tab pull-right-tab colm pad-10">
                                        <label for="breadth_store" class="gui-label pad-5">اندازه بازار</label>
                                        <div class="rate-part">
                                            <input type="range" min="1" max="5" value="<?php  if($score_market){echo $score_market;}else{echo 0;}?>" class="renge" name="score_market">
                                            <span class="font-s11">امتیاز:</span>
                                            <p class="font-s11 inlin-block"></p>
                                        </div>
                                    </div>
                                    <div class="colm4 colm6-tab pull-right-tab colm pad-10">
                                        <label for="breadth_store" class="gui-label pad-5">پتانسیل رشد بازار</label>
                                        <div class="rate-part">
                                            <input type="range" min="1" max="5" value="<?php  if($score_growth){echo $score_growth;}else{echo 0;} ?>" class="renge" name="score_growth">
                                            <span class="font-s11">امتیاز:</span>
                                            <p class="font-s11 inlin-block"></p>
                                        </div>
                                    </div>
                                    <div class="colm4 colm6-tab pull-right-tab colm pad-10">
                                        <label for="breadth_store" class="gui-label pad-5">شدت فضای رقابتی بازار هدف</label>
                                        <div class="rate-part">
                                            <input type="range" min="1" max="5" value="<?php if($score_competition){echo $score_competition;}else{echo 0;}?>" class="renge" name="score_competition">
                                            <span class="font-s11">امتیاز:</span>
                                            <p class="font-s11 inlin-block"></p>
                                        </div>
                                    </div>
                                </div>
                                <hr>    
                            </div>
                            <div class="pad-card">
                                <h4 class="font-w300 font-s16 spacer-t10">مدل کسب و کار </h4>
                                <div class="colm12 colm frm-row pad-5 pad-t20 slidecontainer">
                                    <div class="colm4 colm6-tab pull-right-tab colm pad-10">
                                        <label for="breadth_store" class="gui-label pad-5">بخش‌بندی مشخص و شفاف مشتریان</label>
                                        <div class="rate-part">
                                            <input type="range" min="1" max="5" value="<?php  if($score_targetmarket){echo $score_targetmarket;}else{echo 0;} ?>" class="renge" name="score_targetmarket">
                                            <span class="font-s11">امتیاز:</span>
                                            <p class="font-s11 inlin-block"></p>
                                        </div>
                                    </div>
                                    <div class="colm4 colm6-tab pull-right-tab colm pad-10">
                                        <label for="breadth_store" class="gui-label pad-5">ارزش پیشنهادی مشخص و ملموس </label>
                                        <div class="rate-part">
                                            <input type="range" min="1" max="5" value="<?php if($score_suggestedvalue){echo $score_suggestedvalue;}else{echo 0;} ?>" class="renge" name="score_suggestedvalue">
                                            <span class="font-s11">امتیاز:</span>
                                            <p class="font-s11 inlin-block"></p>
                                        </div>
                                    </div>
                                    <div class="colm4 colm6-tab pull-right-tab colm pad-10">
                                        <label for="breadth_store" class="gui-label pad-5">کیفیت MVP</label>
                                        <div class="rate-part">
                                            <input onchange="" type="range" min="1" max="5" value="<?php if($score_mvp){echo $score_mvp;}else{echo 0;} ?>" class="renge" name="score_mvp">
                                            <span class="font-s11">امتیاز:</span>
                                            <p class="font-s11 inlin-block"></p>
                                        </div>
                                    </div>
                                </div>
                                <div class="colm12 colm frm-row pad-5 pad-t20 slidecontainer">
                                    <div class="colm4 colm6-tab pull-right-tab colm pad-10">
                                        <label for="breadth_store" class="gui-label pad-5">شفاف بودن جریان‌های درآمدی </label>
                                        <div class="rate-part">
                                            <input type="range" min="1" max="5" value="<?php if($score_transparency){echo $score_transparency;}else{echo 0;} ?>" class="renge" name="score_transparency">
                                            <span class="font-s11">امتیاز:</span>
                                            <p class="font-s11 inlin-block"></p>
                                        </div>
                                    </div>
                                    <div class="colm4 colm6-tab pull-right-tab pull-right-tab colm pad-10">
                                        <label for="breadth_store" class="gui-label pad-5">داشتن مزیت رقابتی</label>
                                        <div class="rate-part">
                                            <input type="range" min="1" max="5" value="<?php  if($score_advantage){echo $score_advantage;}else{echo 0;} ?>" class="renge" name="score_advantage">
                                            <span class="font-s11">امتیاز:</span>
                                            <p class="font-s11 inlin-block"></p>
                                        </div>
                                    </div>
                                    <div class="colm4 colm6-tab pull-right-tab colm pad-10">
                                        <label for="breadth_store" class="gui-label pad-5">داشتن استراتژی ورود به بازار</label>
                                        <div class="rate-part">
                                            <input type="range" min="1" max="5" value="<?php  if($score_strategy){echo $score_strategy;}else{echo 0;} ?>" class="renge" name="score_strategy">
                                            <span class="font-s11">امتیاز:</span>
                                            <p class="font-s11 inlin-block"></p>
                                        </div>
                                    </div>
                                </div>
                                <hr>
                            </div>
                            <div class="pad-card">
                                <h4 class="font-w300 font-s16 spacer-t10">کیفیت مستندات ارسالی </h4>
                                <div class="colm12 colm frm-row pad-5 pad-t20 slidecontainer">
                                    <div class="colm4 colm6-tab pull-right-tab colm pad-10">
                                        <label for="breadth_store" class="gui-label pad-5">کامل و دقیق بودن مستندات</label>
                                        <div class="rate-part">
                                            <input type="range" min="1" max="5" value="<?php  if($score_precise){echo $score_precise;}else{echo 0;}  ?>" class="renge" name="score_precise">
                                            <span class="font-s11">امتیاز:</span>
                                            <p class="font-s11 inlin-block"></p>
                                        </div>
                                    </div>
                                </div>
                                <hr>
                            </div>
                            <div class="pad-card">
                                <h4 class="font-w300 font-s16 spacer-t10">نظر داور</h4>
                                <div class="pad-t30">
                                    <label class="relative">
                                        <textarea name="score_comment" class="gui-input sans-digit" id="referee-comment"><?php  echo $score_comment; ?></textarea>
                                    </label>
                                </div>                          
                            </div>

                            <div class="spacer-b10 spacer-t20 flex-center-row">
                                <button type="submit" name="btn_problem_store" class="icon-dabir transparent-btn accept pad-5 iransans">
                                    <span><i class="aaa fa fa-check"></i></span>
                                    <p class="font-s11 align-center">ثبت</p>
                                </button>
                            </div>
                            
                            <div class="colm12 colm pad-t40">
                                <button type="submit" name="score_accept_status" value="accepted_referee" class="iransans colm6 colm accept-card btn-ui pull-right">
                                    <span><i class="aaa fa fa-check"></i></span>
                                    قبول کردن تیم
                                </button>
                                <button type="submit" name="score_feiled_status" value="failed_referee" class="iransans colm6 colm times-card btn-ui pull-right">
                                    <span><i class="aaa fa fa-times"></i></span>
                                    رد کردن تیم
                                </button>
                                <div class="clearfix"></div>
                            </div>
                        </form>
                    </div>
                <?php }?>

                <div class="body-form relative pad-25 pad-r35 pad-l35 pad-5-mob wow fadeInUpBig" data-wow-duration="1s">
                    <div class="bg-chart2 body-form-top absolute flex-center">
                        <a name="team"></a><i class="fa fa-portrait vertical font-s30 color-white"></i>
                    </div>
                    <div class="absolute title-panel">
                        <h3 class="font-w300 font-s18 ">اطلاعات pitch deck <?php echo $referee_count; ?></h3>
                    </div>
                    <div class="frm-row pad-t30">
                        <div class="colm12 pad-5 pad-t20">
                            <p class="pull-right font-w300 font-s14">چه مشکلی را حل می کنید؟</p>
                            <p class="pull-right pad-r10 font-w400 font-s14 color-black pad-r10"><?php echo $problem; ?></p>
                            <div class="clearfix"></div>
                        </div>
                        <div class="colm12 pad-5 pad-t20">
                            <p class="pull-right font-w300 font-s14">راه حل شما چیست ؟</p>
                            <p class="pull-right pad-r10 font-w400 font-s14 color-black pad-r10"><?php echo $mysolution; ?></p>
                            <div class="clearfix"></div>
                        </div>
                        <div class="colm12 pad-5 pad-t20">
                            <p class="pull-right font-w300 font-s14">راه حل های موجود چیست ؟</p>
                            <p class="pull-right pad-r10 font-w400 font-s14 color-black pad-r10"><?php echo $solution; ?></p>
                            <div class="clearfix"></div>
                        </div>
                        <div class="colm12 pad-5 pad-t20">
                            <p class="pull-right font-w300 font-s14">اندازه بازار برای اینکار چقدر است ؟</p>
                            <p class="pull-right pad-r10 font-w400 font-s14 color-black pad-r10"><?php echo $market_size; ?></p>
                            <div class="clearfix"></div>
                        </div>
                        <div class="colm12 pad-5 pad-t20">
                            <p class="pull-right font-w300 font-s14">رقبای داخلی و خارجی شما چه کسانی هستند ؟</p>
                            <p class="pull-right pad-r10 font-w400 font-s14 color-black pad-r10"><?php echo $defect; ?></p>
                            <div class="clearfix"></div>
                        </div>
                        <?php if($pdf):?>
                            <div class="colm12 pad-5 pad-t20">
                                <a href="<?php echo wp_get_attachment_url( $pdf ); ?>" download>دانلود پیچ دک</a>
                            </div>
                        <?php endif ?>
                        <div class="clearfix"></div>
                    </div>
                </div>
                <?php if($video):?>
                    <div class="body-form relative spacer-t30 pad-25 pad-r35 pad-l35 pad-5-mob wow fadeInUpBig" data-wow-duration="1s">
                        <div class="bg-chart6 body-form-top absolute flex-center">
                            <i class="fa fa-play vertical font-s30 color-white"></i>
                        </div>
                        <div class="absolute title-panel">
                            <h3 class="font-w300 font-s18 ">ویدیوی معرفی </h3>
                        </div>
                        <div class="frm-row pad-t30">
                            <div class="colm12 pad-5 pad-t20">
                                <video width="100%" controls>
                                    <source src="<?php echo wp_get_attachment_url( $video ); ?>"></source>
                                </video>
                            </div>
                        </div>
                    </div>
                <?php endif ?>
                <div class="body-form relative spacer-t30 pad-25 pad-r35 pad-l35 pad-5-mob wow fadeInUpBig" data-wow-duration="1s">
                    <div class="bg-chart3 body-form-top absolute flex-center">
                        <i class="fa fa-user-edit vertical font-s30 color-white"></i>
                    </div>
                    <div class="absolute title-panel">
                        <h3 class="font-w300 font-s18 ">اطلاعات تکمیلی</h3>
                    </div>
                    <div class="frm-row pad-t30">
                        <div class="colm12 pad-5 pad-t20">
                            <p class="pull-right font-w300 font-s14">نحوه آشنایی با اعضای تیم؟</p>
                            <p class="pull-right pad-r10 font-w400 font-s14 color-black pad-r10"><?php echo $introduction; ?></p>
                            <div class="clearfix"></div>
                        </div>
                        <div class="colm12 pad-5 pad-t20">
                            <p class="pull-right font-w300 font-s14">چه چیز باعث شده شما بهتر از بقیه باشید ؟</p>
                            <p class="pull-right pad-r10 font-w400 font-s14 color-black pad-r10"><?php echo $better; ?></p>
                            <div class="clearfix"></div>
                        </div>
                        <div class="colm12 pad-5 pad-t20">
                            <p class="pull-right font-w300 font-s14">تیمتون چه چیزی کم داره ؟</p>
                            <p class="pull-right pad-r10 font-w400 font-s14 color-black pad-r10"><?php echo $defect_team; ?></p>
                            <div class="clearfix"></div>
                        </div>
                        <div class="clearfix"></div>
                    </div>
                </div>
                <div class="body-form relative spacer-t30 pad-25 pad-r35 pad-l35 pad-5-mob wow fadeInUpBig" data-wow-duration="1s">
                    <div class="bg-chart6 body-form-top absolute flex-center">
                        <i class="fa fa-user-tie  vertical font-s30 color-white"></i>
                    </div>
                    <div class="absolute title-panel">
                        <h3 class="font-w300 font-s18 ">اطلاعات رهبر تیم</h3>
                    </div>
                    <div class="frm-row pad-t30">
                        <div class="colm4 colm pull-right pad-5 pad-t20">
                            <p class="pull-right font-w300 font-s14">نام:</p>
                            <p class="pull-right pad-r10 font-w400 font-s14 color-black"><?php echo $firstname; ?></p>
                            <div class="clearfix"></div>
                        </div>
                        <div class="colm4 colm pull-right pad-5 pad-t20">
                            <p class="pull-right font-w300 font-s14">نام خانوادگی:</p>
                            <p class="pull-right pad-r10 font-w400 font-s14 color-black"><?php echo $lastname; ?></p>
                            <div class="clearfix"></div>
                        </div>
                        <div class="colm4 colm pull-right pad-5 pad-t20">
                            <p class="pull-right font-w300 font-s14">شماره همراه:</p>
                            <p class="pull-right pad-r10 font-w400 font-s14 color-black"><?php echo $mobile; ?></p>
                            <div class="clearfix"></div>
                        </div>
                        <div class="colm4 colm pull-right pad-5 pad-t20">
                            <p class="pull-right font-w300 font-s14">ایمیل:</p>
                            <p class="pull-right pad-r10 font-w400 font-s13 color-black"><?php echo $email; ?></p>
                            <div class="clearfix"></div>
                        </div>
                        <div class="colm4 colm pull-right pad-5 pad-t20">
                            <p class="pull-right font-w300 font-s14">لینکدین:</p>
                            <p class="pull-right pad-r10 font-w400 font-s14 color-black"><?php echo $linkedin; ?></p>
                            <div class="clearfix"></div>
                        </div>
                        <div class="colm4 colm pull-right pad-5 pad-t20">
                            <p class="pull-right font-w300 font-s14">تاریخ تولد:</p>
                            <p class="pull-right pad-r10 font-w400 font-s14 color-black"><?php echo jdate('Y/m/d',strtotime($birthday)); ?></p>
                            <div class="clearfix"></div>
                        </div>
                        <div class="colm4 colm pull-right pad-5 pad-t20">
                            <p class="pull-right font-w300 font-s14">تخصص:</p>
                            <p class="pull-right pad-r10 font-w400 font-s14 color-black"><?php echo $expertise; ?></p>
                            <div class="clearfix"></div>
                        </div>
                        <div class="colm4 colm pull-right pad-5 pad-t20">
                            <p class="pull-right font-w300 font-s14">تحصیلات:</p>
                            <p class="pull-right pad-r10 font-w400 font-s14 color-black"><?php echo $educationl; ?></p>
                            <div class="clearfix"></div>
                        </div>
                        <div class="colm4 colm pull-right pad-5 pad-t20">
                            <p class="pull-right font-w300 font-s14">میزان سهام:</p>
                            <p class="pull-right pad-r10 font-w400 font-s14 color-black"><?php echo $stock; ?></p>
                            <div class="clearfix"></div>
                        </div>
                   <!--     <div class="colm4 colm pull-right pad-5 pad-t20">
                            <p class="pull-right font-w300 font-s14">سمت در استارت آپ :</p>
                            <p class="pull-right pad-r10 font-w400 font-s14 color-black"><?php echo $side; ?></p>
                            <div class="clearfix"></div>
                        </div>-->
                        <div class="colm8 colm pull-right pad-5 pad-t20">
                            <p class="pull-right font-w300 font-s14">میانگین زمان اختصاص داده شده به استارتاپ در طول ماه:</p>
                            <p class="pull-right pad-r10 font-w400 font-s14 color-black"><?php echo $average; ?></p>
                            <div class="clearfix"></div>
                        </div>

                        <div class="clearfix"></div>
                    </div>
                </div>
                <?php
                $args = array(
                    'showposts'=>10,
                    'query'=>array(
                        array(
                            'key'=>'user_id',
                            'value'=>$user_id,
                            'compare'=>'='
                        ),
                        array(
                            'key'=>'status',
                            'value'=>'publish',
                            'compare'=>'='
                        )
                    )
                );
                $group_user = query_data('group_user',$args);
                ?>
                <?php foreach($group_user as $number_s):
                        switch($number_s->education) {
                            case '1': $number_s->education = 'زیر دیپلم'; break;
                            case '2': $number_s->education = 'دیپلم'; break;
                            case '3': $number_s->education = 'فوق دیپلم'; break;
                            case '4': $number_s->education = 'لیسانس'; break;
                            case '5': $number_s->education = 'فوق لیسانس'; break;
                            case '6': $number_s->education = 'دکتری'; break;
                            case '7': $number_s->education = 'فوق دکتری'; break;
                        }
                    ?>
                    <div class="body-form relative spacer-t30 pad-25 pad-r35 pad-l35 pad-5-mob wow fadeInUpBig" data-wow-duration="1s">
                        <div class="body-form-top absolute flex-center">
                            <i class="fa fa-users vertical font-s30 color-white"></i>
                        </div>
                        <div class="absolute title-panel">
                            <h3 class="font-w300 font-s18">اطلاعات اعضای تیم</h3>
                        </div>
                        <div class="frm-row pad-t30">
                            <div class="colm4 colm pull-right pad-5 pad-t20">
                                <p class="pull-right font-w300 font-s14">نام:</p>
                                <p class="pull-right pad-r10 font-w400 font-s14 color-black"><?php echo $number_s->first_name; ?></p>
                                <div class="clearfix"></div>
                            </div>
                            <div class="colm4 colm pull-right pad-5 pad-t20">
                                <p class="pull-right font-w300 font-s14">نام خانوادگی:</p>
                                <p class="pull-right pad-r10 font-w400 font-s14 color-black"><?php echo $number_s->last_name; ?></p>
                                <div class="clearfix"></div>
                            </div>
                            <div class="colm4 colm pull-right pad-5 pad-t20">
                                <p class="pull-right font-w300 font-s14">شماره همراه:</p>
                                <p class="pull-right pad-r10 font-w400 font-s14 color-black"><?php echo $number_s->mobile; ?></p>
                                <div class="clearfix"></div>
                            </div>
                            <div class="colm4 colm pull-right pad-5 pad-t20">
                                <p class="pull-right font-w300 font-s14">ایمیل:</p>
                                <p class="pull-right pad-r10 font-w400 font-s13 color-black"><?php echo $number_s->email; ?></p>
                                <div class="clearfix"></div>
                            </div>
                            <div class="colm4 colm pull-right pad-5 pad-t20">
                                <p class="pull-right font-w300 font-s14">لینکدین:</p>
                                <p class="pull-right pad-r10 font-w400 font-s14 color-black"><?php echo $number_s->socials; ?></p>
                                <div class="clearfix"></div>
                            </div>
                            <div class="colm4 colm pull-right pad-5 pad-t20">
                                <p class="pull-right font-w300 font-s14">تاریخ تولد:</p>
                                <p class="pull-right pad-r10 font-w400 font-s14 color-black">
                                	<?php echo jdate('Y/m/d',strtotime($number_s->birthday)); ?>
                                </p>
                                <div class="clearfix"></div>
                            </div>
                            <div class="colm4 colm pull-right pad-5 pad-t20">
                                <p class="pull-right font-w300 font-s14">تخصص:</p>
                                <p class="pull-right pad-r10 font-w400 font-s14 color-black"><?php echo $number_s->expertise; ?></p>
                                <div class="clearfix"></div>
                            </div>
                            <div class="colm4 colm pull-right pad-5 pad-t20">
                                <p class="pull-right font-w300 font-s14">تحصیلات:</p>
                                <p class="pull-right pad-r10 font-w400 font-s14 color-black"><?php echo $number_s->education; ?></p>
                                <div class="clearfix"></div>
                            </div>
                            <div class="colm4 colm pull-right pad-5 pad-t20">
                                <p class="pull-right font-w300 font-s14">سمت در استارت آپ :</p>
                                <p class="pull-right pad-r10 font-w400 font-s14 color-black"><?php echo  $number_s->side; ?></p>
                                <div class="clearfix"></div>
                            </div>
                            <div class="colm8 colm pull-right pad-5 pad-t20">
                                <p class="pull-right font-w300 font-s14">میانگین زمان اختصاص داده شده به استارتاپ در طول ماه:</p>
                                <p class="pull-right pad-r10 font-w400 font-s14 color-black"><?php echo $number_s->average; ?></p>
                                <div class="clearfix"></div>
                            </div>
                            <div class="colm4 colm pull-right pad-5 pad-t20">
                                <p class="pull-right font-w300 font-s14">میزان سهام:</p>
                                <p class="pull-right pad-r10 font-w400 font-s14 color-black"><?php echo  $number_s->stock; ?></p>
                                <div class="clearfix"></div>
                            </div>
                            <div class="clearfix"></div>
                        </div>
                    </div>
                <?php endforeach ?>

            </div>
            <div class="colm3 colm12-tab colm pull-right spacer-t30-mob spacer-t30-tab">
            <?php if(array_intersect($allowed_roles, $current_user->roles )){?>
                    <div>
                        <div class="body-form pad-15 spacer-b10 spacer-t10 pad-5-mob wow zoomIn relative" data-wow-duration="1s">
                            <div class="bg-chart3 body-form-top absolute flex-center">
                                <i class="fa fa-rocket vertical font-s30 color-white"></i>
                            </div>
                            <div class="absolute title-panel">
                                <h3 class="font-w300 font-s18">اطلاعات استارتاپ ها</h3>
                            </div>
                            <div class="frm-row pad-t20 line-h">
                                <div class="colm12 colm pull-right pad-5 pad-t20">
                                    <p class="pull-right font-w300 font-s13">نام استــارت آپ:</p>
                                    <p class="pull-right pad-r10 font-w400 font-s12 color-black"><?php echo $startup_name; ?></p>
                                    <div class="clearfix"></div>
                                </div>
                                <div class="colm12 colm pull-right pad-5 pad-t20">
                                    <p class="pull-right font-w300 font-s13">سایت استــارت آپ:</p>
                                    <p class="pull-right pad-r10 font-w400 font-s12 color-black">
                                        <?php
                                        if (!preg_match("~^(?:f|ht)tps?://~i", $website)) {
									        $website = "http://" . $website;
									    }
                                        ?>
                                        <a href="<?php echo $website;?>" target="_blank"><?php echo $protocol.' '.$website; ?></a>
                                    </p>
                                    <div class="clearfix"></div>
                                </div>
                                <div class="colm12 colm pull-right pad-5 pad-t20">
                                    <p class="pull-right font-w300 font-s13">تا کنون سرمایه جذب کرده اید:</p>
                                    <p class="pull-right pad-r10 font-w400 font-s12 color-black"><?php echo $investment; ?></p>
                                    <div class="clearfix"></div>
                                </div>
                                <div class="colm12 colm pull-right pad-5 pad-t20">
                                    <p class="pull-right font-w300 font-s13">نمونه اولیه ساخته اید:</p>
                                    <p class="pull-right pad-r10 font-w400 font-s12 color-black"><?php echo $prototype; ?></p>
                                    <div class="clearfix"></div>
                                </div>
                                <div class="colm12 colm pull-right pad-5 pad-t20">
                                    <p class="pull-right font-w300 font-s13">تاریخ شروع به کار:</p>
                                    <p class="pull-right pad-r10 font-w400 font-s12 color-black"><?php echo $start_date; ?></p>
                                    <div class="clearfix"></div>
                                </div>
                                <div class="clearfix"></div>
                            </div>
                        </div>
                        <?php
                        if($status=='pending')  { ?>
                        <div class="body-form pad-15 spacer-b10 spacer-t30 pad-5-mob wow zoomIn relative" data-wow-duration="1s">
                            <div class="bg-chart6 body-form-top absolute flex-center">
                                <i class="fa fa-user-shield vertical font-s30 color-white"></i>
                            </div>
                            <div class="absolute title-panel">
                                <h3 class="font-w300 font-s18 ">وضعیت استارت آپ</h3>
                            </div>
                            <?php if(in_array('operational' , $roles) || array_intersect($allowed_all, $current_user->roles )){?>
                                <form method="post">
                                    <div class="pad-t40 pad-5">
                                        <label for="" class="pad-5 color-blue font-s13 bold font-w300">نظر مدیرعملیاتی</label>
                                        <label class="relative">
                                            <textarea name="admin_comment" class="gui-input sans-digit" id="admin-comment"><?php echo $admin_comment; ?></textarea>
                                        </label>
                                    </div>
                                    <div class="align-center pad-t10 flex-spacebetween pad-b15">
                                        <button type="submit" name="status" value="failed" class="icon-dabir times transparent-btn pad-5 iransans">
                                            <span><i class="fa fa-times"></i></span>
                                            <p class="font-s11 align-center">رد</p>
                                        </button>
                                        <a href="<?php echo home_url("/startup-edit/$user_id") ?>" class="icon-dabir edit pad-5 iransans">
                                            <span><i class="fa fa-pencil-alt"></i></span>
                                            <p class="font-s11 align-center">ویرایش </p>
                                        </a>
                                        <button type="submit" name="status" value="accepted" class="icon-dabir transparent-btn accept pad-5 iransans">
                                            <span><i class="fa fa-check"></i></span>
                                            <p class="font-s11 align-center">تایید</p>
                                        </button>
                                    </div>
                                </form>
                            <?php }else{?>
                                <div class="pad-t40 pad-5">
                                    <div class="pad-5 color-blue font-s13 bold font-w300">نظر مدیرعملیاتی</div>
                                    <p class="font-s13"><?php echo ($admin_comment)?$admin_comment:"مدیر نظری نداده است"; ?></p>
                                </div>
                            <?php }?>
                            <?php if($status == "failed"): ?>
                                <div class="alert alert-rose alert-with-icon colm12 colm flex-center spacer-b10 spacer-t30 wow zoomIn"  data-wow-duration="1s" data-notify="container">
                                    <div class="flex-center-row"><i class="fa fa-times pad-l5"></i> رد شده است.</div>
                                </div>
                            <?php elseif($status == "accepted"): ?>
                                <div class="alert alert-success alert-with-icon colm12 colm flex-center spacer-b10 spacer-t30 wow zoomIn" data-wow-duration="1s" data-notify="container">
                                    <div class="flex-center-row"><i class="fa fa-check pad-l5"></i> تایید شده است.</div>
                                </div>
                            <?php endif ?>
                            <div class="clearfix"></div>
                        </div>
                        <?php } ?>
                        <?php if(array_intersect($allowed_referee, $roles ) || array_intersect($allowed_all, $current_user->roles )){ ?>
                            
                                <div class="body-form pad-15 spacer-b10 spacer-t30 pad-5-mob  wow zoomIn relative" data-wow-duration="1s">
                                    <div class="bg-chart2 body-form-top absolute flex-center">
                                        <i class="fa fa-balance-scale vertical font-s30 color-white"></i>
                                    </div>
                                    <div class="absolute title-panel">
                                        <h3 class="font-w300 font-s18">نتیجه داوری</h3>
                                    </div>
                                    <div class="frm-row pad-t20">
                                        <?php
                                        $id_author1=$data_referee[0]->author_id;
                                        $score_full =$data_referee[0]->score_full;
                                        $score_coordination = $data_referee[0]->score_coordination;
                                        $score_ability = $data_referee[0]->score_ability;
                                        $score_market = $data_referee[0]->score_market;
                                        $score_growth = $data_referee[0]->score_growth;
                                        $score_competition = $data_referee[0]->score_competition;
                                        $score_targetmarket = $data_referee[0]->score_targetmarket;
                                        $score_suggestedvalue = $data_referee[0]->score_suggestedvalue;
                                        $score_mvp = $data_referee[0]->score_mvp;
                                        $score_transparency = $data_referee[0]->score_transparency;
                                        $score_advantage = $data_referee[0]->score_advantage;
                                        $score_strategy = $data_referee[0]->score_strategy;
                                        $score_precise = $data_referee[0]->score_precise;
                                        $score_comment = $data_referee[0]->score_comment;
                                        $vote1=(($score_full+$score_coordination+$score_ability)/3)*35/100;
                                        $vote2=(($score_market+$score_growth+$score_competition)/3)*20/100;
                                        $vote3=(($score_targetmarket+$score_suggestedvalue+$score_mvp+$score_transparency+$score_advantage+ $score_strategy)/6)*35/100;
                                        $vote4=(($score_precise)/1)*10/100;
                                        $totoal_score1 = $vote1+$vote2+$vote3+$vote4;

                                        ?>
                                        <?php if($id_author1){?>
                                            <div class="colm12 colm pull-right pad-5 pad-t20">
                                                <p class="pull-right font-w300 font-s13">نمره داور اول: <?php echo number_format($totoal_score1, 2, '.', ''); ?></p>
                                                <p class="pull-right pad-r10 font-w400 font-s12 color-black"></p>
                                                <a href="#open-modal1" class="font-s12 pull-left color-mentor show-popup">نمایش</a>
                                                <div class="open-popup">
                                                    <div id="open-modal1" class="modal-window">
                                                        <div class="content colm">
                                                            <a href="#modal-close" title="بستن" class="modal-close"><i class="fa fa-times"></i></a>
                                                            <?php get_template_part('content','vote1') ?>
                                                        </div>
                                                    </div>
                                                </div>
                                                <div class="clearfix"></div>
                                            </div>
                                        <?php }?>
                                        <?php
                                        $id_author2=$data_referee[1]->author_id;
                                        $score_full =$data_referee[1]->score_full;
                                        $score_coordination = $data_referee[1]->score_coordination;
                                        $score_ability = $data_referee[1]->score_ability;
                                        $score_market = $data_referee[1]->score_market;
                                        $score_growth = $data_referee[1]->score_growth;
                                        $score_competition = $data_referee[1]->score_competition;
                                        $score_targetmarket = $data_referee[1]->score_targetmarket;
                                        $score_suggestedvalue = $data_referee[1]->score_suggestedvalue;
                                        $score_mvp = $data_referee[1]->score_mvp;
                                        $score_transparency = $data_referee[1]->score_transparency;
                                        $score_advantage = $data_referee[1]->score_advantage;
                                        $score_strategy = $data_referee[1]->score_strategy;
                                        $score_precise = $data_referee[1]->score_precise;
                                        $score_comment = $data_referee[1]->score_comment;
                                        $vote1=(($score_full+$score_coordination+$score_ability)/3)*35/100;
                                        $vote2=(($score_market+$score_growth+$score_competition)/3)*20/100;
                                        $vote3=(($score_targetmarket+$score_suggestedvalue+$score_mvp+$score_transparency+$score_advantage+ $score_strategy)/6)*35/100;
                                        $vote4=(($score_precise)/1)*10/100;
                                        $totoal_score2 = $vote1+$vote2+$vote3+$vote4;

                                        ?>
                                        <?php if($id_author2){?>
                                            <div class="colm12 colm pull-right pad-5 pad-t20">
                                                <p class="pull-right font-w300 font-s13">نمره داور دوم: <?php echo number_format($totoal_score2, 2, '.', ''); ?></p>
                                                <p class="pull-right pad-r10 font-w400 font-s12 color-black"></p>
                                                <a href="#open-modal2" class="font-s12 pull-left color-mentor show-popup">نمایش</a>
                                                <div class="open-popup">
                                                    <div id="open-modal2" class="modal-window">
                                                        <div class="content colm">
                                                            <a href="#modal-close" title="بستن" class="modal-close"><i class="fa fa-times"></i></a>
                                                            <?php get_template_part('content','vote2') ?>
                                                        </div>
                                                    </div>
                                                </div>
                                                <div class="clearfix"></div>
                                            </div>
                                        <?php }?>
                                        <?php
                                        $id_author3=$data_referee[2]->author_id;
                                        $score_full =$data_referee[2]->score_full;
                                        $score_coordination = $data_referee[2]->score_coordination;
                                        $score_ability = $data_referee[2]->score_ability;
                                        $score_market = $data_referee[2]->score_market;
                                        $score_growth = $data_referee[2]->score_growth;
                                        $score_competition = $data_referee[2]->score_competition;
                                        $score_targetmarket = $data_referee[2]->score_targetmarket;
                                        $score_suggestedvalue = $data_referee[2]->score_suggestedvalue;
                                        $score_mvp = $data_referee[2]->score_mvp;
                                        $score_transparency = $data_referee[2]->score_transparency;
                                        $score_advantage = $data_referee[2]->score_advantage;
                                        $score_strategy = $data_referee[2]->score_strategy;
                                        $score_precise = $data_referee[2]->score_precise;
                                        $score_comment = $data_referee[2]->score_comment;
                                        $vote1=(($score_full+$score_coordination+$score_ability)/3)*35/100;
                                        $vote2=(($score_market+$score_growth+$score_competition)/3)*20/100;
                                        $vote3=(($score_targetmarket+$score_suggestedvalue+$score_mvp+$score_transparency+$score_advantage+ $score_strategy)/6)*35/100;
                                        $vote4=(($score_precise)/1)*10/100;
                                        $totoal_score3 = $vote1+$vote2+$vote3+$vote4;

                                        ?>
                                        <?php if($id_author3){?>
                                            <div class="colm12 colm pull-right pad-5 pad-t20">
                                                <p class="pull-right font-w300 font-s13">نمره داور سوم: <?php echo number_format($totoal_score3, 2, '.', ''); ?></p>
                                                <p class="pull-right pad-r10 font-w400 font-s12 color-black"></p>
                                                <a href="#open-modal3" class="font-s12 pull-left color-mentor show-popup">نمایش</a>
                                                <div class="open-popup">
                                                    <div id="open-modal3" class="modal-window">
                                                        <div class="content colm">
                                                            <a href="#modal-close" title="بستن" class="modal-close"><i class="fa fa-times"></i></a>
                                                            <?php get_template_part('content','vote3') ?>
                                                        </div>
                                                    </div>
                                                </div>
                                                <div class="clearfix"></div>
                                            </div>
                                        <?php }?>
                                        <?php

                                        $id_author4=$data_referee[3]->author_id;
                                        $score_full =$data_referee[3]->score_full;
                                        $score_coordination = $data_referee[3]->score_coordination;
                                        $score_ability = $data_referee[3]->score_ability;
                                        $score_market = $data_referee[3]->score_market;
                                        $score_growth = $data_referee[3]->score_growth;
                                        $score_competition = $data_referee[3]->score_competition;
                                        $score_targetmarket = $data_referee[3]->score_targetmarket;
                                        $score_suggestedvalue = $data_referee[3]->score_suggestedvalue;
                                        $score_mvp = $data_referee[3]->score_mvp;
                                        $score_transparency = $data_referee[3]->score_transparency;
                                        $score_advantage = $data_referee[3]->score_advantage;
                                        $score_strategy = $data_referee[3]->score_strategy;
                                        $score_precise = $data_referee[3]->score_precise;
                                        $score_comment = $data_referee[3]->score_comment;
                                        $vote1=(($score_full+$score_coordination+$score_ability)/3)*35/100;
                                        $vote2=(($score_market+$score_growth+$score_competition)/3)*20/100;
                                        $vote3=(($score_targetmarket+$score_suggestedvalue+$score_mvp+$score_transparency+$score_advantage+ $score_strategy)/6)*35/100;
                                        $vote4=(($score_precise)/1)*10/100;
                                        $totoal_score4 = $vote1+$vote2+$vote3+$vote4;

                                        ?>
                                        <?php if($id_author4){?>
                                            <div class="colm12 colm pull-right pad-5 pad-t20">
                                                <p class="pull-right font-w300 font-s13">نمره داور چهارم: <?php echo number_format($totoal_score4, 2, '.', ''); ?></p>
                                                <p class="pull-right pad-r10 font-w400 font-s12 color-black"></p>
                                                <a href="#open-modal4" class="font-s12 pull-left color-mentor show-popup">نمایش</a>
                                                <div class="open-popup">
                                                    <div id="open-modal4" class="modal-window">
                                                        <div class="content colm">
                                                            <a href="#modal-close" title="بستن" class="modal-close"><i class="fa fa-times"></i></a>
                                                            <?php get_template_part('content','vote4') ?>
                                                        </div>
                                                    </div>
                                                </div>
                                                <div class="clearfix"></div>
                                            </div>
                                        <?php } ?>
                                        <?php
                                        $number_all=($totoal_score1+$totoal_score2+$totoal_score3+$totoal_score4)/$query_aa;

                                        ?>
                                        <?php if($id_author1 || $id_author2 || $id_author3 || $id_author4){?>
                                            <div class="align-center border-t-chart colm colm12 pad-5 pad-t20 pull-right color-mentor font-s14">
                                                <span><i class="fa fa-clone"></i></span>
                                                <span>نمره نهایی:<?php echo $id_user; ?></span>
                                                <span><?php echo number_format($number_all, 2, '.', '');?></span>
                                                <span>از 5</span>
                                            </div>
                                        <?php }?>
                                        <?php if(empty($data_referee[0]->id)){?>

                                            <div class="align-center border-t-chart colm colm12 pad-5 pad-t20 pull-right color-mentor font-s14">
                                                <span><i class="fa fa-clone"></i></span>
                                                <span>این تیم هنوز داوری نشده</span>
                                            </div>

                                        <?php } ?>
                                        <div class="clearfix"></div>
                                    </div>
                                </div>
                        
                        <?php }?>
                        <div class="body-form pad-15 spacer-b10 spacer-t30 pad-5-mob wow zoomIn relative" data-wow-duration="1s">
                            <div class="bg-chart1 body-form-top absolute flex-center">
                                <i class="fa fa-chalkboard-teacher vertical font-s30 color-white"></i>
                            </div>
                            <div class="absolute title-panel">
                                <h3 class="font-w300 font-s18 ">وضعیت داوری</h3>
                            </div>
                            <?php if(in_array('operational' , $roles) || array_intersect($allowed_all, $current_user->roles )){?>
                                <form method="post">
                                    <div class="pad-t40 pad-5">
                                        <label for="" class="pad-5 color-blue font-s13 bold font-w300">نظر مدیر عملیاتی</label>
                                        <label class="relative">
                                            <textarea name="modir_comment" class="gui-input sans-digit" id="modir_comment"><?php echo $modir_comment; ?></textarea>
                                        </label>
                                    </div>
                                    <div class="align-center pad-t10 flex-spacearound  pad-b15">
                                        <button type="submit" name="status_modir" value="failed_modir" class="icon-dabir times transparent-btn pad-5 iransans">
                                            <span><i class="fa fa-times"></i></span>
                                            <p class="font-s11 align-center">رد</p>
                                        </button>
                                        <button type="submit" name="status_modir" value="accepted_modir" class="icon-dabir transparent-btn accept pad-5 iransans">
                                            <span><i class="fa fa-check"></i></span>
                                            <p class="font-s11 align-center">تایید</p>
                                        </button>
                                    </div>
                                </form>
                            <?php }else{?>
                                <div class="pad-t40 pad-5">
                                    <div class="pad-5 color-blue font-s13 bold font-w300">نظر مدیر</div>
                                    <p class="font-s13"><?php echo ($modir_comment)?$modir_comment:"مدیر نظری نداده است"; ?></p>
                                </div>
                            <?php }?>
                            <?php if($status_modir == "failed_modir"): ?>
                                <div class="alert alert-rose alert-with-icon colm12 colm flex-center spacer-b10 spacer-t30 wow zoomIn"  data-wow-duration="1s" data-notify="container">
                                    <div class="flex-center-row font-s13"><i class="fa fa-times pad-l5"></i> توسط مدیر عملیاتی رد شد.</div>
                                </div>
                            <?php elseif($status_modir == "accepted_modir"): ?>
                                <div class="alert alert-success alert-with-icon colm12 colm flex-center spacer-b10 spacer-t30 wow zoomIn" data-wow-duration="1s" data-notify="container">
                                    <div class="flex-center-row font-s13"><i class="fa fa-check pad-l5"></i>توسط مدیرعملیاتی تایید شد.</div>
                                </div>
                            <?php endif ?>
                            <div class="clearfix"></div>
                        </div>

                    </div>
                <?php } ?>


            </div>
            <div class="clearfix"></div>
        </div>
    </div>
    <?php get_footer() ?>
    <?php get_footer('admin') ?>
<?php }else{
    wp_redirect(home_url());
}?>
<script>
    jQuery(document).ready(function($){
        const sliders = document.querySelectorAll(".rate-part");

        sliders.forEach(function(slider){
            const input = slider.querySelector('input');
            const output = slider.querySelector('p');

            output.innerHTML = input.value;

            input.oninput = function () {
                output.innerHTML = this.value;
            }
        })
    });

    function searchApi(id,resultId ,name){
        var searchRequest = null;
        var resultid = resultId;
        var _resultid = "'"+resultId+"'";
        var param = name;
        var _id = '.'+id;
        var minlength = 2;
        var refereeAPI = "https://app.100startups.ir/api/?";

            clearTimeout(this.delay);
            this.delay = setTimeout( function() {
                var field , that = this, value = jQuery(_id).val();
                if (value.length >= minlength) {
                   data = {
                        type : param,
                        field : value
                    };
                   jQuery.getJSON(refereeAPI, data).done(function(data) {
                        if (data.length) {
                            var output = '<ul class="searchresult">';
                            jQuery.each(data, function(i, item) {
                                output += '<li  data-id="' + item.id + '" data-name="' + item.name + '">';
                                output += '<span>' + item.name + '</span>';
                                output += '</li>';
                                if (i === 8) {
                                    return false;
                                }
                            });
                            output += '</ul>';
                            console.log(jQuery(that).closest('.'+resultId));
                            jQuery(that).closest('.'+resultId).append(output);
                        }else{
                            jQuery(that).closest('.'+resultId).append('<span class="font-s14">فردی با این نام پیدا نشد</span>');
                        }
                    }).fail(function() {
                        console.log("error");
                    }).always(function() {

                    });
                } else {
                    jQuery(that).siblings('.'+resultid).html('').hide();
                }
            }.bind(this), 500);

        jQuery(document).on('click', '.'+resultid+' .searchresult li', function($) {
            var id = $(this).data("id");
            var name = $(this).data("name");
            $(this).parents().eq(2).find('.referee-name').val(name);
            $(this).parents().eq(2).find('.referee-id').val(id);
            $('.referee-result').hide();
        })
    }
    // auto compelete
    jQuery(document).ready(function($){

        $(".rate-part input").on('change',function(){
            var t = $(this);
            var x = t.val();
            t.attr('value',x);
            t.closest('span').text(x);
            console.log(x);
        })




    })

    // abrz

</script>
<script>
    new WOW().init();
</script>
<script>
    jQuery(document).ready(function($){
        $(".open-popup").click(function(){
            $(".modal-window").hide();
        });
        $(".show-popup").click(function(){
            $(".modal-window").show();
        });

    });


    function scrollTo(element) {
        var scrollToId = element.getAttribute('data-scroll');

    }
</script>