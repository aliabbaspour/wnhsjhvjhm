<?php // template name: send-message  ?>
<?php
$current_user = wp_get_current_user();
if(is_user_logged_in()) {
$user_id = get_query_var('id_m');
$user = get_userdata($user_id);
?>




<?php }else{
    wp_redirect(home_url());
}?>