<?php 
$user = wp_get_current_user();
$user_id = $user->ID;
$status = get_user_meta($user_id,'status',true);

switch ($status) {
	case 'pending':
		$status = 'در حال بررسی';
		break;
	case 'accepted':
		$status = 'تایید شده';
		break;
	case 'referee':
		$status = 'در حال داوری';
		break;
	case 'companion':
		$status = 'در حال اختصاص راهبر ارشد';
		break;
	default: 
		
		break;
}
?>
<?php get_header() ?>
<?php get_header('admin') ?>
<style>
	.hide-tab{
		display: none;
	}
</style>
<div class="colm12 colm  margin-auto">
	<div class="spacer-t25">
		<div class="pad-t30">
			<div class="frm-row">
				<div class="colm4 colm12-tab colm pull-left pad-15 pad-5-mob spacer-b25-mob wow fadeInDown" data-wow-duration="1s">
					<div class="body-form body-form1 pad-15 relative">
						<div class="pad-b10">
							<div class="bg-chart1 icon-cat-panel absolute  flex-center">
								<i class="fa fa-rocket vertical font-s30 color-white"></i>
							</div>
							<div class="align-right">
								<a href="#" class="color-darkgray font-w200 font-s15">وضعیت استارتاپ شما</a>
								<h4 class="font-w300 font-s20 title-panel"><?php echo $status ?></h4>
							</div>
						</div>
						<div class="border-t-chart font-w200 font-s12 pad-t10">
							<span class="font-w300">
								<i class="fa fa-chart-bar pad-l5 verticall"></i>
							</span>
							<span>
								نتیجه :
							</span>
						</div>
					</div>
				</div>
			</div>
		</div>
		<div class="colm8 colm12-tab colm pull-right pad-10 pad-5-mob">
	     	<div class="body-form pad-b25 spacer-b30" >
	     		<div class="flex">
		        	<!--<div class="colm2 font-s10 colm pull-right taga ">
		        		<a href="#">
		        			<div class="tab1 flex-center sg-tab " data-id="1">اختصاص داور</div>
		        		</a>
		        	</div>-->
		        	<div class="colm3 font-s10 colm pull-right taga">
		        		<a href="#">
		        			<div class="tabfin flex-center sg-tab" data-id="2">اختصاص راهبر</div>
		        		</a>	
		        	</div>
		        	<div class="colm4 font-s10 colm pull-right taga">   
		        		<a href="#">
		        			<div class="tabfin flex-center  sg-tab" data-id="3">داوری غیرحضوری</div>
		        		</a>	
		        	</div>
		        	<div class="colm4 font-s10 colm pull-right taga">
		        		<a href="#">
		        			<div class="tabfin flex-center sg-tab" data-id="4">ارزیابی داوران</div>
		        		</a>	
		        	</div>
		        	<div class="colm4 font-s10 colm pull-right taga"> 
		        		<a href="#">
		        			<div class="tabfin5 flex-center sg-tab" data-id="5">داوری حضوری</div>
		        		</a>	
		        	</div>
		        	
		        	<!--<div class="colm2 font-s10 colm pull-right taga ">
		        		<a href="#">
		        			<div class="tabfin flex-center sg-tab" data-id="5">پیش قرارداد</div>
		        		</a>	
		        	</div>-->
		        	
		        	<div class="clearfix"></div>
	     		</div>
	     		<div class="cnt1 sg-content " id="1">
				
	     		</div>
	     		<div class="cnt2 sg-content align-center hide" id="2">
	     			
	     		</div>
	     		<div class="cnt3 sg-content align-center hide" id="3">
	     		
	     		</div>
	     		<div class="cnt4 sg-content align-center hide" id="4">
	     		
	     		</div>
	     		<div class="cnt5 sg-content align-center hide" id="5">
	     			
	     		</div>
	     		<div class="cnt6 sg-content align-center hide" id="6">
	     		
	     		</div>
	     	</div>
	     	<div class="body-form relative pad-15 pad-25 pad-r35 pad-l35" >
     			<div class="bg-chart1 body-form-top absolute flex-center">
					<i class="fa fa-rocket vertical font-s30 color-white"></i>
				</div>
				<div class="absolute title-panel">
					<h3 class="font-w300 font-s18">اطلاعات استــارت آپ ها</h3>
				</div>
				<div class="frm-row pad-t20">
					<div class="colm4 colm pull-right pad-5 pad-t20">
						<p class="pull-right font-w300 font-s14">نام استــارت آپ:</p>
						<p class="pull-right pad-r10 font-w400 font-s14 color-black"><?php echo $startup_name; ?></p>
						<div class="clearfix"></div>
					</div>
					<div class="colm4 colm pull-right pad-5 pad-t20">
						<p class="pull-right font-w300 font-s14">سایت استــارت آپ:</p>
						<p class="pull-right pad-r10 font-w400 font-s14 color-black">
							<a href="<?php echo $website;?>" target="_blank"><?php echo $website; ?></a>
						</p>
						<div class="clearfix"></div>
					</div>
					<div class="colm4 colm pull-right pad-5 pad-t20">
						<p class="pull-right font-w300 font-s14">تا کنون سرمایه جذب کرده اید:</p>
						<p class="pull-right pad-r10 font-w400 font-s14 color-black"><?php echo $investment; ?></p>
						<div class="clearfix"></div>
					</div>
					<div class="colm4 colm pull-right pad-5 pad-t20">
						<p class="pull-right font-w300 font-s14">نمونه اولیه ساخته اید:</p>
						<p class="pull-right pad-r10 font-w400 font-s14 color-black"><?php echo $prototype; ?></p>
						<div class="clearfix"></div>
					</div>
					<div class="colm4 colm pull-right pad-5 pad-t20">
						<p class="pull-right font-w300 font-s14">تاریخ شروع به کار:</p>
						<p class="pull-right pad-r10 font-w400 font-s14 color-black"><?php echo $start_date; ?></p>
						<div class="clearfix"></div>
					</div>
					<div class="clearfix"></div>
				</div>
	     	</div>
			<?php if(array_intersect($allowed_startup_level, $current_user->roles )): ?>

	     	<?php endif ?>
	     	<div class="relative spacer-t30 payam1" data-wow-duration="1s">
				<div class="body-form relative pad-b10">
					<div class="payam">
		     			<div class="bg-chart5 body-form-top absolute flex-center">
							<i class="fa fa-comment vertical font-s30 color-white"></i>
						</div>
						<div class="absolute title-panel">
							<h3 class="font-w300 font-s18">آخرین پیام ها</h3>
						</div>
					</div>
					<div class="pad-table overflow-scroll">
						<table class="table color6">
							<thead>
								<tr>
									<th class="center">عنوان پیام</th>
									<th class="center">نام فرستنده</th>
									<th class="center">ایمیل فرستنده</th>
									<th class="center">خلاصه پیام</th>
								 </tr>
							</thead>
							<tbody>
								<?php 
							 $args=array(
			                    'number' => 2,
			                    'role__not_in' => array( 'administrator','manager','secretariat','referee','operational' ),
			                    'orderby' => 'ID',
			                    'order' => 'DESC',
		                    );
							$user_query = new WP_User_Query($args); 
							$i=1;
							if ( ! empty( $user_query->get_results() ) ) {
								foreach ( $user_query->get_results() as $user ) {
								//	print_r($user);
								$user_id 	= $user->ID;
								$user_login	= $user->user_login;
								$role 		= $user->roles[0];
								$startup_name = get_user_meta($user_id,'startup_name',true);
								$firstname  = get_user_meta($user_id,'first_name',true);
		    					$lastname   = get_user_meta($user_id,'last_name',true);
		    					$mobile   	= get_user_meta($user_id,'mobile',true);
								$expertise	= get_user_meta($user_id,'expertise',true);
								$dabir_ok 	= get_user_meta($user_id,'dabir_ok',true);
								if($dabir_ok == "ok"){
									$class = "bg-success";
								}elseif($dabir_ok == "remove"){
									$class = "bg-danger";
								}elseif($dabir_ok == "edit"){
									$class = "bg-info";
								}else{
									$class ="bg-white";
								}
							?>
							 <tr class="<?php echo $class; ?>">
								<td class="center"><?php echo $startup_name; ?></td>
								<td class="center"><?php echo $firstname.' '.$lastname; ?></td>
								<td class="center"><?php echo jdate('Y/m/d',$user->user_registered);?></td>
								<td class="center">
									<a class="color-silver" title="نمایش" href="<?php echo home_url("/information/$user_id") ?>" 
										<span>
											<i class="align-center font-s20 fa fa-address-card"></i>
										</span>								
									</a>
								</td>
					  		</tr>
					  		<tr class="<?php echo $class; ?>">
								<td class="center"><?php echo $startup_name; ?></td>
								<td class="center"><?php echo $firstname.' '.$lastname; ?></td>
								<td class="center"><?php echo jdate('Y/m/d',$user->user_registered);?></td>
								<td class="center">
									<a class="color-silver" title="نمایش" href="<?php echo home_url("/information/$user_id") ?>" 
										<span>
											<i class="align-center font-s20 fa fa-address-card"></i>
										</span>								
									</a>
								</td>
					  		</tr>
						  		<?php		
								}wp_reset_query();
							}
							?>
							</tbody>
						</table>
					</div>
				</div>
			</div>
	     	<div class="body-form relative spacer-t30 pad-25 pad-r35 pad-l35" data-wow-duration="1s">
				<div class="bg-chart2 body-form-top absolute flex-center">
					<i class="fa fa-portrait vertical font-s30 color-white"></i>
				</div>
				<div class="absolute title-panel">
					<h3 class="font-w300 font-s18 ">اطلاعات pitch deck</h3>
				</div>
				<div class="frm-row pad-t30">
					<div class="colm12 pad-5 pad-t20">
						<p class="pull-right font-w300 font-s14">چه مشکلی را حل می کنید؟</p>
						<p class="pull-right pad-r10 font-w400 font-s14 color-black pad-r10"><?php echo $problem; ?></p>
						<div class="clearfix"></div>
					</div>
					<div class="colm12 pad-5 pad-t20">
						<p class="pull-right font-w300 font-s14">راه حل شما چیست ؟</p>
						<p class="pull-right pad-r10 font-w400 font-s14 color-black pad-r10"><?php echo $mysolution; ?></p>
						<div class="clearfix"></div>
					</div>
					<div class="colm12 pad-5 pad-t20">
						<p class="pull-right font-w300 font-s14">راه حل های موجود چیست ؟</p>
						<p class="pull-right pad-r10 font-w400 font-s14 color-black pad-r10"><?php echo $solution; ?></p>
						<div class="clearfix"></div>
					</div>
					<div class="colm12 pad-5 pad-t20">
						<p class="pull-right font-w300 font-s14">اندازه بازار برای اینکار چقدر است ؟</p>
						<p class="pull-right pad-r10 font-w400 font-s14 color-black pad-r10"><?php echo $market_size; ?></p>
						<div class="clearfix"></div>
					</div>
					<div class="colm12 pad-5 pad-t20">
						<p class="pull-right font-w300 font-s14">رقبای داخلی و خارجی شما چه کسانی هستند ؟</p>
						<p class="pull-right pad-r10 font-w400 font-s14 color-black pad-r10"><?php echo $defect; ?></p>
						<div class="clearfix"></div>
					</div>
					<?php if($pdf):?>
					<div class="colm12 pad-5 pad-t20">
						<a href="<?php echo wp_get_attachment_url( $pdf ); ?>" download>دانلود پیچ دک</a>
					</div>
					<?php endif ?>
					<div class="clearfix"></div>
				</div>
	     	</div>
	     	<?php if($video):?>
	     	<div class="body-form relative spacer-t30 pad-25 pad-r35 pad-l35" data-wow-duration="1s">
				<div class="bg-chart4 body-form-top absolute flex-center">
					<i class="fa fa-play vertical font-s30 color-white"></i>
				</div>
				<div class="absolute title-panel">
					<h3 class="font-w300 font-s18 ">ویدیوی معرفی</h3>
				</div>
				<div class="frm-row pad-t30">
					<div class="colm12 pad-5 pad-t20">
						<video width="100%" controls>
							<source src="<?php echo wp_get_attachment_url( $video ); ?>"></source>
						</video>
					</div>
				</div>
			</div>
	     	<?php endif ?>
	     	<div class="body-form relative spacer-t30 pad-25 pad-r35 pad-l35" data-wow-duration="1s">
				<div class="bg-chart3 body-form-top absolute flex-center">
					<i class="fa fa-user-edit vertical font-s30 color-white"></i>
				</div>
				<div class="absolute title-panel">
					<h3 class="font-w300 font-s18 ">اطلاعات تکمیلی</h3>
				</div>
				<div class="frm-row pad-t30">
					<div class="colm12 pad-5 pad-t20">
						<p class="pull-right font-w300 font-s14">نحوه آشنایی با اعضای تیم؟</p>
						<p class="pull-right pad-r10 font-w400 font-s14 color-black pad-r10"><?php echo $introduction; ?></p>
						<div class="clearfix"></div>
					</div>
					<div class="colm12 pad-5 pad-t20">
						<p class="pull-right font-w300 font-s14">چه چیز باعث شده شما بهتر از بقیه باشید ؟</p>
						<p class="pull-right pad-r10 font-w400 font-s14 color-black pad-r10"><?php echo $better; ?></p>
						<div class="clearfix"></div>
					</div>
					<div class="colm12 pad-5 pad-t20">
						<p class="pull-right font-w300 font-s14">تیمتون چه چیزی کم داره ؟</p>
						<p class="pull-right pad-r10 font-w400 font-s14 color-black pad-r10"><?php echo $defect_team; ?></p>
						<div class="clearfix"></div>
					</div>
					<div class="clearfix"></div>
				</div>
	     	</div>
	     	<div class="body-form relative spacer-t30 pad-25 pad-r35 pad-l35" data-wow-duration="1s">
				<div class="bg-chart4 body-form-top absolute flex-center">
					<i class="fa fa-user-tie  vertical font-s30 color-white"></i>
				</div>
				<div class="absolute title-panel">
					<h3 class="font-w300 font-s18 ">اطلاعات رهبر تیم</h3>
				</div>
				<div class="frm-row pad-t30">
					<div class="colm4 colm pull-right pad-5 pad-t20">
						<p class="pull-right font-w300 font-s14">نام:</p>
						<p class="pull-right pad-r10 font-w400 font-s14 color-black"><?php echo $firstname; ?></p>
						<div class="clearfix"></div>
					</div>
					<div class="colm4 colm pull-right pad-5 pad-t20">
						<p class="pull-right font-w300 font-s14">نام خانوادگی:</p>
						<p class="pull-right pad-r10 font-w400 font-s14 color-black"><?php echo $lastname; ?></p>
						<div class="clearfix"></div>
					</div>
					<div class="colm4 colm pull-right pad-5 pad-t20">
						<p class="pull-right font-w300 font-s14">شماره همراه:</p>
						<p class="pull-right pad-r10 font-w400 font-s14 color-black"><?php echo $mobile; ?></p>
						<div class="clearfix"></div>
					</div>
					<div class="colm4 colm pull-right pad-5 pad-t20">
						<p class="pull-right font-w300 font-s14">ایمیل:</p>
						<p class="pull-right pad-r10 font-w400 font-s13 color-black"><?php echo $email; ?></p>
						<div class="clearfix"></div>
					</div>
					<div class="colm4 colm pull-right pad-5 pad-t20">
						<p class="pull-right font-w300 font-s14">لینکدین:</p>
						<p class="pull-right pad-r10 font-w400 font-s14 color-black"><?php echo $linkedin; ?></p>
						<div class="clearfix"></div>
					</div>
					<div class="colm4 colm pull-right pad-5 pad-t20">
						<p class="pull-right font-w300 font-s14">تاریخ تولد:</p>
						<p class="pull-right pad-r10 font-w400 font-s14 color-black"><?php echo $birthday; ?></p>
						<div class="clearfix"></div>
					</div>
					<div class="colm4 colm pull-right pad-5 pad-t20">
						<p class="pull-right font-w300 font-s14">تخصص:</p>
						<p class="pull-right pad-r10 font-w400 font-s14 color-black"><?php echo $expertise; ?></p>
						<div class="clearfix"></div>
					</div>
					<div class="colm4 colm pull-right pad-5 pad-t20">
						<p class="pull-right font-w300 font-s14">تحصیلات:</p>
						<p class="pull-right pad-r10 font-w400 font-s14 color-black"><?php echo $education; ?></p>
						<div class="clearfix"></div>
					</div>
					<div class="colm4 colm pull-right pad-5 pad-t20">
						<p class="pull-right font-w300 font-s14">سمت در استارت آپ :</p>
						<p class="pull-right pad-r10 font-w400 font-s14 color-black"><?php echo $side; ?></p>
						<div class="clearfix"></div>
					</div>
					<div class="clearfix"></div>
					<div class="colm12 colm  pad-5 pad-t20">
						<p class="pull-right font-w300 font-s14">میانگین زمان اختصاص داده شده به استارتاپ در طول ماه:</p>
						<p class="pull-right pad-r10 font-w400 font-s14 color-black"><?php echo $average; ?></p>
						<div class="clearfix"></div>
					</div>
				</div>
	     	</div>
	     	<?php
				$args = array(
					'showposts'=>10,
					'query'=>array(
						array(
							'key'=>'user_id',
							'value'=>$user_id,
							'compare'=>'='
						),
						array(
							'key'=>'status',
							'value'=>'publish',
							'compare'=>'='
						)
					)
				);
				$group_user = query_data('group_user',$args);
			?>
			<?php foreach($group_user as $number_s): ?>
	     	<div class="body-form relative spacer-t30 pad-25 pad-r35 pad-l35" data-wow-duration="1s">
 				<div class="body-form-top absolute flex-center">
					<i class="fa fa-users vertical font-s30 color-white"></i>
				</div>
				<div class="absolute title-panel">
					<h3 class="font-w300 font-s18">اطلاعات اعضای تیم</h3>
				</div>
				<div class="frm-row pad-t30">
					<div class="colm4 colm pull-right pad-5 pad-t20">
						<p class="pull-right font-w300 font-s14">نام:</p>
						<p class="pull-right pad-r10 font-w400 font-s14 color-black"><?php echo $number_s->first_name; ?></p>
						<div class="clearfix"></div>
					</div>
					<div class="colm4 colm pull-right pad-5 pad-t20">
						<p class="pull-right font-w300 font-s14">نام خانوادگی:</p>
						<p class="pull-right pad-r10 font-w400 font-s14 color-black"><?php echo $number_s->last_name; ?></p>
						<div class="clearfix"></div>
					</div>
					<div class="colm4 colm pull-right pad-5 pad-t20">
						<p class="pull-right font-w300 font-s14">شماره همراه:</p>
						<p class="pull-right pad-r10 font-w400 font-s14 color-black"><?php echo $number_s->mobile; ?></p>
						<div class="clearfix"></div>
					</div>
					<div class="colm4 colm pull-right pad-5 pad-t20">
						<p class="pull-right font-w300 font-s14">ایمیل:</p>
						<p class="pull-right pad-r10 font-w400 font-s13 color-black"><?php echo $number_s->email; ?></p>
						<div class="clearfix"></div>
					</div>
					<div class="colm4 colm pull-right pad-5 pad-t20">
						<p class="pull-right font-w300 font-s14">لینکدین:</p>
						<p class="pull-right pad-r10 font-w400 font-s14 color-black"><?php echo $number_s->socials; ?></p>
						<div class="clearfix"></div>
					</div>
					<div class="colm4 colm pull-right pad-5 pad-t20">
						<p class="pull-right font-w300 font-s14">تاریخ تولد:</p>
						<p class="pull-right pad-r10 font-w400 font-s14 color-black"><?php echo $number_s->birthday; ?></p>
						<div class="clearfix"></div>
					</div>
					<div class="colm4 colm pull-right pad-5 pad-t20">
						<p class="pull-right font-w300 font-s14">تخصص:</p>
						<p class="pull-right pad-r10 font-w400 font-s14 color-black"><?php echo $number_s->expertise; ?></p>
						<div class="clearfix"></div>
					</div>
					<div class="colm4 colm pull-right pad-5 pad-t20">
						<p class="pull-right font-w300 font-s14">تحصیلات:</p>
						<p class="pull-right pad-r10 font-w400 font-s14 color-black"><?php echo $number_s->education; ?></p>
						<div class="clearfix"></div>
					</div>
					<div class="colm4 colm pull-right pad-5 pad-t20">
						<p class="pull-right font-w300 font-s14">سمت در استارت آپ :</p>
						<p class="pull-right pad-r10 font-w400 font-s14 color-black"><?php echo  $number_s->side; ?></p>
						<div class="clearfix"></div>
					</div>
					<div class="clearfix"></div>
					<div class="colm12 colm  pad-5 pad-t20">
						<p class="pull-right font-w300 font-s14">میانگین زمان اختصاص داده شده به استارتاپ در طول ماه:</p>
						<p class="pull-right pad-r10 font-w400 font-s14 color-black"><?php echo $number_s->average; ?></p>
						<div class="clearfix"></div>
					</div>
				</div>
	     	</div>
			<?php endforeach ?>
			
		</div>
        <div class="colm4 colm12-tab colm pull-left pad-15 pad-5-mob spacer-b25-mob wow fadeInDown" data-wow-duration="1s">
            <div class="body-form body-form1 pad-15 relative">
                <div class="pad-b10">
                    <div class="bg-chart5 icon-cat-panel absolute  flex-center">
                        <i class="fa fa-wallet vertical font-s30 color-white"></i>
                    </div>
                    <div class="align-right">
                        <a href="<?php echo home_url("/request-money") ?>" class="color-darkgray font-w200 font-s15">کیف پول</a>
                    </div>
                </div>
                <div class="border-t-chart font-w200 font-s12">
                    <div class="colm12 colm pull-right pad-5 pad-t20">
                        <p class="pull-right font-w300 font-s17">اختصاص داده شده:</p>
                        <p class="pull-right pad-r10 font-w400 font-s14 color-black"></p>
                        <div class="clearfix"></div>
                    </div>
                    <div class="colm12 colm pull-right pad-5 pad-t20">
                        <p class="pull-right font-w300 font-s17">باقی مانده:</p>
                        <p class="pull-right pad-r10 font-w400 font-s14 color-black"></p>
                        <div class="clearfix"></div>
                    </div>
                    <div class="colm12 colm pull-right pad-5 pad-t20">
                        <p class="pull-right font-w300 font-s17">برداشت شده:</p>
                        <p class="pull-right pad-r10 font-w400 font-s14 color-black"></p>
                        <div class="clearfix"></div>
                    </div>
                </div>
            </div>
        </div>
			<div class="colm3 colm pull-right"> 
				<?php if(array_intersect($allowed_secretariat, $current_user->roles )){ ?>
					<div>
						<?php if($status == "failed"): ?>
							<div class="alert alert-rose alert-with-icon colm12 colm flex-center spacer-b10 spacer-t10 "  data-notify="container">
								<div class="flex-center-row"><i class="fa fa-times pad-l5"></i> رد شده است.</div>
					      	</div>
				      	<?php elseif($status == "accepted"): ?>
							<div class="alert alert-success alert-with-icon colm12 colm flex-center spacer-b10 spacer-t10 "  data-notify="container">
								<div class="flex-center-row"><i class="fa fa-check pad-l5"></i> تایید شده است.</div>
					      	</div>
				      	<?php endif ?>
				     	<div class="body-form pad-15 spacer-b10 spacer-t10relative" >
							<div class="bg-chart1 body-form-top absolute flex-center">
								<i class="fa fa-user-shield vertical font-s30 color-white"></i>
							</div>
							<div class="absolute title-panel">
								<h3 class="font-w300 font-s18 ">دبیرخانه</h3>
							</div>
							<?php if($current_user_role == 'secretariat'){?>
							<form method="post">
				                <div class="pad-t40 pad-5">
				                    <label for="" class="pad-5 color-blue font-s13 bold font-w300">نظر دبیر</label>
				                    <label class="relative">
				                        <textarea name="admin_comment" class="gui-input sans-digit" id="admin-comment"><?php echo $admin_comment; ?></textarea>
				                    </label>
				                </div>
				                <div class="align-center pad-t10 flex-spacebetween pad-b15">
									<button type="submit" name="status" value="failed" class="icon-dabir times transparent-btn pad-5 iransans">
										<span><i class="fa fa-times"></i></span>
										<p class="font-s11 align-center">رد</p>
									</button> 
									<a href="<?php echo home_url("/startup-edit/$user_id") ?>" class="icon-dabir edit pad-5 iransans">
										<span><i class="fa fa-pencil-alt"></i></span>
										<p class="font-s11 align-center">ویرایش </p>
									</a> 
									<button type="submit" name="status" value="accepted" class="icon-dabir transparent-btn accept pad-5 iransans">
										<span><i class="fa fa-check"></i></span>
										<p class="font-s11 align-center">تایید</p>
									</button>
								</div>
							</form>
							<?php }else{?>
				     			<div class="pad-t40 pad-5">
				                    <div class="pad-5 color-blue font-s13 bold font-w300">نظر دبیر</div>
				                    <p class="font-s13"><?php echo ($admin_comment)?$admin_comment:"دبیر نظری نداده است"; ?></p>
				                </div>
				     		<?php }?>
			     		</div>
					</div>
				<?php } ?>
			
				<?php if(array_intersect($allowed_referee, $current_user->roles )): ?>
					<div class="body-form pad-15 spacer-b10 spacer-t30  relative" >
						<div class="bg-chart2 body-form-top absolute flex-center">
							<i class="fa fa-balance-scale vertical font-s30 color-white"></i>
						</div>
						<div class="absolute title-panel">
							<h3 class="font-w300 font-s18 ">داوری</h3>
						</div>
						<form method="post">
							<div class="colm12 colm pad-5">
								<label for="breadth_store" class="gui-label pad-5">اندازه بازار</label>
								<div class="slidecontainer">
								  <input type="range" min="1" max="10" value="<?php if($renge1){echo $renge1;}else echo 0 ; ?>" class="renge" name="renge1" id="myRange">
								  <p class="font-s11">امتیاز: <span id="demo"></span></p> 
								</div>  
							</div>
							<div class="colm12 colm pad-5">
								<label for="breadth_store" class="gui-label pad-5">حل مشکل</label>
								<div class="slidecontainer">
							 	  <input type="range" min="1" max="10" value="<?php if($renge2){echo $renge2;}else echo 0 ; ?>" class="renge" name="renge2" id="myRange2">
								  <p class="font-s11">امتیاز: <span id="demo2"></span></p> 
								</div>
							</div>
							<?php if($current_user_role == 'referee'){?>
							<div class="spacer-b10 spacer-t10 flex-center-row">
								<button type="submit" name="btn_problem_store" class="icon-dabir transparent-btn accept pad-5 iransans">
									<span><i class="aaa fa fa-check"></i></span>
									<p class="font-s11 align-center">تایید</p>
								</button>
							</div>
							<?php } ?>
						</form>
			     	</div>
				<?php endif ?>	
			</div>
     	<div class="clearfix"></div>
	</div>
</div>
<style>
header , footer{
	display: none;
}
</style>
<?php get_footer('admin'); ?>
<?php get_footer(); ?>
<script>
var range = document.getElementById("myRange");
var output = document.getElementById("demo");
output.innerHTML = range.value;

range.oninput = function() {
  output.innerHTML = range.value;
}

var range2 = document.getElementById("myRange2");
var outputt = document.getElementById("demo2");
outputt.innerHTML = range2.value;

range2.oninput = function() {
  outputt.innerHTML = range2.value;
}

// auto compelete
jQuery(document).ready(function($){
	var searchRequest = null;
	var minlength = 2;
	var refereeAPI = "https://app.100startups.ir/api/?";
	$("#choosementor input").on('input', function() {
		clearTimeout(this.delay);
		this.delay = setTimeout( function() {

			var field , that = this, value = $(this).val();
			var resultid = 'referee-result'
			if (value.length >= minlength) {
				$.getJSON(refereeAPI, {
					field : value,
				}).done(function(data) {
					if (data.length) {
						var output = '<ul class="searchresult">';
						$.each(data, function(i, item) {
							output += '<li  data-id="' + item.id + '" data-name="' + item.name + '">';
							output += '<span>' + item.name + '</span>';
							output += '</li>';
							if (i === 8) {
								return false;
							}
						});
						output += '</ul>';
						$(that).parent().find('.referee-result').show().html(output);
					}else{
						$(that).parent().find('.referee-result').show().html('<span class="font-s14">فردی با این نام پیدا نشد</span>');
					}
				}).fail(function() {
					console.log("error");
				}).always(function() {

				});
			} else {
				$(that).parent().find('.referee-result').html('').hide();
			}
		}.bind(this), 500);
	});

	$(document).on('click', '.referee-result .searchresult li', function() {
		var id = $(this).data("id");
		var name = $(this).data("name");
		$(this).parents().eq(2).find('.referee-name').val(name);
		$(this).parents().eq(2).find('.referee-id').val(id);
		$('.referee-result').hide();
	})
})
</script>
<script>
	new WOW().init();
</script>