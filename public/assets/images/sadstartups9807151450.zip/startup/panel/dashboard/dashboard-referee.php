<?php
$user = wp_get_current_user();
$user_id = $user->ID;
$user_role = $user->roles[0];
$allowed_all= array('editor', 'administrator','managers');
$args=array('number' => -1,'role__in' => array( 'referee' ));
$user_query = new WP_User_Query($args); 
$args=array('number' => -1,'role__in' => array( 'investor' ));
$user_query_investor = new WP_User_Query($args); 

$args=array(
    'number' => -1,
    'role__in' => array( 'coach' ),
	
);
$user_query_coach = new WP_User_Query($args); 
$args=array(
    'number' => -1,
    'role__not_in' => array('editor', 'administrator','managers','investor','coach','secretariat','referee','operational'),
	
);
$user_query_sub = new WP_User_Query($args); 

$args=array(
    'number' => -1,
    'meta_query' => array(
		array(
			'key'     => 'roles',
			'value'   => serialize(strval('referee')),
			'compare' => 'LIKE',
		)
	),
	
);
$user_ok_referee = new WP_User_Query($args); 

$query_referee = array(
	'meta_key' => 'status',
	'meta_value' => 'referee',
);
$count_referee = query_count('usermeta',$query_referee);


?>
<?php get_header(); ?>
<?php get_header('admin'); ?>
<style>

</style>
<div class="pad-t40">
	<div class="frm-row">
		<div>
			<div class="colm4 colm12-tab colm pull-right pad-15 pad-5-mob spacer-b25-mob wow fadeInDown" data-wow-duration="1s">
				<div class="body-form pad-15 relative">
					<div class="pad-b10">
						<div class="bg-chart1 icon-cat-panel absolute  flex-center">
							<i class="fa fa-rocket vertical font-s30 color-white"></i>
						</div>
						<div class="align-right">
							<a href="<?php echo home_url("/list-startup") ?>" class="color-darkgray font-w200 font-s15">استارتاپ ها</a>
							<h4 class="font-w300 font-s20 title-panel"><?php echo count($user_query_sub->get_results()) ?></h4>
						</div>
					</div>
					<div class="border-t-chart font-w200 font-s12 pad-t10">
						<span class="font-w300">
							<i class="fa fa-chart-bar pad-l5 verticall"></i>
						</span>
						<span>
							همه استارتاپ ها
						</span>
					</div>
				</div>
			</div>
			<div class="colm4 colm12-tab colm pull-right pad-15 pad-5-mob spacer-b25-mob wow fadeInDown" data-wow-duration="1s">
				<div class="body-form pad-15 relative">
					<div class="pad-b10">
						<div class="bg-chart2 icon-cat-panel absolute flex-center">
							<i class="fa fa-check vertical font-s30 color-white"></i>
						</div>
						<div class="align-right">
							<a href="#" class="color-darkgray font-w200 font-s15">داوری شده</a>
							<h4 class="font-w300 font-s20 title-panel"><?php echo $count_referee ;?></h4>
						</div>
					</div>
					<div class="border-t-chart font-w200 font-s12 pad-t10">
						<span class="font-w300">
							<i class="fa fa-chart-bar pad-l5 vertical"></i>
						</span>
						<span>
							 آمار داوری شده ها
						</span>
					</div>
				</div>
			</div>
			<div class="colm4 colm12-tab colm pull-right pad-15 pad-5-mob spacer-b25-mob wow fadeInDown" data-wow-duration="1.5s">
				<div class="body-form pad-15 relative">
					<div class="pad-b10">
						<div class="bg-chart3 icon-cat-panel absolute flex-center">
							<i class="fa fa-times  vertical font-s30 color-white"></i>
						</div>
						<div class="align-right">
							<a href="#" class="color-darkgray font-w200 font-s15">داوری نشده</a>
							<h4 class="font-w300 font-s20 title-panel">28</h4>
						</div>
					</div>
					<div class="border-t-chart font-w200 font-s12 pad-t10">
						<span class="font-w300">
							<i class="fa fa-chart-bar pad-l5 vertical"></i>
						</span>
						<span>
							آمار داوری نشده ها
						</span>
					</div>
				</div>
			</div>
			<div class="clearfix"></div>
		</div>
	</div>
	<div class="frm-row pad-t40 spacer-b25-mob pad-5-mob">
		<div class="body-form relative wow fadeInUpBig" data-wow-duration="1s">
			<div class="pad-b10">
     			<div class="bg-chart1 body-form-top absolute flex-center">
					<i class="fa fa-pause vertical font-s30 color-white"></i>
				</div>
				<div class="absolute title-panel">
					<h3 class="font-w300 font-s18 font-s12-mob">استارتاپ های در انتظار داوری</h3>
				</div>
				<div class="frm-row  pad-t25-mob pad-t30-tab">
					<div class="colm4 colm12-tab colm pull-left pull-none relative pad-20">      
					     <input class="input-panel align-right" placeholder="جستجو کنید..." type="search" name="" value=""  >
					     <span class="bar"></span>
				    </div>
				</div>
			</div>
			<div class="frm-row pad-t40">
				<div class="overflow-scroll pad-b40">
					<?php
						if($_GET['status'] == 'accepted'){
							$query = array(
								'key'       => 'status',
								'value'     => 'accepted',
								'compare'   => '=',
							);
						}
						if($_GET['status'] == 'failed'){
							$query = array(
								'key'       => 'status',
								'value'     => 'failed',
								'compare'   => '=',
							);
						}
						if($_GET['status'] == 'pending'){
							$query = array(
								'key'       => 'status',
								'value'     => 'pending',
								'compare'   => '=',
							);
						}

						$user_id = $user->ID;
						$allowedRoles = array('editor', 'administrator','managers');
						$number = 10; 
						$roleIn = array('subscriber');
						$metaQuery = array(
								'relation' => 'OR',
								array(
									'key'       => 'referee1',
									'value'     => $user_id,
									'compare'   => '=',
								),
								array(
									'key'       => 'referee2',
									'value'     => $user_id,
									'compare'   => '=',
								),
								array(
									'key'       => 'referee3',
									'value'     => $user_id,
									'compare'   => '=',
								),
								array(
									'key'       => 'referee4',
									'value'     => $user_id,
									'compare'   => '=',
								),
								$query
						);
					$list = new list_users();
					$list->startups($allowedRoles ,$metaQuery ,$number );

				?>

				</div>
			</div>
		</div>
	</div>
	<div class="colm12 colm pull-right pad-t40 pad-5-mob spacer-b25-mob wow slideInRight" data-wow-duration="1.5s">
		<div class="body-form relative pad-b10 spacer-b20">
			<div class="payam">
     			<div class="bg-chart5 body-form-top absolute flex-center">
					<i class="fa fa-comment vertical font-s30 color-white"></i>
				</div>
				<div class="absolute title-panel">
					<h3 class="font-w300 font-s18">آخرین پیام ها</h3>
				</div>
			</div>
            <div class="pad-table overflow-scroll">
                <table class="table color6">
                    <thead>
                    <tr>
                        <th class="center">عنوان پیام</th>
                        <th class="center">نام فرستنده</th>
                        <th class="center">ایمیل فرستنده</th>
                        <th class="center">تاریخ</th>
                        <th class="center">عملیات</th>
                    </tr>
                    </thead>
                    <tbody>
                    <?php
                    $args = array();
                    $query_data = query_data('message',$args);
                    if ( ! empty( $query_data ) ) {
                        foreach ( $query_data as $data ) {
                            $reciver = get_userdata( $data->receiver_id );
                            ?>
                            <tr class="<?php echo $class; ?>">
                                <td class="center"><?php echo $data->message_title ;  ?></td>
                                <td class="center"><?php echo $reciver->last_name .  ", " . $reciver->first_name ; ?></td>
                                <td class="center"><?php echo $reciver->user_email; ?></td>
                                <td class="center"><?php echo jdate('Y/m/d',$data->date);?></td>
                                <td class="center">
                                    <a class="color-silver" title="نمایش" href="<?php   ?>"
                                    <span>
											<i class="align-center font-s20 fa fa-address-card"></i>
										</span>
                                    </a>
                                </td>
                            </tr>
                        <?php }	}else{?>
                        <th colspan="5" style="background: #f7f5ed;">
                            <img height="174" src="<?php bloginfo('template_url');?>/assets/images/whitespace/notification.png" alt="whitespace" />
                        </th>
                    <?php } ;?>
                    </tbody>
                </table>
            </div>
		</div>
	</div>
</div>
<?php get_footer(); ?>
<?php get_footer('admin'); ?>
<style>

	rect.highcharts-background{
		fill:transparent
	}
	g.highcharts-exporting-group {
    display: none;
}
text.highcharts-credits {
    display: none;
}
</style>

<script>
	new WOW().init();
</script>
