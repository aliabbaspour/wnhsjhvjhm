<?php
$args=array('number' => -1,'role__in' => array( 'referee' ));
$user_query = new WP_User_Query($args); 
$args=array('number' => -1,'role__in' => array( 'investor' ));
$user_query_investor = new WP_User_Query($args); 

$args=array(
    'number' => -1,
    'role__in' => array( 'coach' ),
	
);
$user_query_coach = new WP_User_Query($args); 
$args=array(
    'number' => -1,
    'role__not_in' => array('editor', 'administrator','managers'),
	
);
$user_query_sub = new WP_User_Query($args); 
?>
<style>
#chartdiv {
  width: 100%;
  max-width: 100%;
  height:400px;
}
#chartdiv1 {
  width: 100%;
  height: 500px;
  font-size: 11px;
}
#chartdiv2 {
  width: 100%;
  height: 251px;
  font-size: 9px;
  padding: 10px;
}
#chartdiv3 {
  width: 100%;
  height: 360px;
  font-size: 9px;
  padding: 10px;
}
</style>
<div class="pad-t30">
	<div class="frm-row">
		<div>
			<div class="colm4 colm pull-right pad-15 wow fadeInDown" data-wow-duration="1s">
				<div class="body-form pad-15 relative">
					<div class="pad-b10">
						<div class="bg-chart1 icon-cat-panel absolute  flex-center">
							<i class="fa fa-rocket vertical font-s30 color-white"></i>
						</div>
						<div class="align-right">
							<a href="<?php echo home_url("/list-startup") ?>" class="color-darkgray font-w200 font-s15">استارتاپ ها</a>
							<h4 class="font-w300 font-s20 title-panel"><?php echo count($user_query_sub->get_results()) ?></h4>
						</div>
					</div>
					<div class="border-t-chart font-w200 font-s12 pad-t10">
						<span class="font-w300">
							<i class="fa fa-chart-bar pad-l5 verticall"></i>
						</span>
						<span>
							آمار استارتاپ ها
						</span>
					</div>
				</div>
			</div>
			<div class="colm4 colm pull-right pad-15 wow fadeInDown" data-wow-duration="1s">
				<div class="body-form pad-15 relative">
					<div class="pad-b10">
						<div class="bg-chart2 icon-cat-panel absolute flex-center">
							<i class="fa fa-users vertical font-s30 color-white"></i>
						</div>
						<div class="align-right">
							<a href="<?php echo home_url("/list-referee") ?>" class="color-darkgray font-w200 font-s15">منتور ها</a>
							<h4 class="font-w300 font-s20 title-panel"><?php echo count($user_query->get_results()) ?></h4>
						</div>
					</div>
					<div class="border-t-chart font-w200 font-s12 pad-t10">
						<span class="font-w300">
							<i class="fa fa-chart-bar pad-l5 vertical"></i>
						</span>
						<span>
							آمار منتور ها
						</span>
					</div>
				</div>
			</div>
			<div class="colm4 colm pull-right pad-15 wow fadeInDown" data-wow-duration="2s">
				<div class="body-form pad-15 relative">
					<div class="pad-b10">
						<div class="bg-chart3 icon-cat-panel absolute flex-center">
							<i class="fa fa-gem  vertical font-s30 color-white"></i>
						</div>
						<div class="align-right">
							<a href="<?php echo home_url("/list-investor") ?>" class="color-darkgray font-w200 font-s15">سفارش های سرمایه گذاری شده</a>
							<h4 class="font-w300 font-s20 title-panel"><?php echo count($user_query_investor->get_results())?></h4>
						</div>
					</div>
					<div class="border-t-chart font-w200 font-s12 pad-t10">
						<span class="font-w300">
							<i class="fa fa-chart-bar pad-l5 vertical"></i>
						</span>
						<span>
							آمار سفارش های سرمایه گذاری شده
						</span>
					</div>
				</div>
			</div>
			<div class="clearfix"></div>
		</div>
	</div>
	<div class="frm-row pad-t40 ">
		<div>
			<div class="colm12 colm pull-right pad-15 wow  zoomIn" data-wow-duration="2s">
				<div class="body-form relative">
					<div class="payam">
		     			<div class="body-form-top absolute flex-center">
							<i class="fa fa-donate vertical font-s30 color-white"></i>
						</div>
						<div class="absolute title-panel">
							<h3 class="font-w300 font-s18">مقدار سرمایه گذاری 10 استارت آپ برتر</h3>
						</div>
					</div>
					<div class="colm6 colm pull-right pad-30">
						<div class="pad-table overflow-scroll">
						<table class="table color6">
							<thead>
								<tr>
									<th class="center">نام استــارتاپ</th>
									<th class="center">سایت استارتاپ</th>
									<th class="center">تاریخ ثبت نام</th>
									<th class="center">عملیات</th>
								 </tr>
							</thead>
							<tbody>
								<?php 
							 $args=array(
			                    'number' => 8,
			                    'role__in' => array( 'subscriber' ),
			                    'orderby' => 'ID',
			                    'order' => 'DESC',
		                    );
							$user_query = new WP_User_Query($args); 
							$i=1;
							if ( ! empty( $user_query->get_results() ) ) {
								foreach ( $user_query->get_results() as $user ) {
								//	print_r($user);
								
								$user_id 	= $user->ID;
								$user_login	= $user->user_login;
								$role 		= $user->roles[0];
								$startup_name = get_user_meta($user_id,'startup_name',true);
								$firstname  = get_user_meta($user_id,'first_name',true);
		    					$lastname   = get_user_meta($user_id,'last_name',true);
		    					$mobile   	= get_user_meta($user_id,'mobile',true);
								$expertise	= get_user_meta($user_id,'expertise',true);
								$dabir_ok 	= get_user_meta($user_id,'dabir_ok',true);
								$start_date = get_user_meta($user_id,'start_date',true);
								$website = get_user_meta($user_id,'website',true);
								$team_number = get_user_meta($user_id,'team_number',true);
								
								if (!empty($website) &&  !preg_match("~^(?:f|ht)tps?://~i", $website)) {
									$website = "http://" . $website;
								}
								if($dabir_ok == "ok"){
									$class = "bg-success";
								}elseif($dabir_ok == "remove"){
									$class = "bg-danger";
								}elseif($dabir_ok == "edit"){
									$class = "bg-info";
								}else{
									$class ="bg-white";
								}
							?>
							 <tr class="<?php echo $class; ?>">
								<td class="center"><?php if($startup_name){echo $startup_name;}else{echo $user_login;} ?></td>
								<td class="center">
								<?= empty($website) ? '-------' : '<a class="color-blue" href="'.$website.'" target="_blank">'.$website.'</a>';  ?>
								</td>
								<td class="center"><?php echo jdate('Y/m/d' , $user->user_registered) ; ?></td>
								<td class="center">
									<a class="color-silver" title="نمایش" href="<?php echo home_url("/information/$user_id") ?>" 
										<span>
											<i class="align-center font-s20 fa fa-address-card"></i>
										</span>								
									</a>
								</td>
					  		</tr>
						  		<?php		
								}wp_reset_query();
							}
							?>
							</tbody>
						</table>
					</div>
					</div>
					<div class="colm6 colm pull-right">
						<div id="chartdiv1"></div>
					</div>
					<div class="clearfix"></div>
				</div>
			</div>
			<div class="clearfix"></div>
		</div>
	</div>
	<div class="frm-row pad-t40 ">
		<div>
			<div class="colm12 colm pull-right pad-15 wow  zoomIn" data-wow-duration="2s">
				<div class="body-form relative pad-b10">
					<div class="payam">
		     			<div class="bg-chart2 body-form-top absolute flex-center">
							<i class="fa fa-handshake vertical font-s30 color-white"></i>
						</div>
						<div class="absolute title-panel">
							<h3 class="font-w300 font-s18">همراهان استارت آپ ها</h3>
						</div>
					</div>
					<div id="chartdiv"></div>	
				</div>
			</div>
			<div class="clearfix"></div>
		</div>
	</div>
		<div class="frm-row pad-t40 ">
		<div>
			<div class="colm6 colm pull-right pad-15 wow zoomIn" data-wow-duration="1.5s">
				<div class="body-form relative pad-b10">
					<div class="payam">
		     			<div class="bg-chart4 body-form-top absolute flex-center">
							<i class="fa fa-money-check-alt	 vertical font-s30 color-white"></i>
						</div>
						<div class="absolute title-panel">
							<h3 class="font-w300 font-s18">سرمایه گذاری تا این لحظه</h3>
						</div>
					</div>
					<div id="chartdiv2"></div>
				</div>
			</div>
			<div class="colm6 colm pull-right pad-15 wow zoomIn" data-wow-duration="1.5s">
				<div class="body-form relative pad-b10">
					<div class="payam">
		     			<div class="bg-chart5 body-form-top absolute flex-center">
							<i class="fa fa-comment vertical font-s30 color-white"></i>
						</div>
						<div class="absolute title-panel">
							<h3 class="font-w300 font-s18">آخرین پیام ها</h3>
						</div>
					</div>
					<div class="pad-table overflow-scroll">
						<table class="table color6">
							<thead>
								<tr>
									<th class="center">عنوان پیام</th>
									<th class="center">نام فرستنده</th>
									<th class="center">ایمیل فرستنده</th>
									<th class="center">تاریخ</th>
									<th class="center">عملیات</th>
								 </tr>
							</thead>
							<tbody>
							<?php 
								$args = array();
								$query_data = query_data('message',$args); 
								if ( ! empty( $query_data ) ) {
								foreach ( $query_data as $data ) {
								$reciver = get_userdata( $data->receiver_id );
							?>
							 <tr class="<?php echo $class; ?>">
								<td class="center"><?php echo $data->message_title ;  ?></td>
								<td class="center"><?php echo $reciver->last_name .  ", " . $reciver->first_name ; ?></td>
								<td class="center"><?php echo $reciver->user_email; ?></td>
								<td class="center"><?php echo jdate('Y/m/d',$data->date);?></td>
								<td class="center">
									<a class="color-silver" title="نمایش" href="<?php   ?>" 
										<span>
											<i class="align-center font-s20 fa fa-address-card"></i>
										</span>								
									</a>
								</td>
					  		</tr>
						  	<?php }	}else{?>
						  		<th colspan="5" style="background: #f7f5ed;">
						  			<img height="174" src="<?php bloginfo('template_url');?>/assets/images/whitespace/notification.png" alt="whitespace" />
						  		</th>
						  	<?php } ;?>
							</tbody>
						</table>
					</div>
				</div>
			</div>
			<div class="clearfix"></div>
		</div>
	</div>
	<div class="frm-row pad-t40 ">
		<div>
			<div class="colm12 colm  pad-15 wow  zoomIn" data-wow-duration="2s">
				<div class="body-form relative pad-b10">
					<div class="payam">
		     			<div class="bg-green body-form-top absolute flex-center"> 
							<i class="fa fa-rocket vertical font-s30 color-white"></i>
						</div>
						<div class="absolute title-panel">
							<h3 class="font-w300 font-s18">استارت آپ های برتر</h3>
						</div>
					</div>
					<div id="chartdiv3"></div>	
				</div>
			</div>
			<div class="clearfix"></div>
		</div>
	</div>
	
</div>
<style>
	rect.highcharts-background{
		fill:transparent
	}
	g.highcharts-exporting-group {
    display: none;
}
text.highcharts-credits {
    display: none;
}
</style>

<script>
	new WOW().init();
</script>
<!-- Resources -->
<script src="https://www.amcharts.com/lib/4/core.js"></script>
<script src="https://www.amcharts.com/lib/4/charts.js"></script>
<script src="https://www.amcharts.com/lib/4/plugins/forceDirected.js"></script>
<script src="https://www.amcharts.com/lib/4/themes/animated.js"></script>

<!-- Chart code -->
<script>

am4core.useTheme(am4themes_animated);

// Create chart
var chart = am4core.create("chartdiv", am4plugins_forceDirected.ForceDirectedTree);

// Create series
var series = chart.series.push(new am4plugins_forceDirected.ForceDirectedSeries());

// Icons
var workstation = "M0 30l4-8h24l4 8zM4 2v18h24V2H4zm22 16H6V4h20v14z";
var server = "M6 0v30h2v2h4v-2h8v2h4v-2h2V0H6zm6 6H8V4h4v2z";
var printer = "M28 26h2V16h-4V2H6v14H2v10h2l-2 4h28l-2-4zM8 4h16v12H8V4zm0 20h16l2 4H6l2-4z";
var router = "M26 20v-8a5 5 0 1 0-2 0v8l-2 1-11-11a5 5 0 0 0-4-8 5 5 0 0 0-1 10v8a5 5 0 1 0 2 0v-8l2-1 11 11-1 3a5 5 0 1 0 6-5z";

// Set data
series.data = [{
  "name": "علی مظلومین",
  "path": server,
  "children": [{
    "name": "رویداد",
    "value": 1,
    "path": workstation
  }, {
    "name": "چیلیوری",
    "value": 1,
    "path": workstation
  }, {
    "name": "تپسی",
    "value": 1,
    "path": workstation
  }, {
    "name": "ابوالفضل نعمتی",
    "value": 1,
    "path": router,
    "link": ["n2"]
  }]
}, {
  "name": "محمد سلامی",
  "path": server,
  "children": [{ 
    "name": "ترب",
    "value": 1,
    "path": workstation
  }, {
    "name": "کجارو",
    "value": 1,
    "path": workstation
  }, {
    "name": "ریحون",
    "value": 1,
    "path": workstation
  }, {
    "name": "مهران رحیمی",
    "value": 1,
    "path": router,
    "link": ["n2"]
  }]
}, {
  "name": "احمد سعیدی",
  "path": server,
  "children": [{
    "name": "اسنپ فود",
    "value": 1,
    "path": workstation
  }, {
    "name": "گردشگری",
    "value": 1,
    "path": workstation
  }, {
    "name": "ترب",
    "value": 1,
    "path": workstation
  }, {
    "id": "n2",
    "name": "علی علیوند",
    "value": 1,
    "path": router
  }]
}];

// Set up data fields
series.dataFields.value = "value";
series.dataFields.name = "name";
series.dataFields.id = "id";
series.dataFields.children = "children";
series.dataFields.linkWith = "link";

// Add labels
series.nodes.template.label.text = "{name}";
series.nodes.template.label.valign = "bottom";
series.nodes.template.label.fill = am4core.color("#000");
series.nodes.template.label.dy = 10;
series.nodes.template.tooltipText = "{name}: [bold]{value}[/]";
series.fontSize = 10;
series.minRadius = 30;
series.maxRadius = 30;

// Configure circles
series.nodes.template.circle.fill = am4core.color("#fff");
series.nodes.template.circle.fill = am4core.color("#fff");

// Configure icons
var icon = series.nodes.template.createChild(am4core.Sprite);
icon.propertyFields.path = "path";
icon.horizontalCenter = "middle";
icon.verticalCenter = "middle";
icon.width = am4core.percent(100);
icon.height = am4core.percent(100);


series.centerStrength = 0.4;
</script>		
<script>
am4core.ready(function() {

// Themes begin
am4core.useTheme(am4themes_animated);
// Themes end

/**
 * Chart design inspired by Nicolas Rapp: https://nicolasrapp.com/studio/
 */

var chart = am4core.create("chartdiv1", am4charts.RadarChart);

chart.data = [
 
  {
    name: "اسنپ",
    value1: 69.8,
    value2: 22.6
  },
  {
    name: "تپسی",
    value1: 63.6,
    value2: 45.3
  },
  {
    name: "آپارات",
    value1: 59.7,
    value2: 12.8
  },
  {
    name: "علی بابا",
    value1: 54.3,
    value2: 19.6
  },
  {
    name: "خوگر",
    value1: 52.9,
    value2: 96.3
  },
  {
    name: "اسنپ فود",
    value1: 42.9,
    value2: 11.9
  },
  {
    name: "چیلیوری",
    value1: 40.9,
    value2: 16.8
  },
  {
    name: "آپ",
    value1: 39.2,
    value2: 9.9
  },

  {
    name: "مامان پز",
    value1: 32.1,
    value2: 35.6
  },
  {
    name: "کجارو",
    value1: 31.8,
    value2: 5.9
  },
  {
    name: "گردشگری",
    value1: 29.3,
    value2: 14.7
  },
  {
    name: "ترب",
    value1: 23.0,
    value2: 2.8
  },
  {
    name: "گوشی شاپ",
    value1: 21.5,
    value2: 12.1
  },
  {
    name: "دیجی کالا",
    value1: 19.7,
    value2: 10.8
  },
];


chart.padding(0, 0, 0, 0);
chart.radarContainer.dy = 50;
chart.innerRadius = am4core.percent(50);
chart.radius = am4core.percent(100);
chart.zoomOutButton.padding(20,20,20,20);
chart.zoomOutButton.margin(20,20,20,20);
chart.zoomOutButton.background.cornerRadius(40,40,40,40);
chart.zoomOutButton.valign = "bottom";

var categoryAxis = chart.xAxes.push(new am4charts.CategoryAxis());
categoryAxis.dataFields.category = "name";
categoryAxis.renderer.labels.template.location = 0.5;
categoryAxis.mouseEnabled = false;

var categoryAxisRenderer = categoryAxis.renderer;
categoryAxisRenderer.cellStartLocation = 0;
categoryAxisRenderer.tooltipLocation = 0.5;
categoryAxisRenderer.grid.template.disabled = true;
categoryAxisRenderer.ticks.template.disabled = true;

categoryAxisRenderer.axisFills.template.fill = am4core.color("#e8e8e8");
categoryAxisRenderer.axisFills.template.fillOpacity = 0.2;
categoryAxisRenderer.axisFills.template.location = -0.5;
categoryAxisRenderer.line.disabled = true;
categoryAxisRenderer.tooltip.disabled = true;
categoryAxis.renderer.labels.template.disabled = true;

categoryAxis.adapter.add("maxZoomFactor", function(maxZoomFactor, target) {
  return target.dataItems.length / 5;
})

var valueAxis = chart.yAxes.push(new am4charts.ValueAxis());

var valueAxisRenderer = valueAxis.renderer;

valueAxisRenderer.line.disabled = true;
valueAxisRenderer.grid.template.disabled = true;
valueAxisRenderer.ticks.template.disabled = true;
valueAxis.min = 0;
valueAxis.renderer.tooltip.disabled = true;

var series1 = chart.series.push(new am4charts.RadarSeries());
series1.name = "CASH HELD OUTSIDE THE U.S.";
series1.dataFields.categoryX = "name";
series1.dataFields.valueY = "value1";
series1.stacked = true;
series1.fillOpacity = 0.5;
series1.fill = chart.colors.getIndex(0);
series1.strokeOpacity = 0;
series1.dataItems.template.locations.categoryX = 0.5;
series1.sequencedInterpolation = true;
series1.sequencedInterpolationDelay = 50;

var series2 = chart.series.push(new am4charts.RadarSeries());
series2.name = "TOTAL CASH PILE";
series2.dataFields.categoryX = "name";
series2.dataFields.valueY = "value2";
series2.stacked = true;
series2.fillOpacity = 0.5;
series2.fill = chart.colors.getIndex(1);
series2.stacked = true;
series2.strokeOpacity = 0;
series2.dataItems.template.locations.categoryX = 0.5;
series2.sequencedInterpolation = true;
series2.sequencedInterpolationDelay = 50;
series2.tooltipText = "[bold]{categoryX}[/]\nTotal: ${valueY.total} \nOverseas: ${value1}";
series2.tooltip.pointerOrientation = "vertical";
series2.tooltip.label.fill = am4core.color("#ffffff");
series2.tooltip.label.fontSize = "0.8em";
series2.tooltip.autoTextColor = false;

chart.seriesContainer.zIndex = -1;



chart.padding(0, 0, 0, 0)



chart.cursor = new am4charts.RadarCursor();
chart.cursor.lineX.strokeOpacity = 1;
chart.cursor.lineY.strokeOpacity = 0;
chart.cursor.lineX.stroke = chart.colors.getIndex(1);
chart.cursor.innerRadius = am4core.percent(30);
chart.cursor.radius = am4core.percent(50);
chart.cursor.selection.fill = chart.colors.getIndex(1);

let bullet = series2.bullets.create();
bullet.fill = am4core.color("#000000");
bullet.strokeOpacity = 0;
bullet.locationX = 0.5;


let line = bullet.createChild(am4core.Line);
line.x2 = -100;
line.x1 = 0;
line.y1 = 0;
line.y1 = 0;
line.strokeOpacity = 1;

line.stroke = am4core.color("#000000");
line.strokeDasharray = "2,3";
line.strokeOpacity = 0.4;


let bulletValueLabel = bullet.createChild(am4core.Label);
bulletValueLabel.text = "{valueY.total.formatNumber('$#.0')}";
bulletValueLabel.verticalCenter = "middle";
bulletValueLabel.horizontalCenter = "right";
bulletValueLabel.dy = -3;

let label = bullet.createChild(am4core.Label);
label.text = "{categoryX}";
label.verticalCenter = "middle";
label.paddingLeft = 20;

valueAxis.calculateTotals = true;


chart.legend = new am4charts.Legend();
chart.legend.parent = chart.radarContainer;
chart.legend.width = 110;
chart.legend.horizontalCenter = "middle";
chart.legend.markers.template.width = 22;
chart.legend.markers.template.height = 18;
chart.legend.markers.template.dy = 2;
chart.legend.labels.template.fontSize = "0.7em";
chart.legend.dy = 20;
chart.legend.dx = -9;

chart.legend.itemContainers.template.cursorOverStyle = am4core.MouseCursorStyle.pointer;
let itemHoverState = chart.legend.itemContainers.template.states.create("hover");
itemHoverState.properties.dx = 5;

let title = chart.radarContainer.createChild(am4core.Label);
title.text = "COMPANIES WITH\nTHE MOST CASH\nHELD OVERSEAS"
title.fontSize = "1.2em";
title.verticalCenter = "bottom";
title.textAlign = "middle";
title.horizontalCenter = "middle";
title.fontWeigth = "800";

chart.maskBullets = false;

let circle = bullet.createChild(am4core.Circle);
circle.radius = 2;
let hoverState = circle.states.create("hover");

hoverState.properties.scale = 5;

bullet.events.on("positionchanged", function(event) {
    event.target.children.getIndex(0).invalidate();
    event.target.children.getIndex(1).invalidatePosition();
})


bullet.adapter.add("dx", function(dx, target) {
  let angle = categoryAxis.getAngle(target.dataItem, "categoryX", 0.5);
  return 20 * am4core.math.cos(angle);
})

bullet.adapter.add("dy", function(dy, target) {
  let angle = categoryAxis.getAngle(target.dataItem, "categoryX", 0.5);
  return 20 * am4core.math.sin(angle);
})

bullet.adapter.add("rotation", function(dy, target) {
  let angle = Math.min(chart.endAngle, Math.max(chart.startAngle, categoryAxis.getAngle(target.dataItem, "categoryX", 0.5)));
  return angle;
})


line.adapter.add("x2", function(x2, target) {
  let dataItem = target.dataItem;
  if (dataItem) {
    let position = valueAxis.valueToPosition(dataItem.values.valueY.value + dataItem.values.valueY.stack);
    return -(position * valueAxis.axisFullLength + 35);
  }
  return 0;
})


bulletValueLabel.adapter.add("dx", function(dx, target) {
  let dataItem = target.dataItem;

  if (dataItem) {
    let position = valueAxis.valueToPosition(dataItem.values.valueY.value + dataItem.values.valueY.stack);
    return -(position * valueAxis.axisFullLength + 40);
  }
  return 0;
})


chart.seriesContainer.zIndex = 10;
categoryAxis.zIndex = 11;
valueAxis.zIndex = 12;

chart.radarContainer.zIndex = 20;


let previousBullets = [];
series2.events.on("tooltipshownat", function(event) {
  let dataItem = event.dataItem;

  for (let i = 0; i < previousBullets.length; i++) {
    previousBullets[i].isHover = false;
  }

  previousBullets = [];

  let itemBullet = dataItem.bullets.getKey(bullet.uid);

  for (let i = 0; i < itemBullet.children.length; i++) {
    let sprite = itemBullet.children.getIndex(i);
    sprite.isHover = true;
    previousBullets.push(sprite);
  }
})

series2.tooltip.events.on("visibilitychanged", function() {
  if (!series2.tooltip.visible) {
    for (let i = 0; i < previousBullets.length; i++) {
      previousBullets[i].isHover = false;
    }
  }
})

chart.events.on("maxsizechanged", function() {
  if(chart.pixelInnerRadius < 200){
    title.disabled = true;
    chart.legend.verticalCenter = "middle";
    chart.legend.dy = 0;
  }
  else{
    title.disabled = false;
    chart.legend.verticalCenter = "top";
    chart.legend.dy = 20;
  }
})

}); // end am4core.ready()
</script>


<script>
am4core.ready(function() {

// Themes begin
am4core.useTheme(am4themes_animated);
// Themes end

// Create chart instance
var chart = am4core.create("chartdiv2", am4charts.XYChart);

// Add data
chart.data = generateChartData();

// Create axes
var dateAxis = chart.xAxes.push(new am4charts.DateAxis());
dateAxis.renderer.minGridDistance = 50;

var valueAxis = chart.yAxes.push(new am4charts.ValueAxis());

// Create series
var series = chart.series.push(new am4charts.LineSeries());
series.dataFields.valueY = "visits";
series.dataFields.dateX = "date";
series.strokeWidth = 2;
series.minBulletDistance = 10;
series.tooltipText = "{valueY}";
series.tooltip.pointerOrientation = "vertical";
series.tooltip.background.cornerRadius = 20;
series.tooltip.background.fillOpacity = 0.5;
series.tooltip.label.padding(12,12,12,12)




// Add cursor
chart.cursor = new am4charts.XYCursor();
chart.cursor.xAxis = dateAxis;
chart.cursor.snapToSeries = series;

function generateChartData() {
    var chartData = [];
    var firstDate = new Date();
    firstDate.setDate(firstDate.getDate() - 1000);
    var visits = 1200;
    for (var i = 0; i < 500; i++) {

        var newDate = new Date(firstDate);
        newDate.setDate(newDate.getDate() + i);
        
        visits += Math.round((Math.random()<0.5?1:-1)*Math.random()*10);

        chartData.push({
            date: newDate,
            visits: visits
        });
    }
    return chartData;
}

}); // end am4core.ready()
</script>



<script>
am4core.ready(function() {

// Themes begin
am4core.useTheme(am4themes_animated);
// Themes end

/**
 * Chart design taken from Samsung health app
 */

var chart = am4core.create("chartdiv3", am4charts.XYChart);
chart.hiddenState.properties.opacity = 0; // this creates initial fade-in

chart.paddingBottom = 30;

chart.data = [{
    "name": "کجارو",
    "steps": 45688,
    "href": "https://app.100startups.ir/assets/uploads/2019/08/download-1.jpg"
}, {
    "name": "اسنپ",
    "steps": 35781,
    "href": "https://app.100startups.ir/assets/uploads/2019/08/images-1.png"
}, {
    "name": "چیلیوری",
    "steps": 25464,
    "href": "https://app.100startups.ir/assets/uploads/2019/08/download.jpg"
}, {
    "name": "تپسی",
    "steps": 18788,
    "href": "https://app.100startups.ir/assets/uploads/2019/08/download.png"
}, {
    "name": "ریحون",
    "steps": 16465,
    "href": "https://app.100startups.ir/assets/uploads/2019/08/images.png"
}, {
    "name": "ترب",
    "steps": 14972,
    "href": "https://app.100startups.ir/assets/uploads/2019/08/photo_2018-07-20_14-52-56.jpg"
}];

var categoryAxis = chart.xAxes.push(new am4charts.CategoryAxis());
categoryAxis.dataFields.category = "name";
categoryAxis.renderer.grid.template.strokeOpacity = 0;
categoryAxis.renderer.minGridDistance = 10;
categoryAxis.renderer.labels.template.dy = 35;
categoryAxis.renderer.tooltip.dy = 35;

var valueAxis = chart.yAxes.push(new am4charts.ValueAxis());
valueAxis.renderer.inside = true;
valueAxis.renderer.labels.template.fillOpacity = 0.3;
valueAxis.renderer.grid.template.strokeOpacity = 0;
valueAxis.min = 0;
valueAxis.cursorTooltipEnabled = false;
valueAxis.renderer.baseGrid.strokeOpacity = 0;

var series = chart.series.push(new am4charts.ColumnSeries);
series.dataFields.valueY = "steps";
series.dataFields.categoryX = "name";
series.tooltipText = "{valueY.value}";
series.tooltip.pointerOrientation = "vertical";
series.tooltip.dy = - 6;
series.columnsContainer.zIndex = 100;

var columnTemplate = series.columns.template;
columnTemplate.width = am4core.percent(50);
columnTemplate.maxWidth = 66;
columnTemplate.column.cornerRadius(60, 60, 10, 10);
columnTemplate.strokeOpacity = 0;

series.heatRules.push({ target: columnTemplate, property: "fill", dataField: "valueY", min: am4core.color("#e5dc36"), max: am4core.color("#5faa46") });
series.mainContainer.mask = undefined;

var cursor = new am4charts.XYCursor();
chart.cursor = cursor;
cursor.lineX.disabled = true;
cursor.lineY.disabled = true;
cursor.behavior = "none";

var bullet = columnTemplate.createChild(am4charts.CircleBullet);
bullet.circle.radius = 30;
bullet.valign = "bottom";
bullet.align = "center";
bullet.isMeasured = true;
bullet.mouseEnabled = false;
bullet.verticalCenter = "bottom";
bullet.interactionsEnabled = false;

var hoverState = bullet.states.create("hover");
var outlineCircle = bullet.createChild(am4core.Circle);
outlineCircle.adapter.add("radius", function (radius, target) {
    var circleBullet = target.parent;
    return circleBullet.circle.pixelRadius + 10;
})

var image = bullet.createChild(am4core.Image);
image.width = 60;
image.height = 60;
image.horizontalCenter = "middle";
image.verticalCenter = "middle";
image.propertyFields.href = "href";

image.adapter.add("mask", function (mask, target) {
    var circleBullet = target.parent;
    return circleBullet.circle;
})

var previousBullet;
chart.cursor.events.on("cursorpositionchanged", function (event) {
    var dataItem = series.tooltipDataItem;

    if (dataItem.column) {
        var bullet = dataItem.column.children.getIndex(1);

        if (previousBullet && previousBullet != bullet) {
            previousBullet.isHover = false;
        }

        if (previousBullet != bullet) {

            var hs = bullet.states.getKey("hover");
            hs.properties.dy = -bullet.parent.pixelHeight + 30;
            bullet.isHover = true;

            previousBullet = bullet;
        }
    }
})

}); // end am4core.ready()
</script>
