<?php
$args=array(
    'number' => -1,
    'role__not_in' => array('editor', 'administrator','managers'),
	
);
$user_query_sub = new WP_User_Query($args); 


$args=array(
    'number' => -1,
    'meta_query' => array(
		array(
			'key'     => 'roles',
			'value'   => serialize(strval('referee')),
			'compare' => 'LIKE',
		)
	),
	
);
$user_query_referee = new WP_User_Query($args); 

$args=array(
    'number' => -1,
    'meta_query' => array(
		array(
			'key'     => 'roles',
			'value'   => serialize(strval('coach')),
			'compare' => 'LIKE',
		)
	),
	
);
$user_query_mentor = new WP_User_Query($args); 

?>

<style>
	.hide-tab{
		display: none;
	}
</style>
<div class="pad-t40">
	<div class="frm-row">
		<div>
			<div class="colm4 colm12-tab colm pull-right pad-15 pad-5-mob  spacer-b25-mob wow fadeInDown" data-wow-duration="1s">
				<div class="body-form pad-15 relative">
					<div class="pad-b10">
						<div class="bg-chart1 icon-cat-panel absolute  flex-center">
							<i class="fa fa-rocket vertical font-s30 color-white"></i>
						</div>
						<div class="align-right">
							<a href="<?php echo home_url("/list-startup") ?>" class="color-darkgray font-w200 font-s15">استارتاپ ها</a>
							<h4 class="font-w300 font-s20 title-panel"><?php echo count($user_query_sub->get_results()) ?></h4>
						</div>
					</div>
					<div class="border-t-chart font-w200 font-s12 pad-t10">
						<span class="font-w300">
							<i class="fa fa-chart-bar pad-l5 verticall"></i>
						</span>
						<span>
							آمار استــارتاپ ها
						</span>
					</div>
				</div>
			</div>
			<div class="colm4 colm12-tab colm pull-right pad-15  pad-5-mob  spacer-b25-mob wow fadeInDown" data-wow-duration="1s">
				<div class="body-form pad-15 relative">
					<div class="pad-b10">
						<div class="bg-chart2 icon-cat-panel absolute flex-center">
							<i class="fa fa-users vertical font-s30 color-white"></i>
						</div>
						<div class="align-right">
							<a href="<?php echo home_url("/list-referee") ?>" class="color-darkgray font-w200 font-s15">منتور ها</a>
							<h4 class="font-w300 font-s20 title-panel"><?php echo count($user_query_mentor->get_results()) ?></h4>
						</div>
					</div>
					<div class="border-t-chart font-w200 font-s12 pad-t10">
						<span class="font-w300">
							<i class="fa fa-chart-bar pad-l5 vertical"></i>
						</span>
						<span>
							آمار منتور ها
						</span>
					</div>
				</div>
			</div>
			<div class="colm4 colm12-tab colm pull-right pad-15 pad-5-mob  spacer-b25-mob wow fadeInDown" data-wow-duration="2s">
				<div class="body-form pad-15 relative">
					<div class="pad-b10">
						<div class="bg-chart3 icon-cat-panel absolute flex-center">
							<i class="fa fa-gem  vertical font-s30 color-white"></i>
						</div>
						<div class="align-right">
							<a href="<?php echo home_url("/list-investor") ?>" class="color-darkgray font-w200 font-s15">سرمایه گذاران</a>
							<h4 class="font-w300 font-s20 title-panel"><?php echo count($user_query_referee->get_results())?></h4>
						</div>
					</div>
					<div class="border-t-chart font-w200 font-s12 pad-t10">
						<span class="font-w300">
							<i class="fa fa-chart-bar pad-l5 vertical"></i>
						</span>
						<span>
							آمار داوران
						</span>
					</div>
				</div>
			</div>
			<div class="clearfix"></div>
		</div>
	</div>
	<div class="frm-row pad-t40 ">
		<div>
			<!--
			<div class="colm4 colm pull-right pad-15 wow slideInRight" data-wow-duration="1.5s">
				<div class=" body-form height320 pad-15 relative">
					<div class="magin-auto absolute content-ch  pad-20">
						<h3 class="font-w300 font-s18">ثبت نام هفتگی</h3>
						<h3 class="colm12 colm border-b-panel font-w200 font-s14">آمار ثبت نام هفتگی</h3>
						<div class="color-bottom-chart font-w200 font-s12 pad-t5">
							<span class="">
								<i class="fa fa-clock vertical"></i>
							</span>
							<span>
								ویرایش شده در دو روز پیش
							</span>
						</div>
					</div>
					<div class="bg-chart3 chart-panel magin-auto absolute pad-20">
						<div class="ct-chart" id="dailySalesChart"></div>
          			</div>
				</div>
			</div>
			<div class="colm4 colm pull-right pad-15 wow zoomIn" data-wow-duration="2s">
				<div class="body-form height320 pad-15 relative">
					<div class="magin-auto absolute content-ch pad-20">
						<h3 class="font-w300 font-s18 title-chart">ثبت نام ماهانه</h3>
						<h3 class="colm12 colm border-b-panel font-w200 font-s14">آمار ثبت نام سایت</h3>
						<div class="color-bottom-chart font-w200 font-s12 pad-t5">
							<span class="">
								<i class="fa fa-clock vertical"></i>
							</span>
							<span>
								ویرایش شده در دو روز پیش
							</span>
						</div>
					</div>
					<div class="bg-chart2 chart-panel magin-auto absolute pad-20">
						<div class="ct-chart" id="websiteViewsChart"></div>
					</div>
				</div>
			</div>
			-->
<!--			<div class="colm8 colm12-tab colm pull-right pad-15  pad-5-mob  spacer-b25-mob wow slideInRight" data-wow-duration="1.5s">-->
<!--				<div class="body-form relative pad-b10">-->
<!--					<div class="payam">-->
<!--		     			<div class="bg-chart5 body-form-top absolute flex-center">-->
<!--							<i class="fa fa-comment vertical font-s30 color-white"></i>-->
<!--						</div>-->
<!--						<div class="absolute title-panel">-->
<!--							<h3 class="font-w300 font-s18">زمان های رزرو شده</h3>-->
<!--						</div>-->
<!--					</div>-->
<!--					<div class="pad-table overflow-scroll">-->
<!--						<table class="table color6">-->
<!--							<thead>-->
<!--								<tr>-->
<!--									<th class="center">عنوان پیام</th>-->
<!--									<th class="center">نام فرستنده</th>-->
<!--									<th class="center">ایمیل فرستنده</th>-->
<!--									<th class="center">خلاصه پیام</th>-->
<!--								 </tr>-->
<!--							</thead>-->
<!--							<tbody>-->
<!--								--><?php //
//							 $args=array(
//			                    'number' => 2,
//			                    'role__not_in' => array( 'administrator','managers','secretariat','referee','operational' ),
//			                    'orderby' => 'ID',
//			                    'order' => 'DESC',
//		                    );
//							$user_query = new WP_User_Query($args);
//							$i=1;
//							if ( ! empty( $user_query->get_results() ) ) {
//								foreach ( $user_query->get_results() as $user ) {
//								//	print_r($user);
//								$user_id 	= $user->ID;
//								$user_login	= $user->user_login;
//								$role 		= $user->roles[0];
//								$startup_name = get_user_meta($user_id,'startup_name',true);
//								$firstname  = get_user_meta($user_id,'first_name',true);
//		    					$lastname   = get_user_meta($user_id,'last_name',true);
//		    					$mobile   	= get_user_meta($user_id,'mobile',true);
//								$expertise	= get_user_meta($user_id,'expertise',true);
//								$dabir_ok 	= get_user_meta($user_id,'dabir_ok',true);
//								if($dabir_ok == "ok"){
//									$class = "bg-success";
//								}elseif($dabir_ok == "remove"){
//									$class = "bg-danger";
//								}elseif($dabir_ok == "edit"){
//									$class = "bg-info";
//								}else{
//									$class ="bg-white";
//								}
//							?>
<!--							 <tr class="--><?php //echo $class; ?><!--">-->
<!--								<td class="center">--><?php //echo $startup_name; ?><!--</td>-->
<!--								<td class="center">--><?php //echo $firstname.' '.$lastname; ?><!--</td>-->
<!--								<td class="center">--><?php //echo jdate('Y/m/d',$user->user_registered);?><!--</td>-->
<!--								<td class="center">-->
<!--									<a class="color-silver" title="نمایش" href="--><?php //echo home_url("/information/$user_id") ?><!--" -->
<!--										<span>-->
<!--											<i class="align-center font-s20 fa fa-address-card"></i>-->
<!--										</span>								-->
<!--									</a>-->
<!--								</td>-->
<!--					  		</tr>-->
<!--					  		<tr class="--><?php //echo $class; ?><!--">-->
<!--								<td class="center">--><?php //echo $startup_name; ?><!--</td>-->
<!--								<td class="center">--><?php //echo $firstname.' '.$lastname; ?><!--</td>-->
<!--								<td class="center">--><?php //echo jdate('Y/m/d',$user->user_registered);?><!--</td>-->
<!--								<td class="center">-->
<!--									<a class="color-silver" title="نمایش" href="--><?php //echo home_url("/information/$user_id") ?><!--" -->
<!--										<span>-->
<!--											<i class="align-center font-s20 fa fa-address-card"></i>-->
<!--										</span>								-->
<!--									</a>-->
<!--								</td>-->
<!--					  		</tr>-->
<!--						  		--><?php	//
//								}wp_reset_query();
//							}
//							?>
<!--							</tbody>-->
<!--						</table>-->
<!--					</div>-->
<!--				</div>-->
<!--			</div>-->
<!--			<div class="colm4 colm12-tab colm pull-right pad-15  pad-5-mob  spacer-b25-mob wow slideInLeft" data-wow-duration="1.5s">-->
<!--				<div class=" body-form height320 pad-15 relative">-->
<!--					<div class="magin-auto absolute content-ch pad-20 ">-->
<!--						<h3 class="font-w300 font-s18">مدیریت سریع زمان ها</h3>-->
<!--						<h3 class="colm12 colm border-b-panel font-w200 font-s14">زمان ها </h3>-->
<!--						<div class="color-bottom-chart font-w200 font-s12 pad-t5">-->
<!--							<span class="">-->
<!--								<i class="fa fa-clock vertical"></i>-->
<!--							</span>-->
<!--							<span>-->
<!--								ویرایش شده در دو روز پیش-->
<!--							</span>-->
<!--						</div>-->
<!--					</div>-->
<!--					<div class="bg-chart1 chart-panel magin-auto absolute pad-20">-->
<!--						<div class="ct-chart" id="completedTasksChart"></div>-->
<!--					</div>-->
<!--				</div>-->
<!--			</div>-->
			<div class="clearfix"></div>
		</div>
	</div>
	<div class="frm-row pad-t40 pad-15  pad-5-mob spacer-b25-mob">
		<div class="body-form relative wow fadeInUpBig" data-wow-duration="1s">
			<div class="pad-b10">
     			<div class="bg-chart1 body-form-top absolute flex-center">
					<i class="fa fa-rocket vertical font-s30 color-white"></i>
				</div>
				<div class="absolute title-panel">
					<h3 class="font-w300 font-s18"> لیست استــارتاپ ها</h3>
				</div>
				<div class="frm-row  pad-t25-mob pad-t30-tab">
					<div class="colm4 colm pull-left pull-none relative pad-20">      
					     <input class="input-panel align-right" placeholder="جستجو کنید..." type="search" name="" value=""  >
					     <span class="bar"></span>
				    </div>
				</div>
			</div>
			<div class="frm-row pad-t40 pad-b10-mob pad-b10-tab pad-b20 overflow-scroll">	
				<div class="pad-table">
					<table class="table color6">
						<thead>
							<tr>
								<th class="center">نام استــارتاپ</th>
								<th class="center">رهبر گروه</th>
								<th class="center">تاریخ ثبت نام</th>
								<th class="center">عملیات</th>
							 </tr>
						</thead>
						<tbody>
							<?php 
						 $args=array(
		                    'number' => 10,
		                    'role__not_in' => array( 'administrator','managers','secretariat','referee','operational' ),
		                    'orderby' => 'ID',
		                    'order' => 'DESC',
	                    );
						$user_query = new WP_User_Query($args); 
						$i=1;
						if ( ! empty( $user_query->get_results() ) ) {
							foreach ( $user_query->get_results() as $user ) {
							//	print_r($user);
							$user_id 	= $user->ID;
							$user_login	= $user->user_login;
							$role 		= $user->roles[0];
							$startup_name = get_user_meta($user_id,'startup_name',true);
							$firstname  = get_user_meta($user_id,'first_name',true);
	    					$lastname   = get_user_meta($user_id,'last_name',true);
	    					$mobile   	= get_user_meta($user_id,'mobile',true);
							$expertise	= get_user_meta($user_id,'expertise',true);
							$dabir_ok 	= get_user_meta($user_id,'dabir_ok',true);
							if($dabir_ok == "ok"){
								$class = "bg-success";
							}elseif($dabir_ok == "remove"){
								$class = "bg-danger";
							}elseif($dabir_ok == "edit"){
								$class = "bg-info";
							}else{
								$class ="bg-white";
							}
						?>
						 <tr class="<?php echo $class; ?>">
							<td class="center"><?php echo $startup_name; ?></td>
							<td class="center"><?php echo $firstname.' '.$lastname; ?></td>
							<td class="center"><?php echo jdate('Y/m/d',$user->user_registered);?></td>
							<td class="center">
								<a class="color-silver" title="نمایش" href="<?php echo home_url("/information/$user_id") ?>" 
									<span>
										<i class="align-center font-s20 fa fa-address-card"></i>
									</span>								
								</a>
							</td>
				  		</tr>
					  		<?php		
							}wp_reset_query();
						}
						?>
						</tbody>
					</table>
				</div>
			</div>
			<div class="colm12 colm pull-right pad-t40 wow  pad-5-mob slideInRight" data-wow-duration="1.5s">
				<div class="body-form relative pad-b10">
					<div class="payam">
		     			<div class="bg-chart5 body-form-top absolute flex-center">
							<i class="fa fa-comment vertical font-s30 color-white"></i>
						</div>
						<div class="absolute title-panel">
							<h3 class="font-w300 font-s18">آخرین پیام ها</h3>
						</div>
					</div>
                    <div class="pad-table overflow-scroll">
                        <table class="table color6">
                            <thead>
                            <tr>
                                <th class="center">عنوان پیام</th>
                                <th class="center">نام فرستنده</th>
                                <th class="center">ایمیل فرستنده</th>
                                <th class="center">تاریخ</th>
                                <th class="center">عملیات</th>
                            </tr>
                            </thead>
                            <tbody>
                            <?php
                            $args = array();
                            $query_data = query_data('message',$args);
                            if ( ! empty( $query_data ) ) {
                                foreach ( $query_data as $data ) {
                                    $reciver = get_userdata( $data->receiver_id );
                                    ?>
                                    <tr class="<?php echo $class; ?>">
                                        <td class="center"><?php echo $data->message_title ;  ?></td>
                                        <td class="center"><?php echo $reciver->last_name .  ", " . $reciver->first_name ; ?></td>
                                        <td class="center"><?php echo $reciver->user_email; ?></td>
                                        <td class="center"><?php echo jdate('Y/m/d',$data->date);?></td>
                                        <td class="center">
                                            <a class="color-silver" title="نمایش" href="<?php   ?>"
                                            <span>
											<i class="align-center font-s20 fa fa-address-card"></i>
										</span>
                                            </a>
                                        </td>
                                    </tr>
                                <?php }	}else{?>
                                <th colspan="5" style="background: #f7f5ed;">
                                    <img height="174" src="<?php bloginfo('template_url');?>/assets/images/whitespace/notification.png" alt="whitespace" />
                                </th>
                            <?php } ;?>
                            </tbody>
                        </table>
                    </div>
				</div>
			</div>
		</div>
	</div>
</div>
<style>
	rect.highcharts-background{
		fill:transparent
	}
	g.highcharts-exporting-group {
    display: none;
}
text.highcharts-credits {
    display: none;
}
</style>


<script>
	new WOW().init();
</script>
