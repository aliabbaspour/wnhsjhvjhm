<?php

$args=array(   
    'number' => -1,
    'role__not_in' => array('editor', 'administrator','managers','investor','coach','secretariat','referee','operational'),
	
);
$user_query_sub = new WP_User_Query($args); 

$args=array(
    'number' => -1,
    'meta_query' => array(
		array(
			'key'     => 'roles',
			'value'   => serialize(strval('referee')),
			'compare' => 'LIKE',
		)
	),
	
);
$user_query_referee = new WP_User_Query($args); 

$args=array(
    'number' => -1,
    'meta_query' => array(
		array(
			'key'     => 'roles',
			'value'   => serialize(strval('coach')),
			'compare' => 'LIKE',
		)
	),
	
);
$user_query_mentor = new WP_User_Query($args); 

$args=array(
    'number' => -1,
    'meta_query' => array(
		array(
			'key'     => 'roles',
			'value'   => serialize(strval('investor')),
			'compare' => 'LIKE',
		)
	),
	
);
$user_query_investor = new WP_User_Query($args); 
?>

<style>
	.hide-tab{
		display: none;
	}
</style>
	<div class="colm12  pad-15 pad-0 wow fadeInDownBig visible-md hide" data-wow-duration="2.3s">
				<div class="body-form">
		     		<div class="flex">
			        	<div class="colm2 font-s10 colm pull-right taga ">
			        		<a href="#" class="cursor-step">
			        			<div class="tab1 flex-center sg-tab " data-id="1" disabled="">اختصاص داور</div>
			        		</a>
			        	</div>
			        	<div class="active-tab  colm2 font-s10 colm pull-right taga">
			        		<a href="#" class="cursor-step">
			        			<div class="tabfin flex-center sg-tab" data-id="2" disabled="">ارزیابی داوران</div>
			        		</a>	
			        	</div>
			        	<div class="colm2 font-s10 colm pull-right taga"> 
			        		<a href="#" class="cursor-step">
			        			<div class="tabfin flex-center sg-tab" data-id="3" disabled="">داوری حضوری</div>
			        		</a>	
			        	</div>
			        	<div class="colm2 font-s10 colm pull-right taga">
			        		<a href="#" class="cursor-step">
			        			<div class="tabfin flex-center sg-tab" data-id="4" disabled="">اختصاص راهبر</div>
			        		</a>	
			        	</div>
			        	<div class="colm2 font-s10 colm pull-right taga ">
			        		<a href="#" class="cursor-step">
			        			<div class="tabfin flex-center sg-tab" data-id="5" disabled="">پیش قرارداد</div>
			        		</a>	
			        	</div>
			        	<div class="colm2 font-s10 colm pull-right taga">   
			        		<a href="#" class="cursor-step">
			        			<div class="tabfin5 flex-center  sg-tab" data-id="6" disabled="">داوری غیرحضوری</div>
			        		</a>	
			        	</div>
			        	<div class="clearfix"></div>
		     		</div>

		     	</div>
			</div>
<div class="pad-t40">
	<div class="frm-row">
		<div>
			<div class="colm3 colm12-tab colm pull-right pad-15 pad-5-mob spacer-b25-mob wow fadeInDown" data-wow-duration="1s">
				<div class="body-form pad-15 relative">
					<div class="pad-b10">
						<div class="bg-chart1 icon-cat-panel absolute  flex-center">
							<i class="fa fa-rocket vertical font-s30 color-white"></i>
						</div>
						<div class="align-right">
							<a href="<?php echo home_url("/list-startup") ?>" class="color-darkgray font-w200 font-s15">استارتاپ ها</a>
							<h4 class="font-w300 font-s20 title-panel"><?php echo count($user_query_sub->get_results()) ?></h4>
						</div>
					</div>
					<div class="border-t-chart font-w200 font-s12 pad-t10">
						<span class="font-w300">
							<i class="fa fa-chart-bar pad-l5 verticall"></i>
						</span>
						<span>
							آمار استــارتاپ های سایت
						</span>
					</div>
				</div>
			</div>
			<div class="colm3 colm12-tab colm pull-right pad-15 wow pad-5-mob spacer-b25-mob fadeInDown" data-wow-duration="1s">
				<div class="body-form pad-15 relative">
					<div class="pad-b10">
						<div class="bg-chart2 icon-cat-panel absolute flex-center">
							<i class="fa fa-users vertical font-s30 color-white"></i>
						</div>
						<div class="align-right">
							<a href="<?php echo home_url("/list-referee") ?>" class="color-darkgray font-w200 font-s15">داوران</a>
							<h4 class="font-w300 font-s20 title-panel"><?php echo count($user_query_referee->get_results()) ?></h4>
						</div>
					</div>
					<div class="border-t-chart font-w200 font-s12 pad-t10">
						<span class="font-w300">
							<i class="fa fa-chart-bar pad-l5 vertical"></i>
						</span>
						<span>
							آمار داوران سایت
						</span>
					</div>
				</div>
			</div>
			<div class="colm3 colm12-tab colm pull-right pad-15 wow pad-5-mob spacer-b25-mob fadeInDown" data-wow-duration="2s">
				<div class="body-form pad-15 relative">
					<div class="pad-b10">
						<div class="bg-chart3 icon-cat-panel absolute flex-center">
							<i class="fa fa-gem  vertical font-s30 color-white"></i>
						</div>
						<div class="align-right">
							<a href="<?php echo home_url("/list-investor") ?>" class="color-darkgray font-w200 font-s15">سرمایه گذاران</a>
							<h4 class="font-w300 font-s20 title-panel"><?php echo count($user_query_investor->get_results())?></h4>
						</div>
					</div>
					<div class="border-t-chart font-w200 font-s12 pad-t10">
						<span class="font-w300">
							<i class="fa fa-chart-bar pad-l5 vertical"></i>
						</span>
						<span>
							آمار سرمایه گذاران سایت
						</span> 
					</div>
				</div>
			</div>
			<div class="colm3 colm12-tab colm pull-right pad-15 wow pad-5-mob spacer-b25-mob fadeInDown" data-wow-duration="2.5s">
				<div class="body-form pad-15 relative">
					<div class="pad-b10">
						<div class="bg-chart4 icon-cat-panel absolute  flex-center">
							<i class="fa fa-chalkboard-teacher vertical font-s30 color-white"></i>
						</div>
						<div class="align-right">
							<a href="<?php echo home_url("/list-coach") ?>" class="color-darkgray font-w200 font-s15">مربیان</a>
							<h4 class="font-w300 font-s20 title-panel"><?php echo count($user_query_mentor->get_results()); ?></h4>
						</div>
					</div>
					<div class="border-t-chart font-w200 font-s12 pad-t10">
						<span class="font-w300">
							<i class="fa fa-chart-bar pad-l5 vertical"></i>
						</span>
						<span>
							آمار مربیان سایت
						</span>
					</div>
				</div>
			</div>
			<div class="clearfix"></div>
		</div>
	</div>
	<div class="frm-row pad-t40 ">
		<div>
			<!--
			<div class="colm4 colm pull-right pad-15 wow slideInRight" data-wow-duration="1.5s">
				<div class=" body-form height320 pad-15 relative">
					<div class="magin-auto absolute content-ch  pad-20">
						<h3 class="font-w300 font-s18">ثبت نام هفتگی</h3>
						<h3 class="colm12 colm border-b-panel font-w200 font-s14">آمار ثبت نام هفتگی</h3>
						<div class="color-bottom-chart font-w200 font-s12 pad-t5">
							<span class="">
								<i class="fa fa-clock vertical"></i>
							</span>
							<span>
								ویرایش شده در دو روز پیش
							</span>
						</div>
					</div>
					<div class="bg-chart3 chart-panel magin-auto absolute pad-20">
						<div class="ct-chart" id="dailySalesChart"></div>
          			</div>
				</div>
			</div>
			<div class="colm4 colm pull-right pad-15 wow zoomIn" data-wow-duration="2s">
				<div class="body-form height320 pad-15 relative">
					<div class="magin-auto absolute content-ch pad-20">
						<h3 class="font-w300 font-s18 title-chart">ثبت نام ماهانه</h3>
						<h3 class="colm12 colm border-b-panel font-w200 font-s14">آمار ثبت نام سایت</h3>
						<div class="color-bottom-chart font-w200 font-s12 pad-t5">
							<span class="">
								<i class="fa fa-clock vertical"></i>
							</span>
							<span>
								ویرایش شده در دو روز پیش
							</span>
						</div>
					</div>
					<div class="bg-chart2 chart-panel magin-auto absolute pad-20">
						<div class="ct-chart" id="websiteViewsChart"></div>
					</div>
				</div>
			</div>
			-->

		</div>
	</div>
	<div class="frm-row pad-t40 pad-15 pad-5-mob spacer-t25-mob">
		<div class="body-form relative wow fadeInUpBig" data-wow-duration="1s">
			<div class="pad-b10">
     			<div class="bg-chart2 body-form-top absolute flex-center">
					<i class="fa fa-file-invoice-dollar vertical font-s30 color-white"></i>
				</div>
				<div class="absolute title-panel">
					<h3 class="font-w300 font-s18">10 درخواست آخر</h3>
				</div>
				<div class="frm-row pad-t25-mob pad-t30-tab">
					<div class="colm4 colm12-tab colm pull-left pull-none relative pad-20">      
					     <input class="input-panel align-right" placeholder="جستجو کنید..." type="search" name="" value=""  >
					     <span class="bar"></span>
				    </div>
				</div>
			</div>
			<div class="frm-row pad-t40 pad-b10-mob pad-b10-tab pad-b20 overflow-scroll">
				<div class="pad-table">
                <table class="table color6">
                    <thead>
                    <tr>
						<th class="center">نام تیم</th>
                        <th class="center">عنوان</th>
                        <th class="center">مبلغ</th>
                        <th class="center">تاریخ درخواست</th>
                        <th class="center">وضعیت</th>
                        <th class="center">عملیات</th>
                    </tr>
                    </thead>
                    <tbody>
                    <?php
                    $args = array(
                        'post_type'=>'requestmoney',
                        'post_status' => "publish",
                        'meta_query'    => array(
                                array(
                                        "key"   => "status",
                                        "value"   => "confirm_mentor",
                                )
                        )

                    );
                        query_posts( $args );
                        while ( have_posts() ) : the_post();


                            $request_id         = $post->ID;
                            $request_title      = get_post_meta($request_id,'request_title',true);
                            $request_expression = get_post_meta($request_id,'request_expression',true);
                            $request_money      = get_post_meta($request_id,'request_money',true);
							$startup_name 		= get_user_meta($post->post_author,'startup_name',true);
                            ?>
                            <tr class="">
								<td class="center"><?php echo $startup_name; ?></td>
                                <td class="center"><?php the_title(); ?></td>
                                <td class="center"><?php echo $request_money; ?></td>
                                <td class="center"><?php echo jdate('Y/m/d',$post->post_created); ?></td>
                                <td class="center">درحال انتظار</td>
                                <td class="center">
                                    <span class="color-silver btn pointer" data-modal="<?php echo $request_id ?>">
                                        <span>
                                            <i class="align-center font-s20 fa fa-address-card"></i>
                                        </span>
                                    </span>
                                </td>
                            </tr>

                            <?php
                            endwhile;
                           wp_reset_query();
                            ?>
                    </tbody>
                </table>
				</div>
			</div>
		</div>
	</div>
</div>
<style>
	rect.highcharts-background{
		fill:transparent
	}
	g.highcharts-exporting-group {
    display: none;
}
text.highcharts-credits {
    display: none;
}
.activee {
     background: #eeeeee;
     color: #222;
}
.cursor-step{
	cursor: context-menu;
}
</style>


<script>
	new WOW().init();
</script>
