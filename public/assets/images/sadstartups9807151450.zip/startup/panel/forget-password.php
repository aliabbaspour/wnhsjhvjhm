<?php //Template Name: forget password ?>
<?php if(!is_user_logged_in()){ ?>
<?php get_header() ?>
<div id="login-panel" class="container-fluide  min-100vh">
	<div class="flex-center min-h100">
		<div class="colm4-login colm10-mob colm6-tab colm">
			 <div class="pad-b20">
			</div>
			<div class="spacer-t25">
				<form action="" method="post" class="smart-validate">
                    <div class=""> 
						<div class="body-form relative">
							<div class=" body-form-top margin-auto absolute pad-b30">
								<div class="img-login margin-auto">
										<img src="<?php bloginfo('template_url') ?>/assets/images/logo-panel.svg" />
								</div>
							</div>
							<div class="pad-t100">
						    	<div class="colm10 colm margin-auto font-s14">      
								     <input class="input-panel" type="password" name="username" required>
								     <span class="bar"></span>
								     <label class="label">رمز عبور</label>
							    </div>
						    	<div class="colm10 colm margin-auto font-s14">      
								     <input class="input-panel" type="password" name="repeat_password" required>
								     <span class="bar"></span>
								     <label class="label">تکرار رمز عبور</label>
							    </div>
							</div>
							<div class="margin-auto align-center pad-b25">
								<button type="submit" name="submit" class="btn-panel pad-10 color-white iransans">تغیر رمز عبور</button>
							</div>
						</div>	
                    </div>
				</form>
			</div>
			<div class="pad-t10">
				<a href="#" class="title color-white">
					<i class="fa fa-home vertical pad-r5"></i>
					<span>ورود به پنل</span>
				</a>
			</div>
		</div>
	</div>
	<div class="clearfix"></div>
</div>
<style>
	header , footer{
		display: none;
	}
</style>
<?php get_footer() ?>
<?php }else{
	wp_redirect(home_url('/dashboard')) ;
}?>