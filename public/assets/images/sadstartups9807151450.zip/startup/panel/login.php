<?php //Template Name: login-panel ?>
<?php if(!is_user_logged_in()){ ?>
<?php 
$message = "";
if(isset($_POST['submit'])){
	$user_login = $_POST['username'];
	$password 	= $_POST['password'];
	$userdata = array(
		'user_login' 	=> $user_login,
		'user_password' => $password,
	);
	$user = wp_signon( $userdata, false );  
	if (!is_wp_error($user)) {
		wp_set_current_user($user -> ID);
		wp_set_auth_cookie($user -> ID);
		wp_redirect(home_url('/dashboard'));
	}else{
		wp_redirect(home_url('/login/?message=error'));
	}
}
?>
<?php get_header() ?>
<style>
	.hide-mob{
		display: none;
	}
</style>
<div id="login-panel" class="container-fluide  min-100vh">
	<div class="flex-center min-h100">
		<div class="colm4-login colm10-mob colm6-tab colm">
			<div class="pad-b20"></div>
			<div class="spacer-t25">
				<form action="" method="post" class="smart-validate">
					<div class="body-form relative">
						<div class=" body-form-top margin-auto absolute pad-b30">
							<div class="img-login margin-auto">
								<img src="<?php bloginfo('template_url') ?>/assets/images/logo-panel.svg" />
							</div>
						</div>
						<div class="pad-t100">
						    <div class="colm10 margin-auto spacer-t25-mob font-s14 spacer-t20-tab">  
							  <div class="mat-div spacer-b25">
							    <label for="username" class="mat-label">نام کاربری</label>
							    <input type="text" class="mat-input" name="username" id="username" required>
							  </div>
						  	</div>
						    <div class="colm10 margin-auto spacer-t10 spacer-t25-mob font-s14 spacer-t20-tab">  
							  <div class="mat-div spacer-b20">
							    <label for="password" class="mat-label">رمز عبور</label>
							    <input type="password" class="mat-input" name="password" id="password" required>
							  </div>
						  	</div>
						  	<?php if($_GET['message'] == 'error'):?>
						  		<div class="font-s15 color-red align-center"> نام کاربری یا کلمه عبور اشتباه می باشد </div>
						  	<?php endif ?>
							<div class="margin-auto align-center pad-b25 pad-t25">
								<button type="submit" name="submit" class="btn-panel pad-10 color-white iransans  colm disabled">ورود</button>
							</div>
						</div>	
                    </div>
				</form>
			</div>
			<div class="pad-t10">
				<a href="#" class="title color-white">
					<i class="fa fa-lock vertical pad-r5"></i>
					<span>فراموشی رمز عبور</span>
				</a>
			</div>
			<?php if($_GET['message']=='alert') {?>
				<div class="alert-sucsess bg-white flex-center color-black font-w400 font-s14 border-ra5 a pad-20 chenge-pass le">
					<h2 class="flex-center-row"><i class="fa fa-check pad-l5"></i>رمز عبور شما با موفقیت تغیر کرد</h2>
				</div>
			<?php }?>
		</div>
	</div>
	<div class="clearfix"></div>
</div>
<style>
	header , footer{
		display: none;
	}
.chenge-pass{
    position: fixed;
    left: 2%;
    border: 1px solid #2222222e;
    bottom: 5%;
    box-shadow: 7px 10px 0px 2px #ffffff;
}

.mat-label {
  display: block;
  font-size: 13px;
  transform: translateY(25px);
  color: #bdb9b9;
  transition: all 0.5s;
}

.mat-input {
  position: relative;
  background: transparent;
  width: 100%;
  border: none;
  outline: none;
  padding: 10px 10px;
  font-size: 13px;
}

.mat-div {
  position: relative;
}

.mat-div:after, .mat-div:before {
  content: "";
  position: absolute;
  display: block;
  width: 100%;
  height: 2px;
  background-color: #e2e2e2; 
  bottom: 0;
  left: 0;
  transition: all 0.5s;
}

.mat-div::after {
  background-color: #25aae1;
  transform: scaleX(0);
}

.is-active::after {
  transform: scaleX(1);
}

.is-active .mat-label {
  color: #8E8DBE;
}

.is-completed .mat-label {
  font-size: 13px;
  transform: translateY(0);
}
</style>
<?php get_footer() ?>
<?php }else{
	wp_redirect(home_url('/dashboard')) ;
}?>
<script>
jQuery(document).ready(function($){
	window.setTimeout(function() {
	    $(".alert-sucsess").fadeTo(500, 0).slideUp(500, function(){
	        $(this).remove(); 
	    });
	}, 4000);
	var uri = window.location.toString();
	if (uri.indexOf("?") > 0) {
	    var clean_uri = uri.substring(0, uri.indexOf("?"));
	    window.history.replaceState({}, document.title, clean_uri);
	}
		
	$(".mat-input").focus(function(){
	  $(this).parent().addClass("is-active is-completed");
	});
	
	$(".mat-input").focusout(function(){
	  if($(this).val() === "")
	    $(this).parent().removeClass("is-completed");
	  $(this).parent().removeClass("is-active");
	})
	
});
</script>