<?php //Template Name: Dashboard ?>
<?php
$user = wp_get_current_user();
$user_id = $user->ID;
$current_user_role =$user->roles[0];
$roles = get_user_meta($user_id,'roles',true);
?>
<?php if(is_user_logged_in()){?>								
<?php get_header();?>
<?php get_header('admin');?>
<?php if (in_array('operational' , $roles)) {?>
	<?php get_template_part('panel/dashboard/dashboard','admin');?>
<?php }?>
<?php if (in_array('coach' , $roles)) {?>
	<?php get_template_part('panel/dashboard/dashboard','coach');?>
<?php }?>
<?php if (in_array('leader' , $roles)) {?>
    <?php get_template_part('panel/dashboard/dashboard','coach');?>
<?php }?>
<?php if (in_array('investor' , $roles)) {?>
	<?php get_template_part('panel/dashboard/dashboard','investor');?>
<?php }?>
<?php if (in_array('financial' , $roles)) {?>
	<?php get_template_part('panel/dashboard/dashboard','financial');?>
<?php }?>
<?php if (in_array('referee' , $roles)) {?>
	<?php get_template_part('panel/dashboard/dashboard','referee');?>
<?php }?>
<?php if($current_user_role == 'subscriber'){?> 
	<?php  get_template_part('panel/dashboard/dashboard','startup');?>
<?php } ?>  
<?php if($current_user_role == 'administrator'){?> 
	<?php  get_template_part('panel/dashboard/dashboard','admin');?>
<?php } ?>  
<?php if($current_user_role == 'editor'){?> 
	<?php  get_template_part('panel/dashboard/dashboard','admin');?>
<?php } ?>  
<?php }else{ ?>
	 <?php wp_redirect('/login');?>
<?php }?>
<style>
header , footer{
	display:none;
}
</style>
<?php get_footer('admin') ?>
<?php get_footer() ?>
<script type="text/javascript">
		let breakCards = !0
  , searchVisible = 0
  , transparent = !0
  , transparentDemo = !0
  , fixedTop = !1
  , mobile_menu_visible = 0
  , mobile_menu_initialized = !1
  , toggle_initialized = !1
  , bootstrap_nav_initialized = !1
  , seq = 0
  , delays = 80
  , durations = 500
  , seq2 = 0
  , delays2 = 80
  , durations2 = 500;

		function startAnimationForLineChart(e) {
        e.on("draw", function(e) {
            "line" === e.type || "area" === e.type ? e.element.animate({
                d: {
                    begin: 600,
                    dur: 700,
                    from: e.path.clone().scale(1, 0).translate(0, e.chartRect.height()).stringify(),
                    to: e.path.clone().stringify(),
                    easing: Chartist.Svg.Easing.easeOutQuint
                }
            }) : "point" === e.type && (seq++,
            e.element.animate({
                opacity: {
                    begin: seq * delays,
                    dur: durations,
                    from: 0,
                    to: 1,
                    easing: "ease"
                }
            }))
        }),
        seq = 0
    }

    function startAnimationForBarChart(e) {
        e.on("draw", function(e) {
            "bar" === e.type && (seq2++,
            e.element.animate({
                opacity: {
                    begin: seq2 * delays2,
                    dur: durations2,
                    from: 0,
                    to: 1,
                    easing: "ease"
                }
            }))
        }),
        seq2 = 0
    }

		function initDashboardPageCharts() {
        if (0 != jQuery("#dailySalesChart").length || 0 != jQuery("#completedTasksChart").length || 0 != jQuery("#websiteViewsChart").length) {
            dataDailySalesChart = {
                labels: ["M", "T", "W", "T", "F", "S", "S"],
                series: [[12, 17, 7, 17, 23, 18, 38]]
            },
            optionsDailySalesChart = {
                lineSmooth: Chartist.Interpolation.cardinal({
                    tension: 0
                }),
                low: 0,
                high: 50,
                chartPadding: {
                    top: 0,
                    right: 0,
                    bottom: 0,
                    left: 0
                }
            };
            var e = new Chartist.Line("#dailySalesChart",dataDailySalesChart,optionsDailySalesChart);
            startAnimationForLineChart(e),
            dataCompletedTasksChart = {
                labels: ["12p", "3p", "6p", "9p", "12p", "3a", "6a", "9a"],
                series: [[230, 750, 450, 300, 280, 240, 200, 190]]
            },
            optionsCompletedTasksChart = {
                lineSmooth: Chartist.Interpolation.cardinal({
                    tension: 0
                }),
                low: 0,
                high: 1e3,
                chartPadding: {
                    top: 0,
                    right: 0,
                    bottom: 0,
                    left: 0
                }
            };
            var a = new Chartist.Line("#completedTasksChart",dataCompletedTasksChart,optionsCompletedTasksChart);
            startAnimationForLineChart(a);
            var t = Chartist.Bar("#websiteViewsChart", {
                labels: ["J", "F", "M", "A", "M", "J", "J", "A", "S", "O", "N", "D"],
                series: [[542, 443, 320, 780, 553, 453, 326, 434, 568, 610, 756, 895]]
            }, {
                axisX: {
                    showGrid: !1
                },
                low: 0,
                high: 1e3,
                chartPadding: {
                    top: 0,
                    right: 5,
                    bottom: 0,
                    left: 0
                }
            }, [["screen and (max-width: 640px)", {
                seriesBarDistance: 5,
                axisX: {
                    labelInterpolationFnc: function(e) {
                        return e[0]
                    }
                }
            }]]);
            startAnimationForBarChart(t)
        }
    }
		initDashboardPageCharts();
</script>