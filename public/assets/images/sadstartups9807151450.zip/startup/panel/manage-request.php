<?php /* template name: manage-request */ ?>
<?php

$current_user = wp_get_current_user();
$current_user_id = $current_user->ID;
$allowed_roles = array('editor', 'administrator','coach','financial','leader');
$roles =get_user_meta($current_user_id,'roles',true);
if(is_user_logged_in() && (array_intersect($allowed_roles, $current_user->roles )) || array_intersect($allowed_roles,$roles) ){



    function count_requests($query = NULL){
        $args = array(

            'post_type' =>  'requestmoney',
            'showposts' =>  '-1',
            'meta_query'    =>  array(
                'relation '  => 'OR',
                $query

            )
        );

        return count(get_posts($args));
    }
    $query_pending = array(
        'key' =>  'status',
        'value' =>  'pending',
    ) ;

    $count_pending = count_requests($query_pending);

    $query_confirm_leader = array(
        'key' =>  'status',
        'value' =>  'confirm_leader',
    ) ;

    $count_confirm_leader = count_requests($query_confirm_leader);

    $query_failed_leader = array(
        'key' =>  'status',
        'value' =>  'failed_leader',
    ) ;

    $count_failed_leader = count_requests($query_failed_leader);

    $query_confirm_financial = array(
        'key' =>  'status',
        'value' =>  'confirm_financial',
    ) ;

    $count_confirm_financial = count_requests($query_confirm_financial);

    $query_failed_financial = array(
        'key' =>  'status',
        'value' =>  'failed_financial',
    ) ;

    $count_failed_financial = count_requests($query_failed_financial);

    $query_confirm_documents = array(
        'key' =>  'status',
        'value' =>  'confirm_documents',
    ) ;

    $count_confirm_documents = count_requests($query_confirm_documents);

    $query_failed_documents = array(
        'key' =>  'status',
        'value' =>  'failed_documents',
    ) ;

    $count_failed_documents = count_requests($query_failed_documents);

    $query_accept = array(
        'key' =>  'status',
        'value' =>  'confirm_financial',
    ) ;

    $count_accept = count_requests($query_accept);

    $query_failed = array(
        'key' =>  'status',
        'value' =>  'failed_financial',
    ) ;

    $title_table = 'همه درخواست ها ';

    if ($_GET['status']=='confirm_leader'){
        $title_table = 'درخواست های تایید شده راهبر';
    }

    if ($_GET['status']=='failed_leader'){
        $title_table = ' درخواست های رد شده راهبر';
    }

    if ($_GET['status']=='confirm_financial'){
        $title_table = 'درخواست های تایید شده مالی';
    }

    if ($_GET['status']=='failed_financial'){
        $title_table = ' درخواست های رد شده مالی';
    }

    if ($_GET['status']=='confirm_documents'){
        $title_table = 'درخواست های تایید شده اسناد';
    }

    if ($_GET['status']=='failed_documents'){
        $title_table = ' درخواست های رد شده اسناد';
    }

    if ($_GET['status']=='pending'){
        $title_table = ' درخواست های درحال انتظار';
    }

    $count_failed = count_requests($query_failed);
    $count_all =  count_requests();

    if(isset($_POST['status_manage'])){

        $request_id = $_POST['data_post'];
        update_post_meta($request_id,'financial_comment',$_POST['financial_comment']);
        if($_POST['status_manage'] == 'accept'){
            update_post_meta($request_id,'status',"confirm_financial");

        }elseif($_POST['status_manage'] == 'failed'){
            update_post_meta($request_id,'status',"failed_financial");
        }
        wp_redirect(home_url("/manage-request"));
    }

    if(isset($_POST['status_leader'])){

        $request_id = $_POST['data_post'];
        update_post_meta($request_id,'leader_comment',$_POST['leader_comment']);

        if($_POST['status_leader'] == 'accept'){
            update_post_meta($request_id,'status',"confirm_leader");

        }elseif($_POST['status_leader'] == 'failed'){

            update_post_meta($request_id,'status',"failed_leader");
        }

        wp_redirect(home_url("/manage-request"));
    }
    $status			      = get_post_meta($request_id,'status',true);
    $financial_comment	  = get_post_meta($request_id,'financial_comment',true);
    $leader_comment	      = get_post_meta($request_id,'leader_comment',true);
    ?>
    <?php get_header() ?>
    <?php get_header('admin') ?>
    <div class="frm-row">
        <div>
            <div class="colm3 colm12-tab colm pull-right pad-15 wow pad-5-mob spacer-b25-mob fadeInDown" data-wow-duration="2.5s">
                <div class="body-form pad-15 relative">
                    <div class="pad-b10">
                        <div class="bg-chart3 icon-cat-panel absolute  flex-center">
                            <i class="fa fa-poll-h vertical font-s30 color-white"></i>
                        </div>
                        <div class="align-right">
                            <a href="<?php echo home_url('/manage-request/'); ?>" class="color-darkgray font-w200 font-s15">همه درخواست ها</a>
                            <h4 class="font-w300 font-s20 title-panel"><?php echo $count_all; ?></h4>
                        </div>
                    </div>
                    <div class="border-t-chart font-w200 font-s12 pad-t10">
						<span class="font-w300">
							<i class="fa fa-chart-bar pad-l5 vertical"></i>
						</span>
                        <span>
							آمار همه درخواست ها
                    </span>
                    </div>
                </div>
            </div>
            <div class="colm3 colm12-tab colm pull-right pad-15 wow pad-5-mob spacer-b25-mob fadeInDown" data-wow-duration="2s">
                <div class="body-form pad-15 relative">
                    <div class="pad-b10">
                        <div class="bg-chart4 icon-cat-panel absolute flex-center">
                            <i class="fa fa-hourglass-half  vertical font-s30 color-white"></i>
                        </div>
                        <div class="align-right">
                            <a href="<?php echo home_url('/manage-request/?status=pending'); ?>" class="color-darkgray font-w200 font-s15">در حال انتظار</a>
                            <h4 class="font-w300 font-s20 title-panel"><?php echo $count_pending ?></h4>
                        </div>
                    </div>
                    <div class="border-t-chart font-w200 font-s12 pad-t10">
						<span class="font-w300">
							<i class="fa fa-chart-bar pad-l5 vertical"></i>
						</span>
                        <span>
							آمار درخواست های در حال انتظار
						</span>
                    </div>
                </div>
            </div>

            <div class="colm3 colm12-tab colm pull-right pad-15 pad-5-mob spacer-b25-mob wow fadeInDown" data-wow-duration="1s">
                <div class="body-form pad-15 relative">
                    <div class="pad-b10">
                        <div class="bg-chart2 icon-cat-panel absolute  flex-center">
                            <i class="fa fa-user-check vertical font-s30 color-white"></i>
                        </div>
                        <div class="align-right">
                            <a href="<?php echo home_url('/manage-request/?status=confirm_leader'); ?>" class="color-darkgray font-w200 font-s15">تایید شده راهبر</a>
                            <h4 class="font-w300 font-s20 title-panel"><?php echo $count_confirm_leader; ?></h4>
                        </div>
                    </div>
                    <div class="border-t-chart font-w200 font-s12 pad-t10">
						<span class="font-w300">
							<i class="fa fa-chart-bar pad-l5 verticall"></i>
						</span>
                        <span>
							آمار درخواست های تایید شده راهبر
                    </span>
                    </div>
                </div>
            </div>

            <div class="colm3 colm12-tab colm pull-right pad-15 wow pad-5-mob spacer-b25-mob fadeInDown" data-wow-duration="1s">
                <div class="body-form pad-15 relative">
                    <div class="pad-b10">
                        <div class="bg-chart1 icon-cat-panel absolute flex-center">
                            <i class="fa fa-user-times vertical font-s30 color-white"></i>
                        </div>
                        <div class="align-right">
                            <a href="<?php echo home_url('/manage-request/?status=failed_leader'); ?>" class="color-darkgray font-w200 font-s15">تایید نشده راهبر</a>
                            <h4 class="font-w300 font-s20 title-panel"><?php echo $count_failed_leader; ?></h4>
                        </div>
                    </div>
                    <div class="border-t-chart font-w200 font-s12 pad-t10">
						<span class="font-w300">
							<i class="fa fa-chart-bar pad-l5 vertical"></i>
						</span>
                        <span>
							آمار درخواست های تایید نشده راهبر
						</span>
                    </div>
                </div>
            </div>

            <div class="colm3 colm12-tab colm pull-right pad-15 wow pad-5-mob spacer-b25-mob fadeInDown" data-wow-duration="1s">
                <div class="body-form pad-15 relative">
                    <div class="pad-b10">
                        <div class="bg-chart2 icon-cat-panel absolute flex-center">
                            <i class="fa fa-money-bill-alt vertical font-s30 color-white"></i>
                        </div>
                        <div class="align-right">
                            <a href="<?php echo home_url('/manage-request/?status=confirm_financial'); ?>" class="color-darkgray font-w200 font-s15">تایید شده مالی</a>
                            <h4 class="font-w300 font-s20 title-panel"><?php echo $count_confirm_financial; ?></h4>
                        </div>
                    </div>
                    <div class="border-t-chart font-w200 font-s12 pad-t10">
						<span class="font-w300">
							<i class="fa fa-chart-bar pad-l5 vertical"></i>
						</span>
                        <span>
							آمار درخواست های تایید شده مالی
						</span>
                    </div>
                </div>
            </div>

            <div class="colm3 colm12-tab colm pull-right pad-15 wow pad-5-mob spacer-b25-mob fadeInDown" data-wow-duration="1s">
                <div class="body-form pad-15 relative">
                    <div class="pad-b10">
                        <div class="bg-chart1 icon-cat-panel absolute flex-center">
                            <i class="fa fa-money-bill vertical font-s30 color-white"></i>
                        </div>
                        <div class="align-right">
                            <a href="<?php echo home_url('/manage-request/?status=failed_financial'); ?>" class="color-darkgray font-w200 font-s15">تایید نشده مالی</a>
                            <h4 class="font-w300 font-s20 title-panel"><?php echo $count_failed_financial; ?></h4>
                        </div>
                    </div>
                    <div class="border-t-chart font-w200 font-s12 pad-t10">
						<span class="font-w300">
							<i class="fa fa-chart-bar pad-l5 vertical"></i>
						</span>
                        <span>
							آمار درخواست های تایید نشده مالی
						</span>
                    </div>
                </div>
            </div>

            <div class="colm3 colm12-tab colm pull-right pad-15 pad-5-mob spacer-b25-mob wow fadeInDown" data-wow-duration="1s">
                <div class="body-form pad-15 relative">
                    <div class="pad-b10">
                        <div class="bg-chart2 icon-cat-panel absolute  flex-center">
                            <i class="fa fa-clipboard-check vertical font-s30 color-white"></i>
                        </div>
                        <div class="align-right">
                            <a href="<?php echo home_url('/manage-request/?status=confirm_documents'); ?>" class="color-darkgray font-w200 font-s15">تایید شده اسناد</a>
                            <h4 class="font-w300 font-s20 title-panel"><?php echo $count_confirm_documents; ?></h4>
                        </div>
                    </div>
                    <div class="border-t-chart font-w200 font-s12 pad-t10">
						<span class="font-w300">
							<i class="fa fa-chart-bar pad-l5 verticall"></i>
						</span>
                        <span>
							آمار درخواست های تایید شده اسناد
                    </span>
                    </div>
                </div>
            </div>
            <div class="colm3 colm12-tab colm pull-right pad-15 wow pad-5-mob spacer-b25-mob fadeInDown" data-wow-duration="1s">
                <div class="body-form pad-15 relative">
                    <div class="pad-b10">
                        <div class="bg-chart1 icon-cat-panel absolute flex-center">
                            <i class="fa fa-window-close vertical font-s30 color-white"></i>
                        </div>
                        <div class="align-right">
                            <a href="<?php echo home_url('/manage-request/?status=failed_documents'); ?>" class="color-darkgray font-w200 font-s15">تایید نشده اسناد</a>
                            <h4 class="font-w300 font-s20 title-panel"><?php echo $count_failed_documents; ?></h4>
                        </div>
                    </div>
                    <div class="border-t-chart font-w200 font-s12 pad-t10">
						<span class="font-w300">
							<i class="fa fa-chart-bar pad-l5 vertical"></i>
						</span>
                        <span>
							آمار درخواست های تایید نشده اسناد
						</span>
                    </div>
                </div>
            </div>

            <div class="clearfix"></div>
        </div>
    </div>
    <div class="spacer-t20">
        <div class="colm12 colm12-tab colm12-tab colm pull-right pad-15 pad-5-mob wow slideInRight" data-wow-duration="1.5s">
            <div class="body-form relative pad-b10">
                <div class="payam">
                    <div class="bg-chart5  body-form-top absolute flex-center">
                        <i class="fa fa-history vertical font-s30 color-white"></i>
                    </div>
                    <div class="absolute title-panel">
                        <h3 class="font-w300 font-s18"><?php echo $title_table; ?></h3>
                    </div>
                </div>
                <div class="pad-table overflow-scroll">
                    <?php

                    ?>
                    <table class="table color6">
                        <thead>
                        <tr>
                            <th class="center">عنوان</th>
                            <th class="center">مبلغ</th>
                            <th class="center">تاریخ</th>
                            <th class="center">وضعیت</th>
                            <th class="center">جزئیات</th>
                            <th class="center">عملیات</th>
                        </tr>
                        </thead>
                        <tbody>
                        <?php
                        if($_GET['status'] == 'confirm_financial'){
                            $query = array(
                                'key'       => 'status',
                                'value'     => 'confirm_financial',
                                'compare'   => '=',
                            );
                        }
                        if($_GET['status'] == 'failed_financial'){
                            $query = array(
                                'key'       => 'status',
                                'value'     => 'failed_financial',
                                'compare'   => '=',
                            );
                        }
                        if($_GET['status'] == 'pending'){
                            $query = array(
                                'key'       => 'status',
                                'value'     => 'pending',
                                'compare'   => '=',
                            );
                        }
                        $args = array(
                            'post_type'=>'requestmoney',
                            'meta_query'    =>  array(
                                'relation '  => 'OR',
                                $query

                            )

                        );
                        query_posts( $args );
                        while ( have_posts() ) : the_post();
                            $request_id 	= $post->ID;

                            $request_title      = get_post_meta($request_id,'request_title',true);
                            $request_expression = get_post_meta($request_id,'request_expression',true);
                            $request_money      = get_post_meta($request_id,'request_money',true);
                            ?>
                            <tr class="">
                                <td class="center"><?php the_title(); ?></td>
                                <td class="center"><?php echo $request_money; ?></td>
                                <td class="center"><?php echo jdate('Y/m/d',$post->post_created); ?></td>
                                <td class="center"><?php action_list_request($request_id) ?></td>
                                <td class="center">
                                    <a class="color-silver" title="نمایش" href="<?php the_permalink();?>"
                                    <span>
	                                	<i class="align-center font-s20 fa fa-address-card"></i>
									</span>
                                    </a>
                                </td>
                                <td class="center">
                                    <span class="color-silver btn pointer btn-requste" data-modal="<?php echo $request_id ?>">
                                        <span>
                                            <i class="align-center font-s20 fa fa-file-import"></i>
                                        </span>
                                    </span>
                                </td>
                            </tr>
                            <!-- modal -->
                            <div class="modal-overlay">
                                <div class="modal">

                                    <a class="close-modal">
                                        <svg viewBox="0 0 20 20">
                                            <path fill="#000000" d="M15.898,4.045c-0.271-0.272-0.713-0.272-0.986,0l-4.71,4.711L5.493,4.045c-0.272-0.272-0.714-0.272-0.986,0s-0.272,0.714,0,0.986l4.709,4.711l-4.71,4.711c-0.272,0.271-0.272,0.713,0,0.986c0.136,0.136,0.314,0.203,0.492,0.203c0.179,0,0.357-0.067,0.493-0.203l4.711-4.711l4.71,4.711c0.137,0.136,0.314,0.203,0.494,0.203c0.178,0,0.355-0.067,0.492-0.203c0.273-0.273,0.273-0.715,0-0.986l-4.711-4.711l4.711-4.711C16.172,4.759,16.172,4.317,15.898,4.045z"></path>
                                        </svg>
                                    </a><!-- close modal -->

                                    <div class="modal-content ajax-result">

                                    </div><!-- content -->
                                </div><!-- modal -->
                            </div><!-- overlay -->
                        <?php
                        endwhile;
                        wp_reset_query();
                        ?>
                        </tbody>
                    </table>
                </div>
            </div>
        </div>
    </div>
    <!-- modal -->
    <div class="modal-overlay">
        <div class="modal">

            <a class="close-modal">
                <svg viewBox="0 0 20 20">
                    <path fill="#000000" d="M15.898,4.045c-0.271-0.272-0.713-0.272-0.986,0l-4.71,4.711L5.493,4.045c-0.272-0.272-0.714-0.272-0.986,0s-0.272,0.714,0,0.986l4.709,4.711l-4.71,4.711c-0.272,0.271-0.272,0.713,0,0.986c0.136,0.136,0.314,0.203,0.492,0.203c0.179,0,0.357-0.067,0.493-0.203l4.711-4.711l4.71,4.711c0.137,0.136,0.314,0.203,0.494,0.203c0.178,0,0.355-0.067,0.492-0.203c0.273-0.273,0.273-0.715,0-0.986l-4.711-4.711l4.711-4.711C16.172,4.759,16.172,4.317,15.898,4.045z"></path>
                </svg>
            </a><!-- close modal -->

            <div class="modal-content result-ajax modal-content result-ajax colm10">

            </div><!-- content -->
        </div><!-- modal -->
    </div><!-- overlay -->


    <style>

        header , footer{
            display: none;
        }

        /* ---------- modal ------------ */

        .modal-overlay {
            display: flex;
            align-items: center;
            justify-content: center;
            position: fixed;
            top: 0;
            left: 0;
            width: 100%;
            height: 100%;
            z-index: 5;
            background-color: rgba(0, 0, 0, 0.07);
            opacity: 0;
            visibility: hidden;
            -webkit-backface-visibility: hidden;
            backface-visibility: hidden;
            transition: opacity 0.6s cubic-bezier(0.55, 0, 0.1, 1), visibility 0.6s cubic-bezier(0.55, 0, 0.1, 1);
        }
        .modal-overlay.active {
            opacity: 1;
            visibility: visible;

        }


        .modal {
            display: flex;
            align-items: center;
            justify-content: center;
            position: relative;
            margin: 0 auto;
            background-color: #fff;
            width: 600px;
            margin-right:38%;
            max-width: 75rem;
            min-height: 20rem;
            padding: 1rem;
            border-radius: 3px;
            opacity: 0;
            overflow-y: auto;
            visibility: hidden;
            box-shadow: 0 2px 10px rgba(0, 0, 0, 0.1);
            -webkit-backface-visibility: hidden;
            backface-visibility: hidden;
            -webkit-transform: scale(1.2);
            transform: scale(1.2);
            transition: all 0.6s cubic-bezier(0.55, 0, 0.1, 1);
        }
        .modal .close-modal {
            position: absolute;
            cursor: pointer;
            top: 5px;
            right: 15px;
            opacity: 0;
            -webkit-backface-visibility: hidden;
            backface-visibility: hidden;
            transition: opacity 0.6s cubic-bezier(0.55, 0, 0.1, 1), -webkit-transform 0.6s cubic-bezier(0.55, 0, 0.1, 1);
            transition: opacity 0.6s cubic-bezier(0.55, 0, 0.1, 1), transform 0.6s cubic-bezier(0.55, 0, 0.1, 1);
            transition: opacity 0.6s cubic-bezier(0.55, 0, 0.1, 1), transform 0.6s cubic-bezier(0.55, 0, 0.1, 1), -webkit-transform 0.6s cubic-bezier(0.55, 0, 0.1, 1);
            transition-delay: 0.3s;
        }
        .modal .close-modal svg {
            width: 1.75em;
            height: 1.75em;
        }
        .modal .modal-content {
            opacity: 0;
            -webkit-backface-visibility: hidden;
            backface-visibility: hidden;
            transition: opacity 0.6s cubic-bezier(0.55, 0, 0.1, 1);
            transition-delay: 0.3s;
        }
        .modal.active {
            visibility: visible;
            opacity: 1;
            margin-right:38%;
            -webkit-transform: scale(1);
            transform: scale(1);
        }
        .modal.active .modal-content {
            opacity: 1;
        }
        .modal.active .close-modal {
            -webkit-transform: translateY(10px);
            transform: translateY(10px);
            opacity: 1;
        }

    </style>

    <?php get_footer(); ?>
    <?php get_footer('admin'); ?>

    <script>

        /*------------- Modal ---------------
        var modalBtns = [...document.querySelectorAll(".btn")];
        modalBtns.forEach(function(btn){
            btn.onclick = function() {
                var modal = btn.getAttribute('data-modal');
                document.getElementById(modal).style.display = "block";

                jQuery('.ajax-result').load("https://app.100startups.ir/popups/", modal);
                /*
                jQuery.ajax({
                    url: "https://app.100startups.ir/popups/",
                    success: function(result){
                        jQuery(".div1").html(result);
                    }});

            }
        });

        var closeBtns = [...document.querySelectorAll(".close")];
        closeBtns.forEach(function(btn){
            btn.onclick = function() {
                var modal = btn.closest('.modal');
                modal.style.display = "none";
            }
        });
    */
        window.onclick = function(event) {
            if (event.target.className === "modal") {
            }
        }

        new WOW().init();

    </script>
    <script>

        jQuery(document).ready(function($){
            var elements = $('.modal-overlay, .modal');

            $('.btn-requste').click(function(){
                elements.addClass('active');
                var modalId = $(this).attr('data-modal');
                //document.getElementById(modal).style.display = "block";
                // jQuery('.div1').load("https://app.100startups.ir/popups/",modal);

                $.ajax({
                    url: "https://app.100startups.ir/popups/",
                    data:{id: modalId} ,
                    type: "POST",
                    success: function(result){
                        console.log(result);
                        jQuery(".result-ajax").html(result);
                    }});

            });

            $('.close-modal').click(function(){
                elements.removeClass('active');
                jQuery(".result-ajax").html().remove();
            });

        });

    </script>

<?php }else{
    wp_redirect(home_url());
}?>