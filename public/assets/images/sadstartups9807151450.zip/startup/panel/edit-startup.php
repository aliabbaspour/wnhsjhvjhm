<?php //Template Name: StartUp Edit ?>
<?php 
//$user = wp_get_current_user();
$current_user = wp_get_current_user();
//$user_id = $user->ID;
$current_user_id = $current_user->ID;
$allowed_roles = array('administrator','manager');
if(is_user_logged_in() && (array_intersect($allowed_roles, $current_user->roles )) ){
$user_id  = get_query_var( 'id_m');
$user = get_user_by( 'id', $user_id );


if(isset($_POST['submit'])){
	update_user_meta($user_id,'startup_name',$_POST['startup_name']);
	update_user_meta($user_id,'website',$_POST['website']);
	update_user_meta($user_id,'start_date',$_POST['start_date']);
	update_user_meta($user_id,'prototype',$_POST['prototype']);
	update_user_meta($user_id,'investment',$_POST['investment']);
    update_user_meta($user_id,'team_number',$_POST['team_number']);
	
	update_user_meta($user_id,'problem',$_POST['problem']);
    update_user_meta($user_id,'mysolution',$_POST['mysolution']);
    update_user_meta($user_id,'solution',$_POST['solution']);
    update_user_meta($user_id,'market_size',$_POST['market_size']);
    update_user_meta($user_id,'defect',$_POST['defect']);
	
	update_user_meta($user_id,'first_name',$_POST['first_name']);
	update_user_meta($user_id,'last_name',$_POST['last_name']);
	update_user_meta($user_id,'birthday',$_POST['birthday']);
	
	update_user_meta($user_id,'mobile',$_POST['mobile']);
	update_user_meta($user_id,'social',$_POST['social']);
	update_user_meta($user_id,'expertise',$_POST['expertise']);
	update_user_meta($user_id,'education',$_POST['education']);
	update_user_meta($user_id,'educationl',$_POST['educationl']);
	update_user_meta($user_id,'side',$_POST['side']);
	update_user_meta($user_id,'average',$_POST['average']);
	update_user_meta($user_id,'stock',$_POST['stock']);
	
    update_user_meta($user_id,'introduction',$_POST['introduction']);
    update_user_meta($user_id,'better',$_POST['better']);
	update_user_meta($user_id,'defect_team',$_POST['defect_team']);
	


	$first_name =$_POST['first_name1'];
	$last_name =$_POST['last_name1'];
	$mobile =$_POST['mobile1'];
	$email =$_POST['email1'];
	$linkedin =$_POST['linkedin1'];
	$birthday =$_POST['birthday1'];
	$expertisel =$_POST['expertisel1'];
	$educationl =$_POST['educationl1'];
	$stock =$_POST['stock1'];
	$average =$_POST['average1'];
	$id = $_POST['ids'];
	$i=0;
	foreach($first_name as $number){
		$x = $i++;
		if(!empty($id[$x])){
			$query = array(
				'ID'=>$id[$x]
			);
			$data = array(
				'first_name'=>$first_name[$x],
				'last_name'=>$last_name[$x],
				'mobile'=>$mobile[$x],
				'email'	=>$email[$x],
				'socials'=>$linkedin[$x],
				'birthday'=>$birthday,
				'expertisel'=>$expertisel[$x],
				'educationl'=>$educationl[$x],
				'stock'=>$stock[$x],
				'average'=>$average[$x],
			);
			update_datas('group_user',$data,$query);
		}

	}





	wp_redirect(home_url("/startup-edit/$user_id"));
}
$first_name = $user->first_name;
$last_name = $user->last_name ;
$email 				= $user->user_email;
$mobile   			= get_user_meta($user_id,'mobile',true);
$startup_name 		= get_user_meta($user_id,'startup_name',true);
$start_date 		= get_user_meta($user_id,'start_date',true);
$introduction 		= get_user_meta($user_id,'introduction',true);
$better 	  		= get_user_meta($user_id,'better',true);
$website 			= get_user_meta($user_id,'website',true);
$dabir_ok 			= get_user_meta($user_id,'dabir_ok',true);
$admin_comment 		= get_user_meta($user_id,'admin_comment',true);
$prototype 			= get_user_meta($user_id,'prototype',true);
$linkedin 			=  get_user_meta($user_id,'linkedin',true) ;
$introduction 		= get_user_meta($user_id,'introduction',true);
$defect_team  		= get_user_meta($user_id,'defect_team',true);
$problem			= get_user_meta($user_id,'problem',true); 
$mysolution 		= get_user_meta($user_id,'mysolution',true);
$solution 			= get_user_meta($user_id,'solution',true);
$market_size    	= get_user_meta($user_id,'market_size',true);
$defect 			= get_user_meta($user_id,'defect',true);
$social	  	  		= get_user_meta($user_id,'social',true);
$expertise	  		= get_user_meta($user_id,'expertise',true);
$education	  		= get_user_meta($user_id,'education',true);
$educationl	  		= get_user_meta($user_id,'educationl',true);
$side	  	  		= get_user_meta($user_id,'side',true);
$birthday			= get_user_meta($user_id,'birthday',true);
$average	  		= get_user_meta($user_id,'average',true);
$stock	  		= get_user_meta($user_id,'stock',true);
$investment = get_user_meta($user_id,'investment',true);
$video =  get_user_meta($user_id,'video',true);
$pdf = get_user_meta($user_id,'pdf',true);


$class = "این فیلد خالی می باشد";
?>
<?php get_header() ?>
<?php get_header('admin') ?>
<style>
footer,header{
	display: none
}
.hide-tab{
	display: none;
}
</style>

<div class="colm12 colm  margin-auto">
	<div class="spacer-t25">
		<div class="colm9 colm12-tab colm margin-auto pad-5">
			
			<form method="post">
				
		     	<div class="body-form relative  spacer-b30 pad-15 pad-25 pad-r35 pad-l35 pad-5-mob wow fadeInDown" data-wow-duration="1s">
					<div class="bg-chart1 body-form-top absolute flex-center">
						<i class="fa fa-rocket vertical font-s30 color-white"></i>
					</div>
					<div class="absolute title-panel">
						<h3 class="font-w300 font-s18 pad-r20">اطلاعات استــارت آپ ها</h3>
					</div>
					<div class="frm-row pad-40 pad-0 spacer-t30-tab spacer-t30-mob">
						<div class="colm4 colm6-tab colm pull-right pad-5">
							<label for="startup-name" class="gui-label pad-5">نام استارتاپ  <span class="color-red">*</span></label>
							<label class="relative">
								<span class="icon-gui flex-center"><i class="fa fa-rocket vertical"></i></span>
								<input type="text" class="gui-input sans-digit" id="startup-name" value="<?php echo $startup_name; ?>" name="startup_name" placeholder="مثال : رویداد" >
							</label>
						</div>
						<div class="colm4 colm6-tab colm pull-right pad-5">
							<label for="website" class="gui-label pad-5">سایت استارتاپ </label>
							<label class="relative">
								<span class="icon-gui flex-center"><i class="fa fa-desktop vertical"></i></span>
								<input type="text" dir="ltr" class="gui-input sans-digit" value="<?php echo $website; ?>" name="website" id="website" placeholder="http://100startup.ir" data-rule-website="true" >
							</label>
						</div>
						<div class="colm4 colm6-tab colm pull-right pad-5">
							<label for="prototype" class="gui-label pad-5">آیا نمونه اولیه ساخته اید <span class="color-red">*</span></label>
							<label class="relative">
								<span for="prototype" class="flex-center icon-select">
                                    <i class="fa fa-chevron-down vertical"></i>
                                </span>
                                <select class="gui-select sans-digit" id="prototype" name="prototype" >
                                    <option value="انتخاب کنید"></option>
                                    <option value="بله" <?php selected($prototype,'بله') ?>>بله</option>
                                    <option value="خیر" <?php selected($prototype,'خیر') ?>>خیر</option>
                                </select>
							</label>
						</div>
						<div class="colm4 colm6-tab colm pull-right pad-5">
							<label for="investment" class="gui-label pad-5 font-s13">آیا تا‌کنون ‌سرمایه ‌جذب‌کرده‌اید <span class="color-red">*</span></label>
							<label class="relative">
								<span class="icon-select flex-center">
                                    <i class="fa fa-chevron-down vertical"></i>
                                </span>
                                <select class="gui-select sans-digit" id="investment" name="investment" >
                                    <option value="انتخاب کنید"></option>
                                    <option value="بله" <?php selected($investment,'بله') ?>>بله</option>
                                    <option value="خیر" <?php selected($investment,'خیر') ?>>خیر</option>
                                </select>
							</label>
						</div>
						<div class="colm4 colm6-tab colm pull-right pad-5">
                            <label for="start-date" class="gui-label pad-5">تاریخ شروع به کار <span class="color-red">*</span></label>
                            <label class="relative">
                                <span class="icon-gui flex-center"><i class="fa fa-calendar-alt"></i></span>
                                <input dir="ltr" class="gui-input sans-digit" name="start_date" value="<?php echo $start_date; ?>" id="start-date" autocomplete="off" readonly placeholder="1398/10/02" >
                            </label>
                        </div>
						<div class="clearfix"></div>
					</div>
		     	</div>
		     	<div class="body-form relative  spacer-b30 pad-25 pad-r35 pad-l35 pad-5-mob wow fadeInUpBig" data-wow-duration="1s">
					<div class="bg-chart2 body-form-top absolute flex-center">
						<i class="fa fa-portrait vertical font-s30 color-white"></i>
					</div>
					<div class="absolute title-panel">
						<h3 class="font-w300 font-s18 pad-r20">اطلاعات pitch deck</h3>
					</div>
					<div class="frm-row pad-40 pad-0 spacer-t30-tab spacer-t30-mob">
                        <div class="pad-5">
                            <label for="problem" class="gui-label pad-5"> <span class="color-red">*</span>  چه مشکلی را حل می کنید ؟ </label>
                            <label class="relative">
                                <textarea name="problem" class="gui-textarea sans-digit"  maxlength="500" id="problem" ><?php echo $problem; ?></textarea>
                            </label>
                        </div>
                        <div class="pad-5">
                            <label for="mysolution" class="gui-label pad-5"><span class="color-red">*</span> راه حل شما چیست ؟ </label>
                            <label class="relative">
                                <textarea name="mysolution" class="gui-textarea sans-digit" maxlength="500" id="mysolution" ><?php echo $mysolution; ?></textarea>
                            </label>
                        </div>
                        <div class="pad-5">
                            <label for="solution" class="gui-label pad-5"><span class="color-red">*</span>  راه حل های موجود چیست ؟ </label>
                            <label class="relative">
                                <textarea name="solution" class="gui-textarea sans-digit" maxlength="500" id="solution" ><?php echo $solution; ?></textarea>
                            </label>
                        </div>
                        <div class="pad-5">
                            <label for="market-size" class="gui-label pad-5"><span class="color-red">*</span> اندازه بازار برای اینکار چقدر است ؟  </label>
                            <label class="relative">
                                <textarea name="market_size" class="gui-textarea sans-digit" maxlength="500" id="market-size" ><?php echo $market_size; ?></textarea>
                            </label>
                        </div>
                        <div class="pad-5">
                            <label for="defect" class="gui-label pad-5"><span class="color-red">*</span> رقبای داخلی و خارجی شما چه کسانی هستند ؟ </label>
                            <label class="relative">
                                <textarea name="defect" class="gui-textarea sans-digit" id="defect" ><?php echo $defect; ?></textarea>
                            </label>
                        </div>
                        <div class="pad-5">
                            <label for="pitch-deck" class="gui-label pad-5">مدل کسب و کار  </label>
                            <?php if($pdf):?>
                            <div class="pad-30">
                            	<a href="<?php echo wp_get_attachment_url( $pdf ); ?>" download>دانلود پبچ دک</a>
                            </div>
                            <?php endif ?>
                    	</div>
                    </div> 
		     	</div>
		     	<?php if($video):?>
		     	<div class="body-form relative spacer-b30 pad-25 pad-r35 pad-l35 pad-5-mob wow fadeInUpBig" data-wow-duration="1s">
					<div class="bg-chart4 body-form-top absolute flex-center">
						<i class="fa fa-play vertical font-s30 color-white"></i>
					</div>
					<div class="absolute title-panel">
						<h3 class="font-w300 font-s18 ">ویدیوی معرفی</h3>
					</div>
					<div class="frm-row pad-t30">
						<div class="colm12 pad-5 pad-t20">
							<video width="100%" controls>
								<source src="<?php echo wp_get_attachment_url( $video ); ?>"></source>
							</video>
						</div>
					</div>
				</div>
		     	<?php endif ?>
		     	<div class="body-form relative  spacer-b30 pad-25 pad-r35 pad-l35 pad-5-mob wow fadeInUpBig" data-wow-duration="1s">
					<div class="bg-chart3 body-form-top absolute flex-center">
						<i class="fa fa-user-edit vertical font-s30 color-white"></i>
					</div>
					<div class="absolute title-panel">
						<h3 class="font-w300 font-s18 pad-r20">اطلاعات تکمیلی</h3>
					</div>
					<div class="frm-row pad-40 pad-0 spacer-t30-tab spacer-t30-mob">
                        <div class="pad-5">
                            <label for="introduction" class="gui-label pad-5">نحوه آشنایی اعضای تیم با یکدیگر </label>
                            <label class="relative text-counter">
                                <textarea  name="introduction" maxlength="300"  class="gui-textarea"  ><?php echo $introduction; ?></textarea>
                            </label>
                        </div>
                        <div class="pad-5">
                            <label for="better" class="gui-label pad-5">چه چیز باعث شده شما بهتر از بقیه باشید ؟</label>
                            <label class="relative">
                                <textarea name="better" maxlength="300" id="team-excerpt1" class="gui-textarea" ><?php echo $better; ?></textarea>
                            </label>
                        </div>
                        <div class="pad-5">
                            <label for="defect" class="gui-label pad-5"> تیمتون چه چیزی کم داره ؟</label>
                            <label class="relative">
                                <textarea name="defect_team" id="team-excerpt2"  maxlength="280" class="gui-textarea" ><?php echo $defect_team; ?></textarea>
                            </label>
                        </div>
						<div class="clearfix"></div>
					</div>
		     	</div>
		     	<div class="body-form relative  spacer-b30 pad-25 pad-r35 pad-l35 pad-5-mob wow fadeInUpBig" data-wow-duration="1s">
					<div class="bg-chart4 body-form-top absolute flex-center">
						<i class="fa fa-user-tie  vertical font-s30 color-white"></i>
					</div>
					<div class="absolute title-panel">
						<h3 class="font-w300 font-s18 pad-r20">اطلاعات رهبر تیم</h3>
					</div>
					<div class="frm-row pad-40 pad-0 spacer-t30-tab spacer-t30-mob">	
						<div class="colm4 colm6-tab colm pull-right pad-5">
							<label for="first-name" class="gui-label pad-5">نام :</label>
							<label class="relative">
								<span class="icon-gui flex-center"><i class="fa fa-user vertical"></i></span>
								<input type="text" class="gui-input sans-digit" id="first-name" value="<?php echo $first_name; ?>" name="first_name" placeholder="مثال : محمد" data-rule-lettersonly="true" autocomplete="off" >
							</label>
						</div>
						<div class="colm4 colm6-tab colm pull-right pad-5"> 
							<label for="first-name" class="gui-label pad-5">نام خانوادگی :</label>
							<label class="relative">
								<span class="icon-gui flex-center"><i class="  fa fa-user vertical"></i></span>
								<input type="text" class="gui-input sans-digit" value="<?php echo $last_name; ?>" name="last_name" placeholder="مثال : محمدی" data-rule-lettersonly="true" id="last-name" autocomplete="off" >
							</label>
						</div>
						<div class="colm4 colm6-tab colm pull-right pad-5">
							<label for="mobile" class="gui-label pad-5"> شماره همراه:</label>
							<label class="relative">
								<span class="icon-gui flex-center"><i class="   fa fa-mobile"></i></span>
								<input dir="ltr" class="gui-input sans-digit" name="mobile" data-rule-customphone="true" value="<?php echo $mobile; ?>" id="mobile" autocomplete="off" placeholder="09XXXXXXXX" >
							</label>
						</div>
						<div class="colm4 colm6-tab colm pull-right pad-5">
							<label for="email" class="gui-label pad-5">ایمیل :</label>
							<label class="relative">
								<span class="icon-gui flex-center"><i class="   fa fa-at"></i></span>
								<input dir="ltr" type="email" class="gui-input sans-digit" name="email" value="<?php echo $user->user_email; ?>" id="email" placeholder="example@gmail.com" >
							</label>
						</div>
						<div class="colm4 colm6-tab colm pull-right pad-5">
							<label for="social" class="gui-label pad-5">لینکدین :</label>
							<label class="relative">
								<span class="icon-gui flex-center"><i class="   fab fa-linkedin-in vertical"></i></span>
								<input dir="ltr" type="text" class="gui-input sans-digit" value="<?php echo $social; ?>"  name="social" id="social" >
							</label>
						</div>
						<div class="colm4 colm6-tab colm pull-right pad-5">
							<label for="birthday" class="gui-label pad-5"> تاریخ تولد :</label>
							<label class="relative">
								<span class="icon-gui flex-center"><i class="fa fa-birthday-cake"></i></span>
								<input dir="ltr" class="gui-input sans-digit datepicker-gregorian" name="birthday" value="<?php echo $birthday; ?>" id="birthday" autocomplete="off" readonly placeholder="1398/10/02" >
							</label>
						</div> 
						<div class="colm4 colm6-tab colm pull-right pad-5">
							<label for="expertise" class="gui-label pad-5">تخصص:</label>
							<label class="relative">
								<span class="icon-gui flex-center"><i class=" fa fa-laptop-code vertical"></i></span>
								<input type="text" class="gui-input sans-digit" name="expertise" value="<?php echo $expertise; ?>" id="expertise" placeholder="مثال : نرم افزار" required>
							</label>
						</div>
						<div class="colm4 colm6-tab colm pull-right pad-5">
							<label class="gui-label pad-5">تحصیلات:</label>
							<label  class="relative">
								<span class="icon-gui flex-center"><i class=" fa fa-user-graduate vertical"></i></span>
								<select class="gui-input sans-digit" name="educationl">
									<option value="">میزان تحصیلات خود را انتخاب کنید</option>
									<option value="1"<?php if ( $educationl == 1 ) echo 'selected="selected"'; ?>>زیر دیپلم</option>
									<option value="2"<?php if ( $educationl == 2 ) echo 'selected="selected"'; ?>>دیپلم</option>
									<option value="3"<?php if ( $educationl == 3 ) echo 'selected="selected"'; ?>>فوق دیپلم</option>
									<option value="4"<?php if ( $educationl == 4 ) echo 'selected="selected"'; ?>>لیسانس</option>
									<option value="4"<?php if ( $educationl == 5 ) echo 'selected="selected"'; ?>>فوق لیسانس</option>
									<option value="4"<?php if ( $educationl == 6 ) echo 'selected="selected"'; ?>>دکتری</option>
									<option value="4"<?php if ( $educationl == 7 ) echo 'selected="selected"'; ?>>فوق دکتری</option>
								</select>
							</label>
						</div>
						<div class="colm4 colm6-tab colm pull-right pad-5">
							<label for="stock" class="gui-label pad-5">میزان سهام :</label>
							<label class="relative">
								<span class="icon-gui flex-center"><i class=" fa fa-percentage vertical"></i></span>
								<input type="number" class="gui-input sans-digit" name="stock1[]" value="<?php echo $number_s->stock; ?>" id="stock" placeholder="مثال :  20 درصد" >
							</label>
						</div>
						<div class="colm6 colm6-tab colm pull-right pad-5">
							<label for="average" class="gui-label pad-5"> زمان اختصاص داده شده به استارتاپ در طول ماه:</label>
							<label class="relative">
								<span class="icon-gui flex-center"><i class=" fa fa-clock vertical"></i></span>
								<input type="number" class="gui-input sans-digit" name="average1[]" value="<?php echo $number_s->average; ?>" id="average" placeholder="مثال : 100 ساعت" >
							</label>
						</div>
	
						<div class="clearfix"></div>
					</div>
		     	</div>
		     	
		     	
		     	
		     	<?php
				$args = array(
					'showposts'=>10,
					'query'=>array(
						array(
							'key'=>'user_id',
							'value'=>$user_id,
							'compare'=>'='
						),
						array(
							'key'=>'status',
							'value'=>'publish',
							'compare'=>'='
						)
					)
				);
				$group_user = query_data('group_user',$args);
			?>
			<?php foreach($group_user as $number_s): ?>
		     	<div class="body-form relative  spacer-b30 pad-25 pad-r35 pad-l35 pad-5-mob wow fadeInUpBig" data-wow-duration="1s">
		     		<input type="hidden" name="ids[]" value="<?php echo $number_s->id ?>" />
	 				<div class="body-form-top absolute flex-center">
						<i class="fa fa-users vertical font-s30 color-white"></i>
					</div>
					<div class="absolute title-panel">
						<h3 class="font-w300 font-s18 pad-r20">اطلاعات اعضای تیم</h3>
					</div>
					<div class="frm-row pad-40 pad-0 spacer-t30-tab spacer-t30-mob">
						<div class="colm4 colm6-tab colm pull-right pad-5">
							<label for="first-name" class="gui-label pad-5">نام :</label>
							<label class="relative">
								<span class="icon-gui flex-center"><i class="fa fa-user vertical"></i></span>
								<input type="text" class="gui-input sans-digit" name="first_name1[]" value="<?php echo $number_s->first_name; ?>"  placeholder="مثال : محمد" data-rule-lettersonly="true" autocomplete="off" >
							</label>
						</div>
						<div class="colm4 colm6-tab colm pull-right pad-5"> 
							<label for="first-name" class="gui-label pad-5">نام خانوادگی :</label>
							<label class="relative">
								<span class="icon-gui flex-center"><i class="  fa fa-user vertical"></i></span>
								<input type="text" name="last_name1[]" class="gui-input sans-digit" value="<?php echo $number_s->last_name; ?>" placeholder="مثال : محمدی" data-rule-lettersonly="true" id="last-name" autocomplete="off" >
							</label>
						</div>
						<div class="colm4 colm6-tab colm pull-right pad-5">
							<label class="gui-label pad-5"> شماره همراه:</label>
							<label class="relative">
								<span class="icon-gui flex-center"><i class="fa fa-mobile"></i></span>
								<input dir="ltr" class="gui-input sans-digit" name="mobile1[]" data-rule-customphone="true" value="<?php echo $number_s->mobile; ?>" autocomplete="off" placeholder="09XXXXXXX" >
							</label>
						</div>
						<div class="colm4 colm6-tab colm pull-right pad-5">
							<label for="email" class="gui-label pad-5">ایمیل :</label>
							<label class="relative">
								<span class="icon-gui flex-center"><i class="fa fa-at"></i></span>
								<input dir="ltr" type="email"  name="email1[]" class="gui-input sans-digit" value="<?php echo $number_s->email; ?>"  placeholder="example@gmail.com" >
							</label>
						</div>
						<div class="colm4 colm6-tab colm pull-right pad-5">
							<label for="social" class="gui-label pad-5">لینکدین :</label>
							<label class="relative">
								<span class="icon-gui flex-center"><i class="fab fa-linkedin-in vertical"></i></span>
								<input dir="ltr" type="text"  name="linkedin1[]" class="gui-input sans-digit" value="<?php echo $number_s->socials; ?>" >
							</label>
						</div>
						<div class="colm4 colm6-tab colm pull-right pad-5">
							<label for="birthday" class="gui-label pad-5"> تاریخ تولد :</label>
							<label class="relative">
								<span class="icon-gui flex-center"><i class="   fa fa-birthday-cake"></i></span>
								<input dir="ltr" name="birthday1[]" class="gui-input sans-digit datepicker-gregorian"  value="<?php echo $number_s->birthday; ?>"  autocomplete="off" readonly placeholder="1398/10/02" >
							</label>
						</div>
						<div class="colm4 colm6-tab colm pull-right pad-5">
							<label for="expertise" class="gui-label pad-5">تخصص:</label>
							<label class="relative">
								<span class="icon-gui flex-center"><i class=" fa fa-laptop-code vertical"></i></span>
								<input type="text" class="gui-input sans-digit" name="expertisel1[]" value="<?php echo $number_s->expertise; ?>" placeholder="مثال : نرم افزار" required>
							</label>
						</div>
						<div class="colm4 colm6-tab colm pull-right pad-5">
							<label class="gui-label pad-5">تحصیلات:</label>
							<label  class="relative">
								<span class="icon-gui flex-center"><i class=" fa fa-user-graduate vertical"></i></span>
								<select class="gui-input sans-digit" name="educationl1[]">
									<option value="">میزان تحصیلات خود را انتخاب کنید</option>
									<option value="1"<?php if ( $number_s->education == 1 ) echo 'selected="selected"'; ?>>زیر دیپلم</option>
									<option value="2"<?php if ( $number_s->education == 2 ) echo 'selected="selected"'; ?>>دیپلم</option>
									<option value="3"<?php if ( $number_s->education == 3 ) echo 'selected="selected"'; ?>>فوق دیپلم</option>
									<option value="4"<?php if ( $number_s->education == 4 ) echo 'selected="selected"'; ?>>لیسانس</option>
									<option value="5"<?php if ( $number_s->education == 5 ) echo 'selected="selected"'; ?>>فوق لیسانس</option>
									<option value="6"<?php if ( $number_s->education == 6 ) echo 'selected="selected"'; ?>>دکتری</option>
									<option value="7"<?php if ( $number_s->education == 7 ) echo 'selected="selected"'; ?>>فوق دکتری</option>
								</select>
							</label>
						</div>
						<div class="colm4 colm6-tab colm pull-right pad-5">
							<label class="gui-label pad-5">میزان سهام :</label>
							<label class="relative">
								<span class="icon-gui flex-center"><i class=" fa fa-percentage vertical"></i></span>
								<input type="number" class="gui-input sans-digit" name="stockl[]" value="<?php echo $number_s->stock; ?>"  placeholder="مثال :  20 درصد" >
							</label>
						</div>
						<div class="colm6 colm6-tab colm pull-right pad-5">
							<label for="sidel" class="gui-label pad-5"> سمت در استارت آپ :</label>
							<label class="relative">
								<span class="icon-gui flex-center"><i class=" fa fa-book-reader"></i></span>
								<input dir="rtl" class="gui-input sans-digit " name="sidel[]" value="<?php echo $number_s->side; ?>"  autocomplete="off" placeholder="سمت استارت آپ" required>
							</label>
						</div>
						<div class="colm6 colm6-tab colm pull-right pad-5">
							<label class="gui-label pad-5"> زمان اختصاص داده شده به استارتاپ در طول ماه:</label>
							<label class="relative">
								<span class="icon-gui flex-center"><i class=" fa fa-clock vertical"></i></span>
								<input type="number" class="gui-input sans-digit" name="averagel[]" value="<?php echo $number_s->average; ?>"  placeholder="مثال : 100 ساعت" >
							</label>
						</div>
						<div class="clearfix"></div>
					</div>
		     	</div>
		     	<?php endforeach ?>
		     	
 				 <div class="align-center pad-t10">
                    <button type="submit" name="submit" class="btn-panel pad-10 color-white iransans wow fadeInUpBig" data-wow-duration="1s">بروزرسانی</button>
                </div>
			</form>
		</div>
     	<div class="clearfix"></div>
	</div>
</div>
<?php get_footer() ?>
<?php get_footer('admin') ?>
<script>
	new WOW().init();
</script>
<?php }?>