<?php get_header() ?>
<div class="container-fluid bg-purple">
    <div class="container">
    	<h1 class="pad-20 align-center font-s40 color-white bold">
			بلاگ
		</h1>
    </div>
</div>
<div class="container-fluid bg-gray">
    <div class="container pad-20">
		<?php while(have_posts()):the_post()?>
			<?php get_template_part('loop','blog');?>
		<?php endwhile ?>
		<div class="clearfix"></div>
		<div class="paging"><?php if (function_exists("pagination")) { pagination($additional_loop->max_num_pages);} ?></div>
    </div>
</div>
<?php get_footer(); ?>