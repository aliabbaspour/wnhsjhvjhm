<?php
wp_list_comments( $args, $comments ); 
	paginate_comments_links();
	comment_form();
?>