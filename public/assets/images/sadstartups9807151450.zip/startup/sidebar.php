<div id="sidebar" class="colm3 colm pull-right">
    <?php if ( is_active_sidebar( 'sidebar-1' ) ) :?>
        <?php dynamic_sidebar('sidebar-1'); ?>   
    <?php endif; ?>  
</div>