<?php
if ( function_exists( 'add_image_size' ) ) {
	add_image_size( 'medium-crop', 500, 500, true );
}