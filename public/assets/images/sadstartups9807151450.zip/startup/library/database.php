<?php
/*--------- Insert Table -----------------*/
function insert_data($tabel,array $data) {
	if(is_array($data) ){
		global $wpdb;
		$tabel = $wpdb->prefix.$tabel;
		$ticket_insert = $wpdb->insert($tabel, $data);  
		$lastid = $wpdb->insert_id ;   
		return $lastid;
	}else{
		return false ;    
	} 
};
function delete_data($tabel,$column,$value) {
	global $wpdb;
	$tabel = $wpdb->prefix.$tabel;
	$tabel_data_delete = $wpdb->delete( $tabel, array( $column => $value ) );   
	return $tabel_data_delete;
};

function update_data($find_in,$find_this,$field,$value,$tabel_name) {  
	global $wpdb;
	$tabel_name = $wpdb->prefix.$tabel_name;
	if ($field <> $find_in) { 
		$wpdb -> update($tabel_name, array($field => $value), array($find_in => $find_this));
	}
};
function update_datas($tabel_name,$data,$query) {  
	global $wpdb;
	$tabel_name = $wpdb->prefix.$tabel_name;
	$return = $wpdb -> update($tabel_name, $data, $query);
};
function query_data($tabel,$args){
	global $wpdb;
	$tabel = $wpdb->prefix.$tabel ;
	$current_page = ($args['paged'])?$args['paged']:'1';
	$items_per_page = ($args['showposts'])?$args['showposts']:'3';
	$orders = ($args['order'])?$args['order']:'DESC';
	$order_by = ($args['order_by'])?$args['order_by']:'ID';
	$meta_query = $args['query'];
	$or = ($args['or'])?$args['or']:'AND';
	if($meta_query){
		for ($i=0; $i < count($meta_query); $i++) {
			$key = $meta_query[$i]['key'];
			$value = $meta_query[$i]['value'];
			$compare = ($meta_query[$i]['compare'])?$meta_query[$i]['compare']:" LIKE ";
			if($i == 0) $where .=" WHERE " ;
			if($compare == "BETWEEN"){
				$value = str_replace(","," AND ",$value);
			}
			$where .= "$key $compare '$value' ";
			if(count($meta_query) > $i+1 ) $where .=" $or " ;
		}
	}
	
	$start_index = ($current_page - 1) * $items_per_page ;
	$total_items = $wpdb->get_var("SELECT COUNT(*) FROM $tabel $where");
	$total_pages = ceil($total_items / $items_per_page);
	if($items_per_page == -1){
		$items_per_page = $total_items;
	}
	$tabel_data = $wpdb->get_results("SELECT * FROM $tabel $where ORDER BY $order_by $orders LIMIT $start_index, $items_per_page "); 
	return $tabel_data ;
}
function get_project($project_id){
	global $wpdb;
	$tabel = $wpdb->prefix.'project' ;
	$tabel_data = $wpdb->get_results("SELECT * FROM $tabel WHERE `post_id` = $project_id"); 
	return $tabel_data ;
} 
function query_join($tabel1,$tabel2,$column,$query_key,$query_value){    
	global $wpdb;				
	$tabel1 = $wpdb->prefix.$tabel1;
	$tabel2 = $wpdb->prefix.$tabel2;
	$tabel_data = $wpdb->get_results("SELECT $tabel1.* FROM $tabel1 INNER JOIN $tabel2 ON $tabel1.$column = $tabel2.$column WHERE $tabel2.$query_key = '$query_value'");//just post_id
	return $tabel_data;
	//------- Query is set for table2 
	//------- $table1.* between SELECT and FROM gives data of table1 (Default is data of Table2)
	//------- for specific data : $table1.post_id between SELECT and FROM
}  

function get_multiple_data($tabel,$find_in,$find_these,$order_key,$order_by){  
	global $wpdb;
	$tabel = $wpdb->prefix.$tabel; 
	$find_these = implode(",",$find_these);
	if(empty($order_by)){ 
		$order_by = 'DESC';
	} 
	if(!empty($order_key) ){
		$order_key = "$tabel.$order_key";
	}else{
		$order_key = "$tabel.ID";   
	} 
 							
	$tabel_data = $wpdb->get_results("SELECT * FROM $tabel WHERE $find_in IN ($find_these) ORDER BY $order_key $order_by");   
	return $tabel_data;
}

function user_name_exists($user_name){    
	global $wpdb;
	$tabel = $wpdb->prefix.'usermeta'; 		
	$tabel_data = $wpdb->get_results("SELECT * FROM $tabel WHERE `meta_key` LIKE 'user_name' AND `meta_value` LIKE '$user_name'");  
	if($tabel_data){
		return $tabel_data;
	}else{
		return '-1';
	}
}

function code_exists($code){    
	global $wpdb;
	$tabel = $wpdb->prefix.'usermeta'; 		
	$tabel_data = $wpdb->get_results("SELECT * FROM $tabel WHERE `meta_key` LIKE 'code' AND `meta_value` LIKE '$code'");  
	if($tabel_data){
		return $tabel_data;
	}else{
		return '-1';
	}
}

function mobile_exists($mobile){    
	global $wpdb;
	$tabel = $wpdb->prefix.'usermeta'; 		
	$tabel_data = $wpdb->get_results("SELECT * FROM $tabel WHERE `meta_key` LIKE 'mobile' AND `meta_value` LIKE '$mobile'");  
	if($tabel_data){
		return $tabel_data;
	}else{
		return '-1';
	}
}
function mobile_exist($mobile){    
	global $wpdb;
	$tabel = $wpdb->prefix.'usermeta'; 		
	$tabel_data = $wpdb->get_results("SELECT * FROM $tabel WHERE `meta_key` LIKE 'mobile' AND `meta_value` LIKE '$mobile'");  
	if($tabel_data){
		return 1;
	}else{
		return '-1';
	}
}

function query_by_date($tabel,$days_ago){    
	global $wpdb;	
	$tabel = $wpdb->prefix.$tabel; 			
	$tabel_data = $wpdb->get_results("SELECT * FROM $tabel WHERE `date` >= NOW() - INTERVAL $days_ago DAY AND `date` < NOW() ORDER BY $tabel.`current_followers` DESC"); 
	return $tabel_data; 
} 

function query_count($tabel,$query){
	global $wpdb;
	$tabel = $wpdb->prefix.$tabel ;
	if($query){
		for ($i=0; $i < count($query) ; $i++) { 
		$compare = ($i < count($query)-1) ? 'AND': '' ;
			$key = key($query);
			$mquery .= " $key = '$query[$key]' $compare ";
			next($query);
		};
		if($mquery){
			$mquery = 'WHERE '.$mquery ;
		}else{
			$mquery = '';
		}
	}
	$rowcount = $wpdb->get_var("SELECT COUNT(*) FROM $tabel $mquery");
	return $rowcount; 
}



//Create Table referee
function operational_create_db() {
	global $wpdb;
	$charset_collate = $wpdb->get_charset_collate();
	$table = $wpdb->prefix . 'operational';

	$sql = "CREATE TABLE $table ( 
		id mediumint(9) NOT NULL AUTO_INCREMENT,
		user_id bigint(20) NOT NULL,
		author_id bigint(20) NOT NULL,
		referee1 varchar(20),
		referee2 varchar(20),
		referee3 varchar(20),
		referee4 varchar(20),
		date datetime,
		status varchar(20),
		PRIMARY KEY  (id)
	) $charset_collate;";

	require_once( ABSPATH . 'wp-admin/includes/upgrade.php' );
	dbDelta( $sql );
}
add_action("admin_init","operational_create_db");
//Create Table referee
function referee_create_db() {
	global $wpdb;
	$charset_collate = $wpdb->get_charset_collate();
	$table = $wpdb->prefix . 'referee';

	$sql = "CREATE TABLE $table ( 
		id mediumint(9) NOT NULL AUTO_INCREMENT,
		user_id bigint(20) NOT NULL,
		author_id bigint(20) NOT NULL,
		score_full int(30),
		score_coordination int(30),
		score_ability int(30),
		score_market int(30),
		score_growth int(30),
		score_competition int(30),
		score_targetmarket int(30),
		score_suggestedvalue int(30),
		score_mvp int(30),
		score_transparency int(30),
		score_advantage int(30),
		score_strategy int(30),
		score_precise int(30), 
		score_comment text NULL,
		scorestatus varchar(20),
		date datetime,
		status varchar(20),
		PRIMARY KEY  (id)
	) $charset_collate;";

	require_once( ABSPATH . 'wp-admin/includes/upgrade.php' );
	dbDelta( $sql );
}
add_action("admin_init","referee_create_db");

function message_create_db() {
	global $wpdb;
	$charset_collate = $wpdb->get_charset_collate();
	$table = $wpdb->prefix . 'message';
	$sql = "CREATE TABLE $table ( 
		id mediumint(9) NOT NULL AUTO_INCREMENT,
		user_id bigint(20) NOT NULL,
		receiver_id bigint(20) NOT NULL,
		message_title text,
		message_content longtext NULL,
		date datetime, 
		status varchar(20),
		PRIMARY KEY  (id)
	) $charset_collate;";

	require_once( ABSPATH . 'wp-admin/includes/upgrade.php' );
	dbDelta( $sql );
}
add_action("admin_init","message_create_db");

 function notifiction_create_db() {
	global $wpdb;
	$charset_collate = $wpdb->get_charset_collate();
	$table = $wpdb->prefix . 'notifiction';
	$sql = "CREATE TABLE $table ( 
		id mediumint(9) NOT NULL AUTO_INCREMENT,
		user_id bigint(20) NOT NULL,
		receiver_id bigint(20) NOT NULL,
		message_id bigint(20) NOT NULL,
		date datetime, 
		status varchar(20),

	) $charset_collate;";

	require_once( ABSPATH . 'wp-admin/includes/upgrade.php' );
	dbDelta( $sql );
}
add_action("admin_init","notifiction_create_db");