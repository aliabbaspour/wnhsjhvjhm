<?php
add_filter('query_vars', function($vars) {
	$vars[] = 'id_m';
	return $vars;
});

add_action('init', function() {
    add_rewrite_rule('^information/([^/]*)/?', 'index.php?pagename=information&id_m=$matches[1]', 'top');
    add_rewrite_rule('^startup-edit/([^/]*)/?', 'index.php?pagename=startup-edit&id_m=$matches[1]', 'top');
    add_rewrite_rule('^profiles/([^/]*)/?', 'index.php?pagename=profiles&id_m=$matches[1]', 'top');
    add_rewrite_rule('^send-message/([^/]*)/?', 'index.php?pagename=send-message&id_m=$matches[1]', 'top');

});