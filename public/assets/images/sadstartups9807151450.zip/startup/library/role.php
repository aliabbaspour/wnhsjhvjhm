<?php
add_role( 'managers','مدیران');
remove_role( 'secretariat' );