<?php
class View_Widget extends WP_Widget {
    function __construct() {
        parent::__construct(
            'View_Widget', // Base ID
            __( 'اخبار پربازدید', 'sws' ), // Name
            array( 'description' => __( 'نمایش اخبار پربازدید ', 'sws' ), ) // Args
        );
    }
    public function widget( $args, $instance ) {
        echo $args['before_widget'];
        if ( ! empty( $instance['title'] ) ) {
            $view_title = apply_filters( 'widget_title', $instance['title'] );
        }
        if ( ! empty( $instance['showpost'] ) ) {
            $view_showpost =  apply_filters( 'widget-showpost', $instance['showpost'] );
        }
        if ( ! empty( $instance['image'] ) ) {
            $view_image = apply_filters( 'widget_image', $instance['image'] );
        }
        if ( ! empty( $instance['cat'] ) ) {
            $view_cat = apply_filters( 'widget_cat', $instance['cat'] );
        }
?>
<div class="widget-view-box relative">
    <div class="widget-view-head">
        <?php $category_link = get_category_link($view_cat); ?>
        <h3 class="widget-view-title">
            <a href="<?php echo $category_link ?>">
                <?php echo $view_title ?>
            </a>
        </h3>
    </div>
    <ul class="pad-r15 pad-l15 pad-b15 font-s13">
    <?php 
        $args=array('showposts'=>$view_showpost,'cat'=>$view_cat);
        query_posts($args);
        while(have_posts()):the_post();
        if (trim($view_image)== 1):?>
        <li class="widget-view-post widget-view-post-thumbnail">
            <div class="pull-right colm colm3">
                <div class="widget-view-post-image responsive">
                    <a href="<?php the_permalink() ?>"><?php the_post_thumbnail('thumbnail') ?></a>
                </div>
            </div>
            <div class="widget-view-post-meta pull-right colm colm9">
                <h4><a href="<?php the_permalink() ?>"><?php the_title() ?></a></h4>
            </div> 
            <div class="clearfix"></div>
        </li>
        <?php else:?>
        <li class="widget-view-post widget-column-list">
            <h4><a href="<?php the_permalink() ?>"><?php the_title() ?></a></h3>
        </li>
        <?php endif ?>
    <?php endwhile;wp_reset_query()?>
    </ul>
</div>
</div>
<?php   
    echo $args['after_widget'];
    }
    public function form( $instance ) {
        $title = ! empty( $instance['title'] ) ? $instance['title'] : __( 'دسته ها', 'sws' );
        $showpost = ! empty( $instance['showpost'] ) ? $instance['showpost'] : __( '', 'sws' );
        $image = ! empty( $instance['image'] ) ? $instance['image'] : __( '', 'sws' );
        $cat = ! empty( $instance['cat'] ) ? $instance['cat'] : __( '', 'sws' );
        ?>
        <p>
        <label for="<?php echo $this->get_field_id( 'title' ); ?>"><?php _e( 'title :' ); ?></label> 
        <input class="widefat" id="<?php echo $this->get_field_id( 'title' ); ?>" name="<?php echo $this->get_field_name( 'title' ); ?>" type="text" value="<?php echo esc_attr( $title ); ?>">
        </p>
        <p>
            <label for="<?php echo $this->get_field_id( 'showpost' ); ?>">تعداد نمایش</label>
            <input class="widefat" id="<?php echo $this->get_field_id( 'showpost' ); ?>" name="<?php echo $this->get_field_name( 'showpost' ); ?>" type="number" value="<?php echo esc_attr( $showpost ); ?>">
        </p>
        <p>
        <label for="<?php echo $this->get_field_id( 'cat' ); ?>">کد دسته</label> 
        <input class="widefat" id="<?php echo $this->get_field_id( 'cat' ); ?>" name="<?php echo $this->get_field_name( 'cat' ); ?>" type="text" value="<?php echo esc_attr( $cat ); ?>">
        کد دسته ها را با علامت , از یکدیگر جدا کنید
        </p>
        <p>
        <label for="<?php echo $this->get_field_id( 'image' ); ?>">عکس</label> 
        <input class="widefat" id="<?php echo $this->get_field_id( 'image' ); ?>" name="<?php echo $this->get_field_name( 'image' ); ?>" type="text" value="<?php echo esc_attr( $image ); ?>">
        برای نشان دادن عکس عدد 1 را وارد کنید.
        </p>
        <?php 
    }
    public function update( $new_instance, $old_instance ) {
        $instance = array();
        $instance['title'] = ( ! empty( $new_instance['title'] ) ) ? strip_tags( $new_instance['title'] ) : '';
        $instance['showpost'] = ( ! empty( $new_instance['showpost'] ) ) ? strip_tags( $new_instance['showpost'] ) : '';
        $instance['image'] = ( ! empty( $new_instance['image'] ) ) ? strip_tags( $new_instance['image'] ) : '';
        $instance['cat'] = ( ! empty( $new_instance['cat'] ) ) ? strip_tags( $new_instance['cat'] ) : '';
        return $instance;
    }

} // class View_Widget
function register_View_Widget() {
    register_widget( 'View_Widget' );
}
add_action( 'widgets_init', 'register_View_Widget' );