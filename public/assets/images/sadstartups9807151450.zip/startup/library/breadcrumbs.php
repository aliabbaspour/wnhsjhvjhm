<?php
function the_breadcrumb() {
    global $post;
    if (!is_home()) {
        echo '<span>موقعیت فعلی شما : </span><a href="';
        echo get_option('home');
        echo '">';
        echo 'خانه';
        echo '</a>/';
        if (is_category() || is_single()) {
            
            the_category('/');
            if (is_single()) {
            }
        } elseif (is_page()) {
            if($post->post_parent){
                $anc = get_post_ancestors( $post->ID );
                $title = get_the_title();
                foreach ( $anc as $ancestor ) {
                    $output = '<a href="'.get_permalink($ancestor).'" title="'.get_the_title($ancestor).'">'.get_the_title($ancestor).'</a>';
                }
                echo $output;
                echo '<span title="'.$title.'"> '.$title.'</span>';
            } else {
                echo '<span> '.get_the_title().'</span>';
            }
        }
    }
    elseif (is_tag()) {single_tag_title();}
    elseif (is_day()) {echo"<a>Archive for "; the_time('F jS, Y'); echo'</a>';}
    elseif (is_month()) {echo"<a>Archive for "; the_time('F, Y'); echo'</a>';}
    elseif (is_year()) {echo"<a>Archive for "; the_time('Y'); echo'</a>';}
    elseif (is_author()) {echo"<a>Author Archive"; echo'</a>';}
    elseif (isset($_GET['paged']) && !empty($_GET['paged'])) {echo "<a>Blog Archives"; echo'</a>';}
    elseif (is_search()) {echo"<a>Search Results"; echo'</a>';}
}