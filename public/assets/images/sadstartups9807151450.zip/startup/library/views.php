<?php
function getPostViews($postID){
if( is_admin() ) return;
$count_key = 'post_views_count';
$count = get_post_meta($postID, $count_key, true);
if($count==''){
    delete_post_meta($postID, $count_key);
    add_post_meta($postID, $count_key, '0');
    return "0 View";
}
return $count.' Views';
}
function setPostViews($postID) {
	if( is_admin() ) return;
	$count_key = 'post_views_count';
	$count = get_post_meta($postID, $count_key, true);
	if($count==''){
	    $count = 0;
	    delete_post_meta($postID, $count_key);
	    add_post_meta($postID, $count_key, '0');
	}else{
	    $count++;
	    update_post_meta($postID, $count_key, $count);
	}
}
 
// Add it to a column in Admin
add_filter('manage_posts_columns', 'posts_column_views');
add_action('manage_posts_custom_column', 'posts_custom_column_views',5,2);
function posts_column_views($defaults){
    $defaults['post_views'] = __('views', 'sws');
    return $defaults;
}
function posts_custom_column_views($column_name, $id){
    if($column_name === 'post_views'){
        echo getPostViews(get_the_ID());
    }
}

// widget views
class Popular_Widget extends WP_Widget {
	function __construct() {
		parent::__construct(
			'Popular_Widget', // Base ID
			__( 'Most visited', 'sws' ), // Name
			array( 'description' => __( 'Most visited Posts', 'sws' ), ) // Args
		);
	}
	public function widget( $args, $instance ) {
		echo $args['before_widget'];
		if ( ! empty( $instance['title'] ) ) {
			echo $args['before_title'] . apply_filters( 'widget_title', $instance['title'] ). $args['after_title'];
		}
?>
<ul>
<?php 
	$args=array('showposts'=>$instance['number'],'meta_key' => 'post_views_count', 'orderby' => 'post_views_count','orderby' => 'meta_value_num', 'order' => 'DESC');
	query_posts($args);
	while(have_posts()):the_post();
?>
	<li>
		<a href="<?php the_permalink()?>"  target="_blank">
		<?php the_title() ?>
		</a>
	</li>
<?php endwhile;wp_reset_query() ?>
</ul>
</div>

<?php
echo $args['after_widget'];
}
public function form( $instance ) {
$title = ! empty( $instance['title'] ) ? $instance['title'] : __( 'Most visited', 'sws' );
$number = ! empty( $instance['number'] ) ? $instance['number'] : __( '20', 'sws' );
		?>
		<p>
		<label for="<?php echo $this -> get_field_id('title'); ?>"><?php _e('title :', 'sws'); ?></label> 
		<input class="widefat" id="<?php echo $this -> get_field_id('title'); ?>" name="<?php echo $this -> get_field_name('title'); ?>" type="text" value="<?php echo esc_attr($title); ?>">
		</p>
		<p>
		<label for="<?php echo $this -> get_field_id('number'); ?>"><?php _e('post count :', 'sws'); ?></label> 
		<input class="widefat" id="<?php echo $this -> get_field_id('number'); ?>" name="<?php echo $this -> get_field_name('number'); ?>" type="number" value="<?php echo esc_attr($number); ?>">
		</p>
		<?php
		}
		public function update( $new_instance, $old_instance ) {
		$instance = array();
		$instance['title'] = ( ! empty( $new_instance['title'] ) ) ? strip_tags( $new_instance['title'] ) : '';
		$instance['number'] = ( ! empty( $new_instance['number'] ) ) ? strip_tags( $new_instance['number'] ) : '';
		return $instance;
		}

		} // class Popular_Widget
		function register_Popular_Widget() {
		register_widget( 'Popular_Widget' );
		}
		add_action( 'widgets_init', 'register_Popular_Widget' );

		// Register the column as sortable
		function view_column_register_sortable( $defaults ) {
		$defaults['post_views'] = 'post_views_count';
		return $defaults;
		}
		add_filter( 'manage_edit-post_sortable_columns', 'view_column_register_sortable' );
		// Register the column as sortable
		function view_column_register_sortable_photo( $defaults ) {
		$defaults['post_views'] = 'post_views_count';
		return $defaults;
		}

		function view_column_orderby( $vars ) {
		if ( isset( $vars['orderby'] ) && 'post_views_count' == $vars['orderby'] ) {
		$vars = array_merge( $vars, array(
		'meta_key' => 'post_views_count',
		'orderby' => 'meta_value_num'
		) );
		}

		return $vars;
		}
		add_filter( 'request', 'view_column_orderby' );