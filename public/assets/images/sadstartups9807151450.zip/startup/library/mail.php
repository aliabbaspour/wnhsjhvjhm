<?php
add_action( 'phpmailer_init', 'wpse8170_phpmailer_init' );
function wpse8170_phpmailer_init( PHPMailer $phpmailer ) {
    $phpmailer->Host = 'mail.planext.ir';
    $phpmailer->Port = 587 ; // could be different
    $phpmailer->Username = 'info@planext.ir'; // if required
    $phpmailer->Password = '09125130071'; // if required
    $phpmailer->SMTPAuth = true; // if required
	$phpmailer->SMTPSecure = 'ssl'; // enable if required, 'tls' is another possible value
    $phpmailer->IsSMTP();
}
function wpb_sender_email( $original_email_address ) {
    return 'support@100startups.ir';
}
function wpb_sender_name( $original_email_from ) {
    return 'صد استارتاپ';
}
add_filter( 'wp_mail_from', 'wpb_sender_email' );
add_filter( 'wp_mail_from_name', 'wpb_sender_name' );