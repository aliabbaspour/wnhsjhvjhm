<?php 
function send_sms($phone,$message){
	$api_key = '2F417954435A6C766E783236736D414A3231316F33586C45453979344D707047';
	$message = urlencode($message);
	$url = "https://api.kavenegar.com/v1/$api_key/verify/lookup.json?receptor=$phone&token=$message&template=register";
	file_get_contents($url);  
}
/*
function send_sms($phone,$message){
	$message = urlencode($message);
	//$url = "https://api.kavenegar.com/v1/$api_key/verify/lookup.json?receptor=$phone&token=$message&template=register";
	$url = "http://ideap.ir/send_via_get/send_sms.php?username=admin&password=09125130071&sender_number=5000263500&receiver_number=$phone&note=$message";
	file_get_contents($url);  
}
*/