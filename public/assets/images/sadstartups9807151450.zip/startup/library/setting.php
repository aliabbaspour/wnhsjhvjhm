<?php
add_action('admin_menu', 'my_setting_menu');
function my_setting_menu() { 
    add_menu_page( 'تنظیمات', 'تنظیمات سایت', 'edit_others_posts' , 'Setting', 'my_setting_options','dashicons-admin-generic'); 
} 
function my_setting_options() {
?>
<div class="setting wrap">
    <div class="setting-admin-container">
        <h1>تـنـظیمات </h1>
        <div>
            <form method="post">
                <div class="padt-10 pad-b10">
                    <label for="setting-webpage-keyword" class="show pad-b10">کلمات کلیدی</label>
                    <input type="text" id="setting-webpage-keyword" name="setting_webpage_keyword" class="container-fluid" value="<?php echo get_option('setting_webpage_keyword'); ?>"/>
                    <p class="admin-setting-note">کلمات را با علامت , از یکدیگر جدا کنید.</p>
                </div>
                
                
                <div class="padt-10 pad-b10">
                    <label for="setting-webpage-description" class="show pad-b10">توضیحات سایت</label>
                    <textarea rows="4" id="setting-webpage-description" name="setting_webpage_description" class="container-fluid"><?php echo get_option('setting_webpage_description'); ?></textarea>
                </div>
                
                
                <div class="padt-10 pad-b10">
                    <label for="setting-webpage-logo" class="show pad-b10">آدرس عکس لوگو</label>
                    <input type="url" id="setting-webpage-logo" name="setting_webpage_logo" class="container-fluid" value="<?php echo get_option('setting_webpage_logo'); ?>"/>
                </div>
                
                
                <div class="padt-10 pad-b10">
                    <label for="setting-webpage-analytics" class="show pad-b10">کد اسکریپت google analytics</label>
                    <textarea dir="ltr" rows="7" id="setting-webpage-analytics" name="setting_webpage_analytics" class="container-fluid"><?php echo get_option('setting_webpage_analytics'); ?></textarea>
                </div>
                
                
                <div class="padt-10 pad-b10">
                    <label for="setting-webpage-logo" class="show pad-b10">آدرس تلگرام</label>
                    <input type="url" id="setting-webpage-logo" name="setting_webpage_telegram" class="container-fluid" value="<?php echo get_option('setting_webpage_telegram'); ?>"/>
                </div>
                
                
                <div class="padt-10 pad-b10">
                    <label for="setting-webpage-logo" class="show pad-b10">آدرس اینستاگرام</label>
                    <input type="url" id="setting-webpage-logo" name="setting_webpage_instagram" class="container-fluid" value="<?php echo get_option('setting_webpage_instagram'); ?>"/>
                </div>
                
                
                <div class="padt-10 pad-b10">
                    <label for="setting-webpage-logo" class="show pad-b10">آدرس فیسبوک</label>
                    <input type="url" id="setting-webpage-logo" name="setting_webpage_facebook" class="container-fluid" value="<?php echo get_option('setting_webpage_facebook'); ?>"/>
                </div>
                
                
                <div class="padt-10 pad-b10">
                    <label for="setting-webpage-logo" class="show pad-b10">آدرس توییتر</label>
                    <input type="url" id="setting-webpage-logo" name="setting_webpage_twitter" class="container-fluid" value="<?php echo get_option('setting_webpage_twitter'); ?>"/>
                </div>
                                
                
                <div class="padt-10 pad-b10">
                    <label for="setting-webpage-logo" class="show pad-b10">آدرس گوگل پلاس</label>
                    <input type="url" id="setting-webpage-logo" name="setting_webpage_google" class="container-fluid" value="<?php echo get_option('setting_webpage_google'); ?>"/>
                </div>
                <div class="button-div">
                    <?php submit_button(); ?>
                </div>
            </form>
        </div>
    </div>
</div>

<?php }
add_action('admin_menu', 'rss_add_admin');
function rss_add_admin() {

    if( isset( $_REQUEST[ 'setting_webpage_keyword' ] ) ) {
        update_option( 'setting_webpage_keyword', $_REQUEST[ 'setting_webpage_keyword' ]  );
    }
    if( isset( $_REQUEST[ 'setting_webpage_description' ] ) ) {
        update_option( 'setting_webpage_description', $_REQUEST[ 'setting_webpage_description' ]  );
    }
    if( isset( $_REQUEST[ 'setting_webpage_logo' ] ) ) {
        update_option( 'setting_webpage_logo', $_REQUEST[ 'setting_webpage_logo' ]  );
    }
    if( isset( $_REQUEST[ 'setting_webpage_analytics' ] ) ) {
        update_option( 'setting_webpage_analytics', $_REQUEST[ 'setting_webpage_analytics' ]  );
    }
    if( isset( $_REQUEST[ 'setting_webpage_telegram' ] ) ) {
        update_option( 'setting_webpage_telegram', $_REQUEST[ 'setting_webpage_telegram' ]  );
    }
    if( isset( $_REQUEST[ 'setting_webpage_instagram' ] ) ) {
        update_option( 'setting_webpage_instagram', $_REQUEST[ 'setting_webpage_instagram' ]  );
    }
    if( isset( $_REQUEST[ 'setting_webpage_facebook' ] ) ) {
        update_option( 'setting_webpage_facebook', $_REQUEST[ 'setting_webpage_facebook' ]  );
    }
    if( isset( $_REQUEST[ 'setting_webpage_twitter' ] ) ) {
        update_option( 'setting_webpage_twitter', $_REQUEST[ 'setting_webpage_twitter' ]  );
    }
    if( isset( $_REQUEST[ 'setting_webpage_google' ] ) ) {
        update_option( 'setting_webpage_google', $_REQUEST[ 'setting_webpage_google' ]  );
    }
}