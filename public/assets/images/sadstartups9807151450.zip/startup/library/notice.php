<?php
add_action('admin_menu', 'add_user_menu_contact');
function add_user_menu_contact() {
	global $menu;
	$args_contact = array('numberposts' => -1, 'post_type' => 'contact','post_status' =>'pending');
	$count_contact = get_posts($args_contact);
	$count_contact = count($count_contact);
	if ($count_contact) {
		foreach ($menu as $key => $value) {
			if ($menu[$key][2] == 'edit.php?post_type=contact') {
				$menu[$key][0] .= '<span class="awaiting-mod"><span>' . $count_contact . '</span></span>';
				return;
			}
		}
	}
}