<?php
add_filter('show_admin_bar', '__return_false');
if ( ! isset( $content_width ) ) {
	$content_width = 600;
}

add_filter('admin_title', 'my_admin_title', 10, 2);

function my_admin_title($admin_title, $title)
{
	$title = 'Smart Web Solution';
    return get_bloginfo('name').' &bull; '.$title;
}

function my_apk_types($mime_types){
    $mime_types['apk'] = 'application/vnd.android.package-archive'; 
    return $mime_types;
}
add_filter('upload_mimes', 'my_apk_types', 1, 1);

function remove_footer_admin () {
	echo 'Designed by <a href="http://www.sws-co.ir" target="_blank">Smart Web Solution</a> ';

}
add_filter('admin_footer_text', 'remove_footer_admin');

function my_footer_shh() {
    remove_filter( 'update_footer', 'core_update_footer' ); 
}
add_action( 'admin_menu', 'my_footer_shh' );

function remove_wp_logo( $wp_admin_bar ) {
	$wp_admin_bar->remove_node( 'wp-logo' );
	$wp_admin_bar->remove_node( 'contextual-help-link-wrap' );
}
add_action( 'admin_bar_menu', 'remove_wp_logo', 999 );

remove_action( 'wp_head','rest_output_link_wp_head');
remove_action( 'wp_head','wp_oembed_add_discovery_links');
remove_action( 'template_redirect', 'rest_output_link_header', 11, 0 );
remove_action('wp_head', 'wp_resource_hints', 2);

add_action('wp_dashboard_setup', 'wpse_73561_remove_all_dashboard_meta_boxes', 9999 );

function wpse_73561_remove_all_dashboard_meta_boxes()
{
    global $wp_meta_boxes;
    $wp_meta_boxes['dashboard']['normal']['core'] = array();
    $wp_meta_boxes['dashboard']['side']['core'] = array();
}
remove_action('welcome_panel', 'wp_welcome_panel');
/* Change Link Gallery */
add_filter( 'shortcode_atts_gallery',
    function( $out ){
        $out['link'] = 'file'; 
        return $out;
    }
);

/* Login */
add_filter('login_headertitle', 'login_text', 112);
add_filter('login_headerurl', 'login_url', 111);
function login_url() {
    return home_url('url');
}

function login_text() {
    return __(get_bloginfo('name'), 'ztjalali', 'boonik');
}
/*
 * Remove website url from comment
 * */
add_filter('comment_form_default_fields', 'url_filtered');
function url_filtered($fields)
{
  if(isset($fields['url']))
   unset($fields['url']);
  return $fields;
}
if ( ! function_exists( 'sws_start_cleanup' ) ) :
	
/*--------------*/
function sws_start_cleanup() {

	// Launching operation cleanup.
	add_action( 'init', 'sws_cleanup_head' );

	// Remove WP version from RSS.
	add_filter( 'the_generator', 'sws_remove_rss_version' );

	// Remove pesky injected css for recent comments widget.
	add_filter( 'wp_head', 'sws_remove_wp_widget_recent_comments_style', 1 );

	// Clean up comment styles in the head.
	add_action( 'wp_head', 'sws_remove_recent_comments_style', 1 );
}
add_action( 'after_setup_theme','sws_start_cleanup' );
endif;
/**
 * Clean up head.+
 * ----------------------------------------------------------------------------
 */

if ( ! function_exists( 'sws_cleanup_head' ) ) :
function sws_cleanup_head() {

	// EditURI link.
	remove_action( 'wp_head', 'rsd_link' );

	// Category feed links.
	remove_action( 'wp_head', 'feed_links_extra', 3 );

	// Post and comment feed links.
	remove_action( 'wp_head', 'feed_links', 2 );

	// Windows Live Writer.
	remove_action( 'wp_head', 'wlwmanifest_link' );

	// Index link.
	remove_action( 'wp_head', 'index_rel_link' );

	// Previous link.
	remove_action( 'wp_head', 'parent_post_rel_link', 10, 0 );

	// Start link.
	remove_action( 'wp_head', 'start_post_rel_link', 10, 0 );

	// Canonical.
	remove_action( 'wp_head', 'rel_canonical', 10, 0 );

	// Shortlink.
	remove_action( 'wp_head', 'wp_shortlink_wp_head', 10, 0 );

	// Links for adjacent posts.
	remove_action( 'wp_head', 'adjacent_posts_rel_link_wp_head', 10, 0 );

	// WP version.
	remove_action( 'wp_head', 'wp_generator' );
	// Emoji detection script.
	remove_action( 'wp_head', 'print_emoji_detection_script', 7 );

	// Emoji styles.
	remove_action( 'wp_print_styles', 'print_emoji_styles' );

	// Remove WP version from css.
	add_filter( 'style_loader_src', 'sws_remove_wp_ver_css_js', 9999 );

	// Remove WP version from scripts.
	add_filter( 'script_loader_src', 'sws_remove_wp_ver_css_js', 9999 );

}
endif;

// Remove WP version from RSS.
if ( ! function_exists( 'sws_remove_rss_version' ) ) :
function sws_remove_rss_version() { return ''; }
endif;

if ( ! function_exists( 'sws_remove_wp_ver_css_js' ) ) :

// Remove WP version from scripts.
function sws_remove_wp_ver_css_js( $src ) {
	if ( strpos( $src, 'ver=' ) ) {
		$src = remove_query_arg( 'ver', $src ); }
	return $src;
}
endif;

// Remove injected CSS for recent comments widget.
if ( ! function_exists( 'sws_remove_wp_widget_recent_comments_style' ) ) :
function sws_remove_wp_widget_recent_comments_style() {
	if ( has_filter( 'wp_head', 'wp_widget_recent_comments_style' ) ) {
	  remove_filter( 'wp_head', 'wp_widget_recent_comments_style' );
	}
}
endif;

// Remove injected CSS from recent comments widget.
if ( ! function_exists( 'sws_remove_recent_comments_style' ) ) :
function sws_remove_recent_comments_style() {
	global $wp_widget_factory;
	if ( isset($wp_widget_factory->widgets['WP_Widget_Recent_Comments']) ) {
	remove_action( 'wp_head', array($wp_widget_factory->widgets['WP_Widget_Recent_Comments'], 'recent_comments_style') );
	}
}
endif;