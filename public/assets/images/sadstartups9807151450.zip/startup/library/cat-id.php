<?php
foreach (get_taxonomies() as $taxonomy) {
	add_action("manage_edit-${taxonomy}_columns", 'column_add');
	add_filter("manage_${taxonomy}_custom_column", 'column_return_value', 10, 3);
	add_filter("manage_edit-${taxonomy}_sortable_columns", 'column_add_clean');
}
function column_add($cols) {
	$cols['sws'] = '<abbr >' . __('کد') . '</abbr>';
	return $cols;
}

function column_add_clean($cols) {
	$cols['sws'] = __('ID');
	return $cols;
}

function column_return_value($value, $column_name, $id) {
	$value = $id;
	return $value;
}