<?php
function blog_register() {
	$labels = array(
		'name' => _x('بلاگ', 'post type general name', 'sws'),
		'singular_name' => _x('بلاگ', 'post type singular name', 'sws'),
		'add_new' => _x('افزودن مطلب', 'video item', 'sws'),
		'add_new_item' => __('افزودن مطلب', 'sws'),
		'edit_item' => __('ویرایش مطلب', 'sws'),
		'new_item' => __('مطلب جدید', 'sws'),
		'view_item' => __('نمایش مطلب', 'sws'),
		'search_items' => __('جستجوی مطلب', 'sws'),
		'not_found' =>  __('مطلبی پیدا نشد', 'sws'),
		'not_found_in_trash' => __('مطلبی  در سطل بازیافت نیست', 'sws'),
		'parent_item_colon' => ''
	);
	$args = array(
		'labels' => $labels,
		'public' => true, //if false doesnt have link
		'publicly_queryable' => true, //if false doesnt show in query 
		'show_ui' => true, //if true display a user-interface (admin panel) for this post type
		'query_var' => true, //If set to true it allows you to request a custom posts type (book) using this: example.com/?book=life-of-pi
		'rewrite' => true, // if set true it prevent to rewrite
		'capability_type' => 'post', //
		'hierarchical' => false, // if empty, 'name' is set to value of 'label', and 'singular_name' is set to value of 'name'.
		'supports' => array('title','thumbnail','excerpt','editor','comments','post-formats'),// Include [title,editor,author,thumbnail,excerpt,trackbacks,custom-fields,comments,revisions,post-formats] 
		'menu_position' => 8, // postition in admin panel menu]
		'menu_icon' => 'dashicons-welcome-write-blog', //icon of post type
        'has_archive' => true //Enables post type archives
	); 
	register_post_type( 'blog' , $args );
}
add_action('init', 'blog_register');
function advisor_register() {
	$labels = array(
		'name' => _x('مشاوران', 'post type general name', 'sws'),
		'singular_name' => _x('مشاوران', 'post type singular name', 'sws'),
		'add_new' => _x('افزودن مشاوران', 'video item', 'sws'),
		'add_new_item' => __('افزودن مشاوران', 'sws'),
		'edit_item' => __('ویرایش مشاوران', 'sws'),
		'new_item' => __('مشاور جدید', 'sws'),
		'view_item' => __('نمایش مشاوران', 'sws'),
		'search_items' => __('جستجوی مشاوران', 'sws'),
		'not_found' =>  __('مطلبی پیدا نشد', 'sws'),
		'not_found_in_trash' => __('مطلبی  در سطل بازیافت نیست', 'sws'),
		'parent_item_colon' => ''
	);
	$args = array(
		'labels' => $labels,
		'public' => true, //if false doesnt have link
		'publicly_queryable' => false, //if false doesnt show in query 
		'show_ui' => true, //if true display a user-interface (admin panel) for this post type
		'query_var' => true, //If set to true it allows you to request a custom posts type (book) using this: example.com/?book=life-of-pi
		'rewrite' => true, // if set true it prevent to rewrite
		'capability_type' => 'post', //
		'hierarchical' => false, // if empty, 'name' is set to value of 'label', and 'singular_name' is set to value of 'name'.
		'supports' => array('title','thumbnail','excerpt'),// Include [title,editor,author,thumbnail,excerpt,trackbacks,custom-fields,comments,revisions,post-formats] 
		'menu_position' => 8, // postition in admin panel menu]
		'menu_icon' => 'dashicons-businessperson', //icon of post type
        'has_archive' => true //Enables post type archives
	); 
	register_post_type( 'advisor' , $args );
}
add_action('init', 'advisor_register');

function Referee_register() {
	$labels = array(
		'name' => _x('داور', 'post type general name', 'sws'),
		'singular_name' => _x('داور', 'post type singular name', 'sws'),
		'add_new' => _x('افزودن داور', 'video item', 'sws'),
		'add_new_item' => __('افزودن داور', 'sws'),
		'edit_item' => __('ویرایش داور', 'sws'),
		'new_item' => __('داور جدید', 'sws'),
		'view_item' => __('نمایش داور', 'sws'),
		'search_items' => __('جستجوی داور', 'sws'),
		'not_found' =>  __('مطلبی پیدا نشد', 'sws'),
		'not_found_in_trash' => __('مطلبی  در سطل بازیافت نیست', 'sws'),
		'parent_item_colon' => ''
	);
	$args = array(
		'labels' => $labels,
		'public' => true, //if false doesnt have link
		'publicly_queryable' => false, //if false doesnt show in query 
		'show_ui' => true, //if true display a user-interface (admin panel) for this post type
		'query_var' => true, //If set to true it allows you to request a custom posts type (book) using this: example.com/?book=life-of-pi
		'rewrite' => true, // if set true it prevent to rewrite
		'capability_type' => 'post', //
		'hierarchical' => false, // if empty, 'name' is set to value of 'label', and 'singular_name' is set to value of 'name'.
		'supports' => array('title','thumbnail','excerpt'),// Include [title,editor,author,thumbnail,excerpt,trackbacks,custom-fields,comments,revisions,post-formats] 
		'menu_position' => 8, // postition in admin panel menu]
		'menu_icon' => 'dashicons-id', //icon of post type
        'has_archive' => true //Enables post type archives
	); 
	register_post_type( 'Referee' , $args );
}
add_action('init', 'Referee_register');


function support_register() {
	$labels = array(
		'name' => _x('حامیان', 'post type general name', 'sws'),
		'singular_name' => _x('حامیان', 'post type singular name', 'sws'),
		'add_new' => _x('افزودن حامی', 'video item', 'sws'),
		'add_new_item' => __('افزودن حامی', 'sws'),
		'edit_item' => __('ویرایش حامی', 'sws'),
		'new_item' => __('حامی جدید', 'sws'),
		'view_item' => __('نمایش حامی', 'sws'),
		'search_items' => __('جستجوی حامی', 'sws'),
		'not_found' =>  __('مطلبی پیدا نشد', 'sws'),
		'not_found_in_trash' => __('مطلبی  در سطل بازیافت نیست', 'sws'),
		'parent_item_colon' => ''
	);
	$args = array(
		'labels' => $labels,
		'public' => true, //if false doesnt have link
		'publicly_queryable' => false, //if false doesnt show in query 
		'show_ui' => true, //if true display a user-interface (admin panel) for this post type
		'query_var' => true, //If set to true it allows you to request a custom posts type (book) using this: example.com/?book=life-of-pi
		'rewrite' => true, // if set true it prevent to rewrite
		'capability_type' => 'post', //
		'hierarchical' => false, // if empty, 'name' is set to value of 'label', and 'singular_name' is set to value of 'name'.
		'supports' => array('title','thumbnail','excerpt'),// Include [title,editor,author,thumbnail,excerpt,trackbacks,custom-fields,comments,revisions,post-formats] 
		'menu_position' => 8, // postition in admin panel menu]
		'menu_icon' => 'dashicons-groups', //icon of post type
        'has_archive' => true //Enables post type archives
	); 
	register_post_type( 'support' , $args );
}
add_action('init', 'support_register');

function contact_register() {
	$labels = array(
		'name' => _x('ارتباط با ما', 'post type general name', 'sws'),
		'singular_name' => _x('ارتباط با ما', 'post type singular name', 'sws'),
		'add_new' => _x('افزودن ارتباط با ما', 'video item', 'sws'),
		'add_new_item' => __('افزودن ارتباط با ما', 'sws'),
		'edit_item' => __('ویرایش ارتباط با ما', 'sws'),
		'new_item' => __('ارتباط با ما جدید', 'sws'),
		'view_item' => __('نمایش ارتباط با ما', 'sws'),
		'search_items' => __('جستجوی ارتباط با ما', 'sws'),
		'not_found' =>  __('مطلبی پیدا نشد', 'sws'),
		'not_found_in_trash' => __('مطلبی  در سطل بازیافت نیست', 'sws'),
		'parent_item_colon' => ''
	);
	$args = array(
		'labels' => $labels,
		'public' => true, //if false doesnt have link
		'publicly_queryable' => false, //if false doesnt show in query 
		'show_ui' => true, //if true display a user-interface (admin panel) for this post type
		'query_var' => true, //If set to true it allows you to request a custom posts type (book) using this: example.com/?book=life-of-pi
		'rewrite' => true, // if set true it prevent to rewrite
		'capability_type' => 'post', //
		'hierarchical' => false, // if empty, 'name' is set to value of 'label', and 'singular_name' is set to value of 'name'.
		'supports' => array('title','editor','thumbnail','excerpt'),// Include [title,editor,author,thumbnail,excerpt,trackbacks,custom-fields,comments,revisions,post-formats] 
		'menu_position' => 8, // postition in admin panel menu]
		'menu_icon' => 'dashicons-groups', //icon of post type
        'has_archive' => true //Enables post type archives
	); 
	register_post_type( 'contactus' , $args );
}
add_action('init', 'contact_register');


function request_money() {
        $labels = array(
            'name' => _x('درخواست ها', 'post type general name', 'sws'),
            'singular_name' => _x('درخواست ها', 'post type singular name', 'sws'),
            'add_new' => _x('افزودن درخواست', 'video item', 'sws'),
            'add_new_item' => __('افزودن درخواست', 'sws'),
            'edit_item' => __('ویرایش درخواست', 'sws'),
            'new_item' => __('درخواست جدید', 'sws'),
            'view_item' => __('نمایش درخواست', 'sws'),
            'search_items' => __('جستجوی درخواست', 'sws'),
            'not_found' =>  __('مطلبی پیدا نشد', 'sws'),
            'not_found_in_trash' => __('مطلبی  در سطل بازیافت نیست', 'sws'),
            'parent_item_colon' => ''
        );
        $args = array(
            'labels' => $labels,
            'public' => true, //if false doesnt have link
            'publicly_queryable' => true, //if false doesnt show in query
            'show_ui' => true, //if true display a user-interface (admin panel) for this post type
            'query_var' => true, //If set to true it allows you to request a custom posts type (book) using this: example.com/?book=life-of-pi
            'rewrite' => true, // if set true it prevent to rewrite
            'capability_type' => 'post', //
            'hierarchical' => false, // if empty, 'name' is set to value of 'label', and 'singular_name' is set to value of 'name'.
            'supports' => array('title','thumbnail','excerpt','custom-fields','author'),// Include [title,editor,author,thumbnail,excerpt,trackbacks,custom-fields,comments,revisions,post-formats]
            'menu_position' => 8, // postition in admin panel menu]
            'menu_icon' => 'dashicons-groups', //icon of post type
            'has_archive' => true //Enables post type archives
        );
        register_post_type( 'requestmoney' , $args );
    }
    add_action('init', 'request_money');

