<?php
/*
function education_taxonomy() {

	$labels = array(
		'name'                       => _x( 'تحصیلات', 'Taxonomy General Name', 'sws' ),
		'singular_name'              => _x( 'تحصیلات', 'Taxonomy Singular Name', 'sws' ),
		'menu_name'                  => __( 'تحصیلات', 'sws' ),
		'all_items'                  => __( 'تحصیلات', 'sws' ),
	);
	$args = array(
		'labels'                     => $labels,
		'hierarchical'               => true,
		'public'                     => true,
		'show_ui'                    => true,
		'show_admin_column'          => true,
		'show_in_nav_menus'          => true,
		'show_tagcloud'              => true,
		'rewrite'           => array( 'slug' => 'education' )
	);
	register_taxonomy( 'education', array( 'post' ), $args );

}
add_action( 'init', 'education_taxonomy', 0 );
*/