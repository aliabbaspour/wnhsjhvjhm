<?php
if ( ! function_exists( 'sws_sidebar_widgets' ) ) :
function sws_sidebar_widgets() {
 register_sidebar( array(
	    'name' => __( 'Main Sidebar', 'sws' ),
	    'id' => 'sidebar-1',
	    'description' => __( 'Widgets in this area will be shown on all posts and pages.', 'sws' ),
	    'before_widget' => '<li id="%1$s" class="widget %2$s">',
		'after_widget'  => '</li>',
		'before_title'  => '<h2 class="widgettitle">',
		'after_title'   => '</h2>',
    ));
}

add_action( 'widgets_init', 'sws_sidebar_widgets' );
endif;