<?php
function redirect_users_by_role() {
    if ( is_super_admin() ) {
    	
    }else{
    	wp_redirect( home_url('') );
    }
} 
add_action( 'admin_init', 'redirect_users_by_role' );

add_action('wp_logout','ps_redirect_after_logout');
function ps_redirect_after_logout(){
	if(is_page( 'chenge-password' )){
		wp_redirect( '/login/?message=alert' );
		exit();
	}
}