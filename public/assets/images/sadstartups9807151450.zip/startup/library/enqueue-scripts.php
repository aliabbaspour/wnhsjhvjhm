<?php
if (!function_exists('sws_scripts')) :
	function sws_scripts() {
		wp_enqueue_style('dropzone-min-css', get_stylesheet_directory_uri() . '/assets/stylesheets/dropzone.min.css');
        wp_enqueue_style('slick', get_stylesheet_directory_uri() . '/assets/stylesheets/slick.css');
        wp_enqueue_style('slick-theme', get_stylesheet_directory_uri() . '/assets/stylesheets/slick-theme.css');
        wp_enqueue_style('chartist.min', get_stylesheet_directory_uri() . '/assets/stylesheets/chartist.min.css');
        wp_enqueue_style('persian-datepicker-theme', get_stylesheet_directory_uri() . '/assets/stylesheets/persian-datepicker.css');
        wp_enqueue_style('iccon.css', get_stylesheet_directory_uri() . '/assets/stylesheets/icon.css');
        wp_enqueue_style('dashboard.css', get_stylesheet_directory_uri() . '/assets/stylesheets/dashboard.css');
        wp_enqueue_style('custom-stylesheet', get_stylesheet_directory_uri() . '/assets/stylesheets/style.css');
        wp_enqueue_style('responsive', get_stylesheet_directory_uri() . '/assets/stylesheets/responsive.css');

        wp_dequeue_script('jquery');
		wp_dequeue_script('jquery-core');
		wp_dequeue_script('jquery-migrate');
		wp_enqueue_script('jquery', false, array(), false, true);
		wp_enqueue_script('jquery-core', false, array(), false, true);
		wp_enqueue_script('jquery-migrate', false, array(), false, true);
		if ( is_singular() ) wp_enqueue_script( "comment-reply" );
		wp_enqueue_script('dropzone.min.js', get_template_directory_uri() . '/assets/javascript/dropzone.min.js', array(), '1.0.0', true);
		wp_enqueue_script('jquery.validate.min', get_template_directory_uri() . '/assets/javascript/jquery.validate.min.js', array(), '1.0.0', true);
		wp_enqueue_script('additional-methods.min', get_template_directory_uri() . '/assets/javascript/additional-methods.min.js', array(), '1.0.0', true);
		wp_enqueue_script('jquery-validate', get_template_directory_uri() . '/assets/javascript/validate.js', array(), '1.0.0', true);
		
		wp_enqueue_script('chartist.min.js', get_template_directory_uri() . '/assets/javascript/chartist.min.js', array(), '1.0.0', true);

		wp_enqueue_script('jquery-persian-date', get_template_directory_uri() . '/assets/javascript/persian-date.min.js', array(), '1.0.0', true);
		wp_enqueue_script('jquery-persian-datepicker', get_template_directory_uri() . '/assets/javascript/persian-datepicker.min.js', array(), '1.0.0', true);
		wp_enqueue_script( 'address', get_template_directory_uri() . '/assets/javascript/address.js', array(), '1.0.0', true );
		wp_enqueue_script('wow.min', get_template_directory_uri() . '/assets/javascript/wow.min.js', array(), '1.0.0', true);
		wp_enqueue_script( 'my-admin-java', get_template_directory_uri() . '/assets/javascript/admin.js', array(), '2.2.0', true);
		wp_enqueue_script('script', get_template_directory_uri() . '/assets/javascript/script.js', array(), '1.0.0', true);
		wp_enqueue_script('slick.min', get_template_directory_uri() . '/assets/javascript/slick.min.js', array(), '1.0.0', true);

	}

	add_action('wp_enqueue_scripts', 'sws_scripts');
endif;
function my_login_stylesheet() {
	wp_enqueue_style('custom-login', get_template_directory_uri() . '/assets/stylesheets/login.css');
}

add_action('login_enqueue_scripts', 'my_login_stylesheet');

function my_admin_theme_style() {
    wp_enqueue_style('my-admin-css', get_template_directory_uri().'/assets/stylesheets/admin.css');
	
	
}
add_action('admin_enqueue_scripts', 'my_admin_theme_style');