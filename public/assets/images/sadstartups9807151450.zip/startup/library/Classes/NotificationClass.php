<?php
	class Notification
	{
		public $currentUser;
		public $currentUserId;
		public $targetUser;

		public function __construct()
		{
			$this->currentUser = get_current_user();
			$this->currentUserId = get_current_user_id();
		}

		public function getNotify()
		{
			$query = array(
					'query'=> array(
							array(
									'key'=>'user_id',
									'value'=> $this->currentUserId,
									'compare'=>'='
							)
					)
			);
			$data = query_data('notifiction',$query);
			return $data;
		}

		public function setNotify($reciverId , $messageId , $status = NULL)
		{
			$date = current_time( 'mysql' );
			$data = array(
					"user_id" => $this->currentUserId,
					"receiver_id" => $reciverId,
					"message_id"  =>  $messageId,
					"date" => $date,
					"status"  => $status
			);


				$id = insert_data('notifiction' , $data);

				return $id;
		}


	}

?>