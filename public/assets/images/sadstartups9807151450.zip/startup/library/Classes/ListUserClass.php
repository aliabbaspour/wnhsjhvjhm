	<?php
	class list_users
	{
	    public $currentUser;
	    public $currentuUserId;
	    public function __construct(){

		 $this->currentUser = wp_get_current_user();
		 $this->currentuUserId =  $this->currentUser->ID;

	    }

        public function startups($allowdRole  ,$metaQuery = NULL ,$number )
		{

			?>
        <table class="table color6 retable">
            <thead>
            <tr>
                <th>ردیف</th>
                <th>نام استارتاپ</th>
                <th>نام نماینده</th>
                <th>ایمیل</th>
                <th>موبایل</th>
                <th class="date-icon relative">زمان ثبت نام</th>
                <th class="center">وضعیت</th>
                <th class="center">عملیات</th>
<!--                <th class="center">پروفایل</th>-->
                <th class="center">ارسال پیام</th>
            </tr>
            </thead>
            <tbody>
						<?php

				        if(array_intersect($allowdRole, $this->currentUser->roles)) {
									        $args = array(
												'number' => $number,
										        'role__in' =>  array('subscriber') ,
												'meta_query' => $metaQuery,
												'order' => 'DESC',
									        );
									        $resultUser = get_users($args);
				        }

							$i = 1;
							if( ! empty($resultUser)) {
								foreach($resultUser as $user) {
									//								print_r($user);
									$user_id = $user->ID;
									$user_login = $user->user_login;
									$role = $user->roles[0];
									$firstname = get_user_meta($user_id , 'first_name' , TRUE);
									$lastname = get_user_meta($user_id , 'last_name' , TRUE);
									$mobile = get_user_meta($user_id , 'mobile' , TRUE);
									$expertise = get_user_meta($user_id , 'expertise' , TRUE);
									$status = get_user_meta($user_id , 'status' , TRUE);
							        $steps = get_user_meta($user_id , 'steps' , TRUE);
								    $website = get_user_meta($user_id , 'website' , TRUE);
							        $startupName = get_user_meta($user_id , 'startup_name' , TRUE);
									if($firstname && $lastname ) {
									    $name = $firstname . ' ' . $lastname;
									}else{
									    $name =  '--------';
                                    }
								    $email = $user->user_email;

									?>
                    <tr class="<?php echo $class; ?>">
                        <td class="iransansdigit"><?php echo $i++; ?></td>
						<?php
							if (!empty($website) &&  !preg_match("~^(?:f|ht)tps?://~i", $website)) {
								$website = "http://" . $website;
							}
						?>
					    <td>
						    <?= empty($website) ? '' : '<a class="color-blue" href="'.$website.'" target="_blank">
									<i class="fa fa-globe pad-l10"></i>
								</a>';  ?>
                          <?= empty($startupName) ? '--------' : $startupName; ?>
						</td>
                        <td><?php echo $name; ?></td>
                        <td><?= empty($email) ? '--------' : $email; ?></td>
                        <td><?php echo $mobile; ?></td>
                        <td><?php echo jdate('Y/m/d' , $user->user_registered) ?></td>
                        <td class="center">
						<?php action_list_startups($user_id) ?>
                        </td>
                        <td class="center">
                            <a class="color-silver" title="نمایش"
                               href="<?php echo home_url("/information/$user_id"); ?>">
                                <i class="font-s20 fa fa-id-card"></i>
                            </a>
                        </td>
                        <td class="center">
                            <a class="color-silver" title="نمایش"
                               href="<?php echo home_url("/send-message/$user_id"); ?>">
                                <i class="font-s20 fa fa-envelope"></i>
                            </a>
                        </td>
                    </tr>
									<?php
								}
								wp_reset_query();
							}
						?>
            </tbody>
        </table>
			<?php
		}

		public function referee($allowdRole ,$number )
        {
            ?>
            <table class="table color6 retable">
                <thead>
                <tr>
                    <th>ردیف</th>
                    <th>نام و نام خانوادگی</th>
                    <th>ایمیل</th>
                    <th>موبایل</th>
                    <!--<th class="center">وضعیت</th>-->
                    <th class="center">ارسال پیام</th>

                </tr>
                </thead>
                <tbody>
        <?php

	        if(array_intersect($allowdRole, $this->currentUser->roles)) {
			        $args=array(
							'number' => $number,
					        'meta_query' => array(
							        array(
									        'key'     => 'roles',
									        'value'   => serialize(strval('referee')),
									        'compare' => 'LIKE',
							        )
					        ),
					        'orderby' => 'ID',
					        'order' => 'DESC',
			        );
			        $user_query = new WP_User_Query($args);
	        }


						$i=1;
						if ( ! empty( $user_query->get_results() ) ) {
							foreach ( $user_query->get_results() as $user ) {
							//	print_r($user);
							$user_id 	= $user->ID;
							$user_login	= $user->user_login;
							$role 		= $user->roles[0];
							$firstname  = get_user_meta($user_id,'first_name',true);
	    					$lastname   = get_user_meta($user_id,'last_name',true);
	    					$mobile   = get_user_meta($user_id,'mobile',true);
							$dabir_ok = get_user_meta($user_id,'dabir_ok',true);
							if($firstname && $lastname ) {
								$name = $firstname . ' ' . $lastname;
							}else{
								$name =  '--------';
							}
						?>
        <tr>
            <td class="iransansdigit"><?php echo $i++; ?></td>
            <td><?=  $name; ?></td>
            <td><?php echo $user->user_email; ?></td>
            <td><?= empty($mobile) ? '--------' : $mobile;  ?></td>
            <!--<td class="center">
                <a class="color-silver" title="نمایش" href="<?php echo home_url("/information/$user_id") ?>"
                	<span>
						<i class="align-center font-s20 fa fa-address-card"></i>
					</span>
                </a>
            </td>-->
            <td class="center">
                <a class="color-silver" title="نمایش" href="<?php echo home_url("/send-message/$user_id");  ?>" >
					<span>
						<i class="font-s20 fa fa-envelope"></i>
					</span>
                </a>
            </td>
        </tr>
        <?php
        }wp_reset_query();
        }
        ?>
                </tbody>
            </table>
<?php


		}

        public function investor($allowdRole ,$number )
			{
				?>
          <table class="table color6 retable">
              <thead>
              <tr>
                  <th>ردیف</th>
                  <th>نام و نام خانوادگی</th>
                  <th>ایمیل</th>
                  <th>موبایل</th>
                  <!--<th class="center">وضعیت</th>-->
                  <th class="center">ارسال پیام</th>

              </tr>
              </thead>
              <tbody>
							<?php

								if(array_intersect($allowdRole, $this->currentUser->roles)) {
									$args=array(
											'number' => $number,
											'meta_query' => array(
													array(
															'key'     => 'roles',
															'value'   => serialize(strval('investor')),
															'compare' => 'LIKE',
													)
											),
											'orderby' => 'ID',
											'order' => 'DESC',
									);
									$user_query = new WP_User_Query($args);
								}


								$i=1;
								if ( ! empty( $user_query->get_results() ) ) {
									foreach ( $user_query->get_results() as $user ) {
										//	print_r($user);
										$user_id 	= $user->ID;
										$user_login	= $user->user_login;
										$role 		= $user->roles[0];
										$firstname  = get_user_meta($user_id,'first_name',true);
										$lastname   = get_user_meta($user_id,'last_name',true);
										$mobile   = get_user_meta($user_id,'mobile',true);
										$dabir_ok = get_user_meta($user_id,'dabir_ok',true);
										if($firstname && $lastname ) {
											$name = $firstname . ' ' . $lastname;
										}else{
											$name =  '--------';
										}
										?>
                      <tr>
                          <td class="iransansdigit"><?php echo $i++; ?></td>
                          <td><?=  $name; ?></td>
                          <td><?php echo $user->user_email; ?></td>
                          <td><?= empty($mobile) ? '--------' : $mobile;  ?></td>
                          <!--<td class="center">
                              <a class="color-silver" title="نمایش" href="<?php echo home_url("/information/$user_id") ?>"
                              <span>
										<i class="align-center font-s20 fa fa-address-card"></i>
									</span>
                              </a>
                          </td>-->
                          <td class="center">
                              <a class="color-silver" title="نمایش" href="<?php echo home_url("/send-message/$user_id");  ?>" >
                                     <span>
                                         <i class="font-s20 fa fa-envelope"></i>
                                     </span>
                              </a>
                          </td>
                      </tr>
										<?php
									}wp_reset_query();
								}
							?>
              </tbody>
          </table>
				<?php


			}

        public function coach($allowdRole ,$number )
			{
				?>
          <table class="table color6 retable">
              <thead>
              <tr>
                  <th>ردیف</th>
                  <th>نام و نام خانوادگی</th>
                  <th>ایمیل</th>
                  <th>موبایل</th>
                 <!-- <th class="center">وضعیت</th>-->
                  <th class="center">ارسال پیام</th>

              </tr>
              </thead>
              <tbody>
							<?php

								if(array_intersect($allowdRole, $this->currentUser->roles)) {
									$args=array(
											'number' => $number,
											'meta_query' => array(
													array(
															'key'     => 'coach',
															'value'   => serialize(strval('investor')),
															'compare' => 'LIKE',
													)
											),
											'orderby' => 'ID',
											'order' => 'DESC',
									);
									$user_query = new WP_User_Query($args);
								}


								$i=1;
								if ( ! empty( $user_query->get_results() ) ) {
									foreach ( $user_query->get_results() as $user ) {
										//	print_r($user);
										$user_id 	= $user->ID;
										$user_login	= $user->user_login;
										$role 		= $user->roles[0];
										$firstname  = get_user_meta($user_id,'first_name',true);
										$lastname   = get_user_meta($user_id,'last_name',true);
										$mobile   = get_user_meta($user_id,'mobile',true);
										$dabir_ok = get_user_meta($user_id,'dabir_ok',true);
										if($firstname && $lastname ) {
											$name = $firstname . ' ' . $lastname;
										}else{
											$name =  '--------';
										}
										?>
                      <tr>
                          <td class="iransansdigit"><?php echo $i++; ?></td>
                          <td><?=  $name; ?></td>
                          <td><?php echo $user->user_email; ?></td>
                          <td><?= empty($mobile) ? '--------' : $mobile;  ?></td>
                          <!--<td class="center">
                              <a class="color-silver" title="نمایش" href="<?php echo home_url("/information/$user_id") ?>"
                              <span>
										<i class="align-center font-s20 fa fa-address-card"></i>
									</span>
                              </a>
                          </td>-->
                          <td class="center">
                              <a class="color-silver" title="نمایش" href="<?php echo home_url("/send-message/$user_id");  ?>" >
                                     <span>
                                         <i class="font-s20 fa fa-envelope"></i>
                                     </span>
                              </a>
                          </td>
                      </tr>
										<?php
									}wp_reset_query();
								}
							?>
              </tbody>
          </table>
				<?php


			}
	}

	?>