<?php
function admin_init(){
	global $current_user;
	//add_meta_box("post_meta", "اطلاعات", "post_meta", array("post"), "normal", "high");
}
add_action("admin_init", "admin_init");
/*
function post_meta() {
	global $post;
	$details =get_post_meta($post->ID,'donate_details',true);
	// Use nonce for verification
	?>
	<div>
		<?php print_r($details)?>
	</div>
	<?php
}
*/
function save_details($post_id){
	global $post;
	
	if ( defined('DOING_AUTOSAVE') && DOING_AUTOSAVE ) 
		return $post_id;
	//if (isset($_POST["link"])) update_post_meta($post->ID, "link", $_POST["link"]);
}
add_action('save_post', 'save_details'); 