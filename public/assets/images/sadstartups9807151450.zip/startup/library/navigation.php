<?php
register_nav_menus(array(
	'main-menu' => 'Main Menu',
	'dashboard' => 'dashboard',
	'admin-menu' => 'Admin Menu',
));