<?php
function modify_contact_methods($profile_fields) {
	$profile_fields['mobile'] = 'موبایل';
	return $profile_fields;
}
add_filter('user_contactmethods', 'modify_contact_methods');

add_filter( 'manage_users_columns', 'rudr_modify_user_table' );
function rudr_modify_user_table( $columns ) {
	// unset( $columns['posts'] ); // maybe you would like to remove default columns
	$columns['registration_date'] = 'تاریخ ثبت نام'; // add new
	$columns['mobile'] = 'موبایل';
	return $columns;
}
 
add_filter( 'manage_users_custom_column', 'rudr_modify_user_table_row', 10, 3 );
function rudr_modify_user_table_row( $row_output, $column_id_attr, $user ) {
	$date_format = 'Y/m/j H:i';
	switch ( $column_id_attr ) {
		case 'registration_date' :
			return jdate( $date_format, strtotime( get_the_author_meta( 'registered', $user ) ) );
			break;
		case 'mobile' :
			return get_the_author_meta( 'mobile', $user );
			break;
		default:
	}
 
	return $row_output;
}
add_filter( 'manage_users_sortable_columns', 'rudr_make_registered_column_sortable' );
function rudr_make_registered_column_sortable( $columns ) {
	return wp_parse_args( array( 'registration_date' => 'registered' ), $columns );
}