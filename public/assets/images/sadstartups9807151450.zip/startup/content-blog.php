<div class="container-fluid">
	<div class="container">
		<div class="pad-20">
			<div class="colm3 colm pull-left">
				<div class="secction-blog-title spacer-t5">
					<a href="<?php echo home_url('/blog') ?>">
					<h3 class="font-s35 bold color-white align-center pad-10 bg-purple">
							مقاله و اطلاعیه ها
					</h3>
					</a>
				</div>
			</div>
			<div class="colm9 colm pull-left ">
				<div>
					<?php $args = array( 'post_type' => 'blog' , 'showposts' => 3 ) ?>
					<?php query_posts($args) ?>
					<?php while(have_posts()):the_post() ?>
						<?php get_template_part('loop','blog');?>
					<?php endwhile;wp_reset_query() ?>
					<div class="clearfix"></div>
				</div>
			</div>
			<div class="clearfix"></div>
		</div>	
	</div>
</div>