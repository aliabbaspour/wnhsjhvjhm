<style>
.bg-pop{
 background-image:	linear-gradient(#43388b, #eeeeee)
}
.bg-contact-us{
	background: linear-gradient(#e74778bf, #5649ad);
}
.color-gray{
	color: #e9e9e9
}
.ab-contact{
	top: 25px;
    right: 50px;
}
.box-shaddow-contact {
    box-shadow: 1px 1px 5px 1px #767676;
}
.gui-input::placeholder {
	font-size: 14px;
}
.contact textarea::placeholder {
	font-size: 14px;
    color: #747474;
}
</style>
<div class="container-fluid bg-contact-us">
		<div class="colm colm6 pull-right pad-15">
			<div class="align-center">
				<span class="bold font-s25 color-white show">ارتباط با ما</span>
				<span class="font-s15 color-gray show">راه های ارتباطی شما با صد استارت آپ</span>
			</div>
			<form method="post" class="smart-validate">
				<div class="frm-row spacer-t15">
					<div class="colm6 colm pad-5 pull-right">
						<!---<label for="first_name" class="gui-label color-white"> نام و نام خانوادگی:</label>--->
						<label>
							<input class="gui-input iransans valid" type="text" name="first_name" id="first_name" placeholder="نام و نام خانوادگی" required="">
						</label>
					</div>
					<div class="colm6 colm pad-5 pull-right">
						<!----<label for="email" class="gui-label color-white">ایمیل :</label>--->
						<label>
							<input class="gui-input iransans valid" type="email" name="email" id="email" placeholder="ایمیل"  required="" >
						</label>
					</div>
					<div class="clearfix"></div>
				</div>
				<div class="frm-row pad-t10">
					<div class="pad-5">
					<!--<label for="description" class="color-white gui-label ">توضیحات :</label>-->
						<label>
							<textarea id="description" name="description" class="gui-textarea" placeholder="توضیحات" rows="6"></textarea>
						</label>
					</div>
				</div>
				<div>
					<div class="pad-5 align-center spacer-t10">
		     			<button type="submit" name="submit_contact" class="colm2 colm btn-web pointer">ثبت</button>
					</div>
				</div>
			</form>
		</div>
		<div class="colm colm6 pull-right align-left">

			<div class="map">
				<img width="80%" src="<?php bloginfo('template_url') ?>/assets/images/map.png" alt="map" />
			</div>
	   </div>
		<div class="clearfix"></div>
</div>
<?php if($_GET['sent']==1):?>
<div class="message-producer pad-20 spacer-b25 color2 align-center message-css">
    <div class="wpulike-notification msg-profile">
    	<div class="wpulike-message wpulike-success">درخواست شما با موفقیت ارسال شد.</div>
	</div>
</div>
<?php endif ?>