<div class="container-fluid bg-purple">
	<div class="container pad-40">
		<div class="colm8 colm pull-right">
			<h3 class="font-s30 color-white align-center">برای حضور در رقابت داغ تابستان استارتاپی و برخورداری از خدمات ۱۰۰ استارتاپ همین حالا اقدام کنید.</h3>
		</div>
		<div class="colm4 colm pull-right pad-10">
			<div class="btn-register sendplan">
				<a class="color-white font-s25 bold" href="<?php echo home_url('register') ?>">ارسال طرح و ایده</a>
			</div>
		</div>
		<div class="clearfix"></div>
	</div>
</div>