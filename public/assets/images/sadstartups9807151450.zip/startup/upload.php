<?php // Template Name: Upload
session_start();
if(isset($_POST['file_type'])){
	$user_id = $_POST['user_id'];
	$file_type = $_POST['file_type'] ;
	require_once( ABSPATH . 'wp-admin/includes/image.php' );
	require_once( ABSPATH . 'wp-admin/includes/file.php' );
	require_once( ABSPATH . 'wp-admin/includes/media.php' );
	if($file_type == 'video'){
		$video_id = media_handle_upload('video', $user_id);
		if ( !is_wp_error( $video_id ) ) {
			update_user_meta($user_id,'video',$video_id);
		}
	}
	if($file_type == 'pdf'){
		$pdf_id = media_handle_upload('pdf', $user_id);
		if ( !is_wp_error( $pdf_id ) ) {
			update_user_meta($user_id,'pdf',$pdf_id);
		}
	}

}
