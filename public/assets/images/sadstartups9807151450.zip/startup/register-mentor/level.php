<?php
$page = $post->post_name;
$stepm = (isset($_GET['stepm'])) ? $_GET['stepm']:'' ;
if($page == 'authentication' || $stepm == 2){
	$stepm = 2 ;
}elseif($page == 'send-number' || $stepm == 3){
	$stepm = 3 ;
}elseif($page == 'validation' || $stepm == 4){
	$stepm = 4 ;
}elseif($page == 'complete-form' || $stepm == 5){
	$stepm = 5 ;
}elseif($page == 'final' || $stepm == 6){
	$stepm = 6 ;
}else{
	$stepm = 1 ;
}
?>
<div id="stepms">
    <ul>
        <li><div class="step <?php echo ($stepm == 1 )?"active":''; ?>" data-desc="ارسال شناسه" align="">1</div></li>
        <li><div class="step <?php echo ($stepm == 2 )?"active":''; ?>" data-desc="احراز هویت" align="">2</div></li>
        <li><div class="step <?php echo ($stepm == 3 )?"active":''; ?>" data-desc="ارسال شماره" align="">3</div></li>
        <li><div class="step <?php echo ($stepm == 4 )?"active":''; ?>" data-desc="اعتبار سنجی" align="">4</div></li>
        <li><div class="step <?php echo ($stepm == 5 )?"active":''; ?>" data-desc="تکمیل اطلاعات" align="">5</div></li>
        <li><div class="step <?php echo ($stepm == 6 )?"active":''; ?>" data-desc="تایید نهایی" align="">6</div></li>
    </ul>
</div>