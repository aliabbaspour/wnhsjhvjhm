<?php /* Template Name: final  */?>
<?php get_header();?>
<style>
header , footer,.mobile {
	display: none;
}
.hide-tab{
	display:none;
}
.hide-tab{
	display: none;
}
</style>
<div id="section-step" class="container-fluide bg-gray">
	<div class="container pad-20 pad-step pad-50-tmob  min-100vh flex-center">
		<div id="section-step-content" class="colm8 colm10-tab colm margin-auto pad-40 pad-20-tab pad-10-mob bg-white spacer-t40 spacer-b40">
			<div class="colm8 colm11-tab colm margin-auto pad-5-mob">
				<div class="pad-b20 align-center">
					<h2 class="font-s30 color6">ثبت نام منتور با موفقیت انجام شد</h2>
					<p class="color-darkgray font-s14">پس از بررسی اطلاعات و تایید، اطلاعات منتور و راهنمای ادامه فرآیند، از طریق ایمیل یا شماره تلفن ارسال خواهند شد.</p>
				</div>
				<div class="align-center spacer-t20 colm">
					<a class="btn-web margin-auto colm5 colm7-mob btn-finish-responsive margin-auto show" href="http://100startups.ir/">بازگشت به صفحه اصلی</a>
					<div class="clearfix"></div>
				</div>
			</div>
		</div>
	</div>
</div>
<?php get_footer();?>