<?php /* Template Name: send number  */?>
<?php
session_start();
$_SESSION['verify'] = 'ok';
if(isset($_POST['mobile_mentor'])){
	$mobile = $_POST['mobile_mentor'];
    $role = $_POST['role'];
	$exists_mobile = mobile_exists( $mobile );
	if($exists_mobile != -1){
		$user_id = $exists_mobile[0]->user_id;
		$mobile_verify = mt_rand(10000,99999);
		$message = $mobile_verify;
        $_SESSION['user_id'] = $user_id;
        $_SESSION['step_mentor'] = 1;
		$_SESSION['mobile_exists'] = 'ok';
		$_SESSION['mobile_verify'] = $mobile_verify;
		$_SESSION['mobile_mentor'] = $mobile;
		$time = strtotime(date("Y-m-d H:i:s"));
		$expir_time = strtotime('+2 minutes', $time);
		$_SESSION['expir_time'] = $expir_time ;
		send_sms($mobile,$message);
		wp_redirect(home_url('/validation'));
	}else{
		$mobile_verify = mt_rand(10000,99999);
		$user_name = 'u'.randomString(8);
		$userdata  = array(
		    'user_login' =>  $user_name,
		    'user_pass'  => $mobile_verify,
		    'role'       =>'managers',
		);
		$user_id = wp_insert_user( $userdata );
        update_user_meta($user_id,'mobile_mentor',$mobile);
		update_user_meta($user_id,'step_mentor',1);
		update_user_meta($user_id,'roles',array('coach'));
		
        $message = $mobile_verify;
        $_SESSION['user_id'] = $user_id;
        $_SESSION['step_mentor'] = 1;
		$_SESSION['mobile_verify'] = $mobile_verify;
		$_SESSION['mobile_mentor'] = $mobile;
		
		send_sms($mobile,$message);
		wp_redirect(home_url('/validation'));
	}
}
?>
<?php get_header();?>
<style>
header , footer ,.mobile{
	display: none;
}
.hide-tab{
	display: none;
}
</style>
<div id="section-step" class="container-fluide  min-100vh flex-center"> 
	<div class="container pad-20 pad-step pad-50-tmob">
		<div id="section-step-content" class="colm8 colm10-tab colm margin-auto pad-40 pad-20-tab pad-10-mob bg-white spacer-t40 spacer-b40">
			<div class="colm10 colm11-tab colm margin-auto pad-5-mob">
				<div class="pad-b20">
					<h2 class="font-s30 color6">دریافت کد</h2>
					<p class="color-darkgray font-s14 align-justify pad-t15">لطفا برای دریافت رمز عبور، تلفن همراه خود را وارد نمایید.</p>
				</div>
				<div class="spacer-t5">
					<form method="post" class="smart-validate" >
						<div class="frm-row pad-5 colm colm9 margin-auto">
                            <label for="mobile" class="gui-label pad-5">تلفن همراه </label>
							<label class="relative">
								<span class="icon-gui flex-center"><i class="fa fa-phone vertical"></i></span>
								<input dir="ltr" type="tel" placeholder="091212345678" class="gui-input sans-digit englishnum number-input" data-msg-required="لطفا شماره همراه خود را وارد کنید" name="mobile_mentor" data-rule-customphone="true" id="mobile-mentor" value="<?php if($mobile_mentor) echo $mobile_mentor;?>" required>
							</label>
						</div>
						<div class="align-left spacer-t40">
			     			<button type="submit" class="btn-web colm" >مرحله بعد </button>
						</div>
					</form>
				</div>
			</div>
		</div>
	</div>
</div>
<?php get_footer() ?>