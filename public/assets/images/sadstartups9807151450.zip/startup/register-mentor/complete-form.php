<?php /* Template Name: complete form  */?>
<?php 
if(isset($_POST['submit'])){
	
	$user = wp_get_current_user();
	$user_id = $user->ID;
	$birthday_mentor = jdateToTimestamp($_POST['birthday']);
	update_user_meta($user_id,'first_name_mentor',$_POST['first_name_mentor']);
	update_user_meta($user_id,'last_name_mentor',$_POST['last_name_mentor']);
	update_user_meta($user_id,'birthday_mentor',$birthday_mentor);
	update_user_meta($user_id,'linkedin_mentor',$_POST['linkedin_mentor']);
	update_user_meta($user_id,'expertise_mentor',$_POST['expertise_mentor']);
	update_user_meta($user_id,'educationl_mentor',$_POST['educationl_mentor']);
	update_user_meta($user_id,'average_mentor',$_POST['average_mentor']);
	
	wp_redirect(home_url('/fainal'));

}
?>
<?php get_header();?>
<style>
header , footer ,.mobile{
	display: none;
}
.hide-tab{
	display: none;
}
</style>

<div id="section-step" class="container-fluide bg-gray">
	<div  class="container pad-20 pad-step pad-50-tmob min-100vh flex-center">
		<div id="section-step-content" class="colm8 colm10-tab colm margin-auto pad-40 pad-20-tab pad-10-mob bg-white spacer-t40 spacer-b40">
			<div class="colm10 colm11-tab colm margin-auto pad-5-mob">
				<div class="pad-b5">
					<h2 class="font-s30 color6">اطلاعات منتور</h2>
                    <p class="color-darkgray font-s14 pad-t15">لطفا برای ثبت نهایی اطلاعات خود را تکمیل کنید  </p>
				</div>
				<div class="spacer-t10">
					<form method="post" class="smart-validate" enctype="multipart/form-data">
						<div class="person" id="">
							<div class="frm-row">
								<div class="colm6 colm pull-right pad-5">
									<label for="first-name" class="gui-label pad-5">نام :</label>
									<label class="relative">
										<span class="icon-gui flex-center"><i class=" fa fa-user vertical"></i></span>
										<input type="text" class="gui-input sans-digit" id="first-name" value="<?php echo $first_name_mentor; ?>" name="first_name_mentor" placeholder="مثال : محمد" data-rule-lettersonly="true" autocomplete="off" required>
									</label>
								</div>
								<div class="colm6 colm pull-right pad-5"> 
									<label for="last-name" class="gui-label pad-5">نام خانوادگی :</label>
									<label class="relative">
										<span class="icon-gui flex-center"><i class=" fa fa-user vertical"></i></span>
										<input type="text" class="gui-input sans-digit" value="<?php echo $last_name_mentor; ?>" name="last_name_mentor" placeholder="مثال : محمدی" data-rule-lettersonly="true" id="last-name" autocomplete="off" required>
									</label>
								</div>
								<div class="clearfix"></div>
							</div>
							<div class="frm-row">
								<div class="colm6 colm pull-right pad-5">
									<label for="mobile" class="gui-label pad-5"> شماره همراه:</label>
									<label class="relative">
										<span class="icon-gui flex-center"><i class=" fa fa-mobile"></i></span>
										<input dir="ltr" class="gui-input sans-digit" readonly value="<?php echo $mobile_mentor; ?>" id="mobile-mentor" >
									</label>
								</div>
								<div class="colm6 colm pull-right pad-5">
									<label for="email" class="gui-label pad-5">ایمیل :</label>
									<label class="relative">
										<span class="icon-gui flex-center"><i class=" fa fa-at"></i></span>
										<input dir="ltr" type="email" class="gui-input sans-digit" name="email_mentor" id="email-mentor" value="<?php echo $email_mentor; ?>"  placeholder="example@gmail.com" required>
									</label>
								</div>
								<div class="clearfix"></div>
							</div>
							<div class="frm-row">
								<div class="colm6 colm pull-right pad-5">
									<label for="linkedin" class="gui-label pad-5">لینکدین :</label>
									<label class="relative">
										<span class="icon-gui flex-center"><i class=" fab fa-linkedin-in vertical"></i></span>
										<input dir="ltr" type="text" class="gui-input sans-digit" value="<?php echo $linkedin_mentor; ?>"  name="linkedin_mentor" id="linkedin-mentor" >
									</label>
								</div>
								<div class="colm6 colm pull-right pad-5">
									<label for="birthday" class="gui-label pad-5"> تاریخ تولد :</label>
									<label class="relative">
										<span class="icon-gui flex-center"><i class=" fa fa-birthday-cake"></i></span>
										<input dir="ltr" class="gui-input sans-digit datepicker-gregorian" name="birthday_mentor" value="<?php echo date('Y-m-d',strtotime($birthday_mentor)); ?>" id="birthday-mentor" autocomplete="off" readonly required placeholder="1398/10/02" >
									</label>
								</div>
								
								<div class="clearfix"></div>
							</div>
							<div class="frm-row">
								<div class="colm6 colm pull-right pad-5">
									<label for="expertise" class="gui-label pad-5">تخصص:</label>
									<label class="relative">
										<span class="icon-gui flex-center"><i class=" fa fa-laptop-code vertical"></i></span>
										<input type="text" class="gui-input sans-digit" name="expertise_mentor" value="<?php echo $expertise_mentor; ?>" id="expertise-mentor" placeholder="مثال : نرم افزار" required>
									</label>
								</div>
						
						        <div class="colm6 colm pull-right pad-5">
						
								<label class="gui-label pad-5">تحصیلات:</label>
						            <label  class="relative">
						                <span class="icon-gui flex-center"><i class=" fa fa-user-graduate vertical"></i></span>
						                <select class="gui-input sans-digit" name="educationl_mentor">
						                    <option value="">میزان تحصیلات خود را انتخاب کنید</option>
						                    <option value="1"<?php if ( $educationl_mentor == 1 ) echo 'selected="selected"'; ?>>زیر دیپلم</option>
						                    <option value="2"<?php if ( $educationl_mentor == 2 ) echo 'selected="selected"'; ?>>دیپلم</option>
						                    <option value="3"<?php if ( $educationl_mentor == 3 ) echo 'selected="selected"'; ?>>فوق دیپلم</option>
						                    <option value="4"<?php if ( $educationl_mentor == 4 ) echo 'selected="selected"'; ?>>لیسانس</option>
						                    <option value="4"<?php if ( $educationl_mentor == 5 ) echo 'selected="selected"'; ?>>فوق لیسانس</option>
						                    <option value="4"<?php if ( $educationl_mentor == 6 ) echo 'selected="selected"'; ?>>دکتری</option>
						                    <option value="4"<?php if ( $educationl_mentor == 7 ) echo 'selected="selected"'; ?>>فوق دکتری</option>
						                </select>
						            </label>
						
						        </div>
								
								<div class="clearfix"></div>
							</div>
							<div class="frm-row">
								<div class="colm6 colm pad-5 pull-right">
									<label for="average" class="gui-label pad-5"> زمان اختصاص داده شده به تیم در طول ماه:</label>
									<label class="relative">
										<span class="icon-gui flex-center"><i class=" fa fa-clock vertical"></i></span>
										<input type="number" class="gui-input sans-digit" name="average_mentor" value="<?php echo $average_mentor; ?>" id="average-mentor" placeholder="مثال : 100 ساعت" >
									</label>
								</div>
								<div class="clearfix"></div>
								<div class="align-left spacer-t40">
					     			<button type="submit" class="btn-web colm" >مرحله بعد </button>
								</div>
							</div>
						</div>

<?php get_footer();?>