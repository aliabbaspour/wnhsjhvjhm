<?php /* Template Name: authentication  */?>
<?php if(is_user_logged_in()){?>
<?php get_header();?>
<style>
header , footer ,.mobile{
	display: none;
}
.hide-tab{
	display: none;
}
</style>
<div id="section-step" class="container-fluide  min-100vh flex-center"> 
	<div class="container pad-20 pad-step pad-50-tmob">
		<div id="section-step-content" class="colm8 colm10-tab colm margin-auto pad-40 pad-20-tab pad-10-mob bg-white spacer-t40 spacer-b40">
			<div class="colm10 colm11-tab colm margin-auto pad-5-mob">
				<div class="pad-b20">
					<h2 class="font-s30 color6">احراز هویت</h2>
					<p class="color-darkgray font-s14 align-justify pad-t15">لطفا برای ادامه روند، از صحت اطلاعات خود مطمعن شوید.</p>
				</div>
				<div class="spacer-t5">
					<form method="post" class="smart-validate" >
						<div class="frm-row pad-5 colm colm6 pull-right">
                            <label for="mobile" class="gui-label pad-5">نام و نام خانوادگی</label>
							<label class="relative">
								<span class="icon-gui flex-center"><i class="fa fa-user vertical"></i></span>
								<input  type="text" placeholder="علی عباسپور" class="gui-input sans-digit englishnum number-input"  name="name_mentor"  id="name-mentor"  disabled>
							</label>
						</div>
						<div class="frm-row pad-5 colm colm6 pull-right">
                            <label for="mobile" class="gui-label pad-5">شماره همراه</label>
							<label class="relative">
								<span class="icon-gui flex-center"><i class="fa fa-phone vertical"></i></span>
								<input dir="ltr" type="tel" placeholder="09XXXXXX" class="gui-input sans-digit englishnum number-input"  name="mobile_mentor"  id="mobile-mentor" >
							</label>
						</div>
						<div class="clearfix"></div>
						<div class="align-left spacer-t40">
			     			<button type="submit" class="btn-web colm" >مرحله بعد </button>
						</div>
					</form>
				</div>
			</div>
		</div>
	</div>
</div>
<?php get_footer() ?>
<?php }else{
	wp_redirect(home_url(''));
}?>